package com.company;

import java.util.Scanner;

public class integer20 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        int a;

        System.out.print("a sekundda=");
        a =num.nextInt();

        System.out.println("a to'la soatda=" + a / 3600);

    }
}
