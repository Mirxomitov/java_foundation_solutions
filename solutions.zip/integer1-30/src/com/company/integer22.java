package com.company;

import java.util.Scanner;

public class integer22 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        int a;

        System.out.print("a soniyada=");
        a =num.nextInt();

        System.out.println("a soat va soniyada =  " + a / 3600 + " soat va  " + a % 3600 + "soniya" );

    }
}
