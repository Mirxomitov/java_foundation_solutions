package com.company;

import java.util.Scanner;

public class integer12 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        int a;

        System.out.println("SHART: 3 xonali son kiriting");

        System.out.print("\na=");
        a = num.nextInt();

        System.out.print("Raqamlari teskari tartibda yozilsa : ");
        System.out.print("" + a % 10 + a / 10 % 10 + a / 100);
    }
}