package com.company;

import java.util.Scanner;

public class integer18 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        int a;

        System.out.println("a=");
        a = num.nextInt();

        System.out.println("Mingliklar xonasidagi raqam=" + (a / 1000 - a / 10000 * 10));
        System.out.println("Mingliklar xonasidagi raqam=" + a / 1000 % 10);
    }
}
