package com.company;

import java.util.Scanner;

public class integer5 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a, b;


        System.out.print("a kesma uzunligi=");
        a = num.nextDouble();
        System.out.print("b kesma uzunligi=");
        b = num.nextDouble();

        System.out.println();

        System.out.println("a kesma ichiga b kesmadan " + (int) (a / b) +" ta joylashtirish mumkin");
        System.out.println("b kesmaning joylashmagan qismi uznligi=" + (b - a % b) );
        System.out.printf("b kesmaning joylashmagan qismi = %.4f%n", (b - a % b) / b );
    }
}