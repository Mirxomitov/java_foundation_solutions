package com.company;

import java.util.Scanner;

public class integer29 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);
        int A, B, C, x, y;

        System.out.print("A=");
        A = num.nextInt();
        System.out.print("B=");
        B = num.nextInt();
        System.out.print("C=");
        C = num.nextInt();

        x = A / C ;
        y = B / C;


        System.out.println("tomonlari A va B bo'lgan to'g'ri to'rtburchakning ichiga tomoni C bo'lgan kvadratdan ");
        System.out.println(x * y + " ta joylashadi " );
        System.out.println("Kvadrat sig'may qolgan yuzasi 1-usulda =" + (A % C * B + (B % C) * (C * (A / C))));
        System.out.println("Kvadrat sig'may qolgan yuzasi 2-usulda=" + (A * B - x * y * C * C));
    }
}
