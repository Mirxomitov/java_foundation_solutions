package com.company;

import java.util.Scanner;

public class integer11 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        int a;

        System.out.println("SHART: 3 xonali son kiriting");

        System.out.print("\na=");
        a = num.nextInt();

        System.out.println(a + " soning birliklar xonasidagi raqam = " + a % 10);
        System.out.println(a + " soning o'nliklar xonasidagi raqam = " + a / 10 % 10);
        System.out.println(a + " soning yuzliklar xonasidagi raqam = " + a / 100 );
        System.out.println("\nUlarning yig'indisi :");
        System.out.print(a % 10 + " + " + a / 10 % 10 + " + " + a / 100 + " = ");
        System.out.print(a % 10 + a / 10 % 10 + a / 100);
    }
}