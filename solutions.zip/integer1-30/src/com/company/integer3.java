package com.company;

import java.util.Scanner;

public class integer3 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        int a;

        System.out.print("necha bite=");
        a = num.nextInt();

        System.out.println("to'liq Kb = " + a / 1024);
    }
}