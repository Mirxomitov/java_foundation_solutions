package com.company;

import java.util.Scanner;

public class integer1 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        int a;

        System.out.print("L [cantimeter]=");
        a = num.nextInt();

        System.out.println("to'liq metr = " + a / 100);
    }
}
