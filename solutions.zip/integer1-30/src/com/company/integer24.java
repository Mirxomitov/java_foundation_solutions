package com.company;

import java.util.Scanner;

public class integer24 {
    public static void main(String[] args) {

        Scanner day = new Scanner(System.in);

        int a0, a1, a2, a3, a4, a5, a6, K;

        System.out.println("JADVAL:");
        System.out.print("0 - yakshanba, ");
        System.out.print("1 - dushanba, ");
        System.out.print("2 - seshanba, ");
        System.out.print("3 - chorshanba, ");
        System.out.print("4 - payshanba, ");
        System.out.print("5 - juma, ");
        System.out.print("6 - shanba.\n\n");

        System.out.println("1-yanvar dushanba deb qabul qilinsin!\n");

        System.out.print("K ni kiriting (1-365 oraliqda) :");
        K = day.nextInt();

        System.out.println(K % 7 + " -> haftaning qaysi kuniga to'g'ri kelishini jadvaldan ko'ring!");
    }
}
