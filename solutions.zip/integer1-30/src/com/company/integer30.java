package com.company;

import java.util.Scanner;

public class integer30 {
    public static void main(String[] args) {
        Scanner year = new Scanner(System.in);
        int a;

        System.out.print("Yilni kiriting=");
        a = year.nextInt();

        System.out.println( a + " - yil " + (a / 100 + 1) + " - asrga tegishli");
    }
}
