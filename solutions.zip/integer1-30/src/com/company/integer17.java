package com.company;

import java.util.Scanner;

public class integer17 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        int a;

        System.out.println("a=");
        a = num.nextInt();

        // System.out.println("Yuzliklar xonasidagi son=" + (a - a / 1000 * 1000 ));
        // System.out.println("Yuzliklar xonasidagi son=" + a % 1000);

        System.out.println("Yuzliklar xonasidagi son=" + (a / 100 - a / 1000 * 10));
        System.out.println("Yuzliklar xonasidagi son=" + a / 100 % 10);
    }
}
