package com.company;

import java.util.Scanner;

public class integer10 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        int a;

        System.out.println("SHART: 3 xonali son kiriting");

        System.out.print("a=");
        a = num.nextInt();

        System.out.println(a + " soning birliklar xonasidagi raqam = " + a % 10);
        System.out.println(a + " soning o'nliklar xonasidagi raqam = " + a / 10 % 10);
    }
}
