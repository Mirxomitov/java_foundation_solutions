package com.company;

import java.util.Scanner;

public class integer23 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        int a;

        System.out.print("a soniyada=");
        a =num.nextInt();

        System.out.println("a = " + a / 3600 + " soat " + a % 3600 / 60 + " daqiqa va " + a % 3600 % 60 + " soniya" );

    }
}
