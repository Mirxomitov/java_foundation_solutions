package com.company;

import java.util.Scanner;

public class integer6 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        byte a;

        System.out.print("a=");
        a = num.nextByte();

        System.out.println(a + " soning o'nliklar xonasi = " + a / 10);
        System.out.println(a + " soning birliklar xonasi = " + a % 10);
    }
}
