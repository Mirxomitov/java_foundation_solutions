package com.company;

import java.util.Scanner;

public class integer4 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a, b, c;


        System.out.print("a kesma uzunligi=");
        a = num.nextDouble();
        System.out.print("b kesma uzunligi=");
        b = num.nextDouble();

        c =  a / b;
        c = (int) c;

        System.out.println("a kesma ichiga b kesmadan " + c +" ta joylashtirish mumkin");
    }
}