package com.company;

import java.util.Scanner;

public class Matrix25 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int[][] arr = Main.AddElementsInt(4, 3);
        Main.displayInt(arr);

        int max = Integer.MIN_VALUE;
        int index = -1;

        for (int i = 0; i < arr.length; i++) {
            int sum = 0;

            for (int j = 0; j < arr[i].length; j++) {
                sum += arr[i][j];
            }

            if (max < sum) {
                max = sum;
                index = i + 1;
            }
        }
        System.out.println("row = " + index + ", sum = " + max);
    }
}
