package com.company;

import java.util.Scanner;

public class Matrix19 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int[][] arr = Main.AddElementsInt(5, 6);
        Main.displayInt(arr);


        for (int[] ints : arr) {
            int sum = 0;
            for (int anInt : ints) {
                sum += anInt;
            }
            System.out.print("sum = " + sum + " ");
        }
//        System.out.println("multiple = " + multiple);
    }
}
