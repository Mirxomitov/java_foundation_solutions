package com.company;

public class Matrix10 {

    public static void main(String[] args) {

        double[][] arr = Main.AddElementsDouble(4, 4);
        Main.displayDouble(arr);
        System.out.println();
        for (int i = 0; i < arr.length; i += 2) {
            for (int j = 0; j < arr[i].length; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }
    }
}