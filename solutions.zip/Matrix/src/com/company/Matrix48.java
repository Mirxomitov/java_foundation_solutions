package com.company;

public class Matrix48 {
    public static void main(String[] args) {

        int[][] matrix = {
                {1, 2, 5, 4, 3},
                {2, 3, 6, 5, 4},
                {3, 4, 7, 6, 5}
        };

        int k1 = 2;
        int k2 = 4;

        for (int row = 0; row < matrix.length; row++) {
            int temp = matrix[row][k1];

            matrix[row][k1] = matrix[row][k2];
            matrix[row][k2] =temp;
        }
        Main.displayInt(matrix);
    }
}