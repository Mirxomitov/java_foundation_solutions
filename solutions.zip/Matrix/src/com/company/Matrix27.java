package com.company;

import java.util.Scanner;

public class Matrix27 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int[][] arr = Main.AddElementsInt(2, 3);
        Main.displayInt(arr);

        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;

        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (min > arr[i][j]) min = arr[i][j];
            }
            if(max < min) max = min;
        }
        System.out.println(max);
    }
}
