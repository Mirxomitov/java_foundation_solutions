package com.company;

public class Main {

    public static void main(String[] args) {
        // write your code here
    }

    public static void displayDouble(double[][] arr) {
//        System.out.print("A matrix made up of random elements : \n");
        for (double[] doubles : arr) {
            for (double aDouble : doubles) {
                System.out.print(aDouble + " ");
            }
            System.out.println("");
        }
    }

    public static void displayInt(int[][] arr) {
        System.out.println("");
        for (int[] ints : arr) {
            for (int anInt : ints) {
                System.out.print(anInt + " ");
            }
            System.out.println("");
        }
    }

    public static int[][] AddElementsInt(int m, int n) {
        int[][] arr = new int[m][n];
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++)
                if ((int) (Math.random() * 10) % 2 == 0) arr[i][j] = (int) (Math.random() * 10);
                else arr[i][j] = (int) (Math.random() * -10);
        }
        return arr;
    }

    public static double[][] AddElementsDouble(int row, int col) {
        double[][] arr = new double[row][col];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                arr[i][j] = (int) (Math.random() * 1000) / 100.0;
            }
        }
        return arr;
    }
    public static int MaxRowEl(int[][] matrix, int row){
        int max = Integer.MIN_VALUE;

            for (int col = 0; col < matrix[0].length; col++) {
                if (max < matrix[row][col]) max = matrix[row][col];
            }
        return max;
    }

    public static int MinColEl(int[][] matrix,int col){
        int min = Integer.MAX_VALUE;

        for (int row = 0; row < matrix.length; row++) {
            if (min > matrix[row][col]) min = matrix[row][col];
        }
        return min;
    }

    public static int MaxColEl(int[][] matrix,int col){
        int max = Integer.MIN_VALUE;

        for (int row = 0; row < matrix.length; row++) {
            if (max < matrix[row][col]) max = matrix[row][col];
        }
        return max;
    }
}