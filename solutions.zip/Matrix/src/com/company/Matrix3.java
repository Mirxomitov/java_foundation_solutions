package com.company;

import java.util.Scanner;

public class Matrix3 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("row = ");
        int row = in.nextInt();
        System.out.println("col = ");
        int col = in.nextInt();

        int[][] arr = new int[row][col];

        for (int i = 0; i < row; i++) {
            int value = in.nextInt();
            for (int j = 0; j < col; j++) {
                arr[i][j] = value;
            }
        }
        Main.displayInt(arr);
    }
}
