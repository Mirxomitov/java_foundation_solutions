package com.company;

import java.util.Scanner;

public class Matrix57 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        // M va N juft qiymat qabul qilmaguncha qayta kiritilsin
        System.out.print("M (juft son) = ");
        int M;

        do {
            M = in.nextInt();
            if (M % 2 != 0) System.out.print("M = ");
        } while (M % 2 != 0);

        System.out.print("N (juft son) = ");
        int N;

        do {
            N = in.nextInt();
            if (N % 2 != 0) System.out.print("N = ");
        } while (N % 2 != 0);

        double[][] matrix = Main.AddElementsDouble(M, N);
        Main.displayDouble(matrix);

        // Asosiy qism boshlandi:
        //row :     i = 0; i < M / 2   va   j = M / 2; j > M
        //col :     a = 0; a < N / 2   va   b = N / 2; b > N

        // row
        for (int i = 0, j = M / 2; i < M / 2; i++, j++) {
            // col
            for (int a = 0, b = N / 2; a < N / 2; a++, b++) {
                // Swap
                double temp = matrix[i][a];
                matrix[i][a] = matrix[j][b];
                matrix[j][b] = temp;
            }
        }
        System.out.println("Aswer : \n");
        Main.displayDouble(matrix);
    }
}
