package com.company;

public class Matrix11 {

    public static void main(String[] args) {

        double[][] arr = Main.AddElementsDouble(4, 4);
        System.out.println("A matrix made up of random elements : ");
        Main.displayDouble(arr);

        System.out.println();

        for (int i = 0; i < arr.length; i += 2) {
            // chapdan o'ngga
            for (int j = 0; j < arr[i].length; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();

            // o'ngdan chapga
            for (int j = arr[i].length - 1; j >= 0 ; j--) {
                System.out.print(arr[i + 1][j] + " ");
            }
            System.out.println();
        }
    }
}