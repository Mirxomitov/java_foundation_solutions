package com.company;

public class Matrix49 {
    public static void main(String[] args) {
        int[][] matrix = {
                {1, 8, 6, 2, 1, 6},
                {2, 6, 7, 4, 5, 6},
                {3, 6, 4, 9, 4, 2},
                {7, 0, 3, 6, 5, 4}
        };

        for (int col = 0; col < matrix[0].length; col++) {
            int min = Integer.MAX_VALUE, max = Integer.MIN_VALUE;
            int indexMax = -1, indexMin = -1;

            for (int row = 0; row < matrix.length; row++) {
                if (max < matrix[row][col]) {
                    max = matrix[row][col];
                    indexMax = row;
                }
                if (min > matrix[row][col]) {
                    min = matrix[row][col];
                    indexMin = row;
                }
            }
//            swapMinMax_Row(matrix, col, indexMax, indexMin);
            int temp = matrix[indexMax][col];
            matrix[indexMax][col] = matrix[indexMin][col];
            matrix[indexMin][col] = temp;
        }
        Main.displayInt(matrix);
    }

//    static void swapMinMax_Row(int[][] matrix, int col, int max, int min) {
//
//        int temp = matrix[max][col];
//        matrix[max][col] = matrix[min][col];
//        matrix[min][col] = temp;
//
//    }
}
