package com.company;

public class Matrix14 {

    public static void main(String[] args) {

        double[][] arr = Main.AddElementsDouble(5, 5);
        Main.displayDouble(arr);

        System.out.println();

        for (int row = 0; row < arr.length; row++) {
            for (int col = 0; col < arr.length - row; col++) {
                System.out.print(arr[col][row] + " ");
            }
            System.out.println();
        }
        System.out.println();


        for (int i = arr.length - 1; i > 0; i--) {
            int breaker = 0;
            for (int j = arr.length - i; j < arr.length; j++) {

                int counter = 1;

                while (arr.length - i - counter != 0 && breaker == 0){
                    counter++;
                    System.out.print("     ");
                }
                breaker++;

                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }

    }
}
