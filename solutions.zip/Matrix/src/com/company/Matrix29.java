package com.company;

public class Matrix29 {
    public static void main(String[] args) {
        double[][] arr = {
                {2.70, 7.86, 1.21, 6.20, 7.97, 6.47, 3.77},
                {0.63, 9.64, 6.02, 2.69, 1.73, 0.30, 5.77} // Answer is : 3 and 4
        };
        Main.displayDouble(arr);

        double min = Integer.MAX_VALUE;
        double max = Integer.MIN_VALUE;

        for (int i = 0; i < arr.length; i++) {
            float sum = 0;
            int counter = 0;

            for (int j = 0; j < arr[i].length; j++) {
                sum += arr[i][j];
            }
            sum /= arr[i].length;

            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] < sum) counter++;
            }
            System.out.println(counter);
        }
    }
}
