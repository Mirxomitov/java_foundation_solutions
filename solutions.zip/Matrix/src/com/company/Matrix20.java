package com.company;

import java.util.Scanner;

public class Matrix20 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int[][] arr = Main.AddElementsInt(5, 6);
        Main.displayInt(arr);

        for (int col = 0; col < arr[1].length; col++) {
            int product = 1;
            for (int[] ints : arr) {
                product *= ints[col];
            }
            System.out.print(product + " ");
        }
    }
}
