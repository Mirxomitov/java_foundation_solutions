package com.company;

import java.util.Scanner;

public class Matrix28 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int[][] arr = Main.AddElementsInt(3, 3);
        Main.displayInt(arr);

        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;

        int indexCol = -1;

        for (int col = 0; col < arr[0].length; col++) {
            int MIN = Integer.MAX_VALUE;
            int sum = 0;

            for (int row = 0; row < arr.length; row++) {
                MIN = Math.min(min, arr[row][col]);
                sum += arr[row][col];
            }
            if (max < sum) {
                min = MIN;
                max = sum;
                indexCol = col;
            }

        }
//
//        for (int i = 0; i < arr.length; i++) {
//            min = Math.min(min, arr[i][indexCol]);
//        }
        System.out.println("min son = " + min);
        System.out.println("min ustun = " + indexCol);
    }
}
