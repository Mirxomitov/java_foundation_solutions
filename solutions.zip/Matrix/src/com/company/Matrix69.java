package com.company;

import java.util.Scanner;

public class Matrix69 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int[][] matrix = {
                {7, 8, 5, 2, 7, 2, 5, 0},
                {1, 7, 1, 0, 0, 4, 6, 0},
                {9, 5, 1, 5, 7, 2, 3, 0},
        };

//        newMatrix(matrix);
//        Main.displayInt(matrix);

        int k = in.nextInt();

        for (int col = matrix[0].length - 2; col >= k; col--) {
            for (int row = 0; row < matrix.length; row++) {
                matrix[row][col + 1] = matrix[row][col];
            }
        }
        for (int row = 0; row < matrix.length; row++) {
            matrix[row][k] = 1;
        }
        Main.displayInt(matrix);
    }

//    public static int[][] newMatrix(int[][] matrix) {
//
//        int[][] newMatrix = new int[matrix.length][matrix[0].length + 1];
//
//        for (int col = 0; col < matrix[0].length; col++) {
//            for (int row = 0; row < matrix.length; row++) {
//                newMatrix[row][col] = matrix[row][col];
//            }
//        }
//        return newMatrix;
//    }
}
