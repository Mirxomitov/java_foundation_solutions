package com.company;

import java.util.Scanner;

public class Matrix6 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("row = ");
        int row = in.nextInt();
        System.out.print("col = ");
        int col = in.nextInt();

        double[][] arr = new double[row][col];

        System.out.print("Q = ");
        double q = in.nextDouble();

        for (int i = 0; i < col; i++) {
            double value = in.nextDouble();
            for (int j = 0; j < row; j++) {
                arr[j][i] = value * Math.pow(q, j);
            }
        }
        Main.displayDouble(arr);
    }
}
