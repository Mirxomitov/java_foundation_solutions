package com.company;

import java.util.Scanner;

public class Matrix23 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int[][] arr = Main.AddElementsInt(7, 2);
        Main.displayInt(arr);

        for (int[] ints : arr) {
            int min = Integer.MAX_VALUE;
            for (int anInt : ints) {
                if (min > anInt) min = anInt;
            }
            System.out.print(min + " ");
        }
    }
}
