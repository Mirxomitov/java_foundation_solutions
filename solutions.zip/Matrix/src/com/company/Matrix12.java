package com.company;

public class Matrix12 {

    public static void main(String[] args) {

        double[][] arr = Main.AddElementsDouble(5, 4);
        Main.displayDouble(arr);

        System.out.println();

        for (int row = 0; row < arr[row].length; row++) {

            for (int col = 0; col < arr.length; col++) {
                System.out.print(arr[col][row] + " ");
            }
            row++;
            System.out.println();
            for (int col = arr.length - 1; col >= 0; col--) {
                System.out.print(arr[col][row] + " ");
            }
            System.out.println();
        }
    }
}