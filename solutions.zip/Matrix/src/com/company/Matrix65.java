package com.company;

public class Matrix65 {
    public static void main(String[] args) {
        int[][] matrix = {
                {7, 8, -5, -2, 7},
                {-1, 7, -1, 0, 0},
                {9, 5, -1, 5, 7},
        };
        Main.displayInt(matrix);


        int index = Index(matrix);
        System.out.println("index = " + index);

        for (int col = index; col < matrix[0].length - 1; col++) {
            for (int row = 0; row < matrix.length; row++) {
                matrix[row][col] = matrix[row][col + 1];
            }
        }
        for (int row = 0; row < matrix.length; row++) {
            matrix[row][matrix[0].length - 1] = 0;
        }
        Main.displayInt(matrix);
    }

    public static int Index(int[][] matrix) {
        int index = -1;

        for (int col = 0; col < matrix[0].length; col++) {
            boolean positive = true;
            for (int row = 0; row < matrix.length; row++) {
                if (matrix[row][col] < 0) positive = false;
            }

            if (positive) {
                index = col;
                return index;
            }
        }
        return index;
    }
}