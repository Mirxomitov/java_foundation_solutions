package com.company;

public class Matrix31 {
    public static void main(String[] args) {
        double[][] arr = {
                {2.70, 7.86, 1.21, 6.20, 7.97, 6.47, 3.77},
                {2.72, 7.96, 2.21, 3.20, 4.97, 8.47, 4.77},
                {0.63, 9.64, 6.02, 2.69, 1.73, 0.30, 5.77}
        };
        Main.displayDouble(arr);
        System.out.println();

        double min = Integer.MAX_VALUE;

        double average = 0;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                average += arr[i][j];
            }
        }
        average /= arr.length * arr[0].length; //an average value was found
        System.out.println("average = " + average);

        int indexOfRow = -1;
        int indexOfCol = -1;

        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (min > Math.abs(arr[i][j] - average)) {
                    indexOfRow = i + 1;
                    indexOfCol = j + 1;
                    min = Math.abs(arr[i][j] - average);
                }
            }
        }
        System.out.println("\nrow = " + indexOfRow);
        System.out.println("col =  " + indexOfCol);

    }
}
