package com.company;

import java.util.Scanner;

public class Matrix22 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int[][] arr = Main.AddElementsInt(2, 6);
        Main.displayInt(arr);

        for (int col = 1; col < arr[0].length; col += 2) {
            int sum = 0;
            for (int row = 0; row < arr.length; row++) {
                sum += arr[row][col];
            }
            System.out.print(sum + "  ");
        }
    }
}
