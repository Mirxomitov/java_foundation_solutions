package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Matrix61 {
    public static void main(String[] args) {
        int matrix[][] = {
                {1, 2, 3,},
                {4, 5, 6,},
                {7, 8, 9,}
        };

        int k = 1;

        for (int row = k - 1; row < matrix.length - 1; row++) {
            matrix[row] = matrix[row + 1];
        }
        /* 1 - usul */
        int arr0[] = new int[matrix[0].length];
        matrix[matrix.length - 1] = arr0;

//        /* 2 - usul */
//        for (int col = 0; col < matrix[0].length; col++) {
//            matrix[matrix.length - 1][col] = 0;
//        }
        Main.displayInt(matrix);
    }
}

class matrix_61 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int k = 1;
        int matrix[][] = {
                {1, 2, 3,},
                {4, 5, 6,},
                {7, 8, 9,}
        };
        //----------------------------------------------------------------------//
        for (int i = k; i < matrix.length - 1; i++) {
            matrix[k] = matrix[i + 1];
        }

        System.out.println(Arrays.deepToString(matrix));
    }
}
