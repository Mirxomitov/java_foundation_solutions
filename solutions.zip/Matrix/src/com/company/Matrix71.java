package com.company;

public class Matrix71 {
    public static void main(String[] args) {
        int[][] matrix = {
                {7, 8, 5, 2, 7, 2, 5, 0},
                {1, 7, 1, -9, 0, 4, 6, 0},
                {9, 5, 1, 5, 7, 2, 3, 0},
        };
        int MIN = Integer.MAX_VALUE;
        int indexOfMin = -1;

        for (int col = 0; col < matrix[0].length; col++) {
            int min = Integer.MAX_VALUE;
            for (int row = 0; row < matrix.length; row++) {
                if( min > matrix[row][col]) min = matrix[row][col];
            }
            if (MIN > min) { // > birinchi uchragan uchun >= oxirgi uchragan uchun
                MIN = min;
                indexOfMin = col;
            }
        }
        SwapColInt(matrix, indexOfMin);
        Main.displayInt(matrix);
    }
    public static int[][] SwapColInt(int[][] matrix, int index){
        for (int col = matrix[0].length - 1; col > index; col--) {
            for (int row = 0; row < matrix.length; row++) {
                matrix[row][col] = matrix[row][col - 1];
            }
        }
        for (int row = 0; row < matrix.length; row++) {
            matrix[row][index + 1] = matrix[row][index];
        }

        return matrix;
    }
}
