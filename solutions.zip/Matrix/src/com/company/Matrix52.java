package com.company;

public class Matrix52 {
    public static void main(String[] args) {
        int[][] matrix = {
                {3, 2, 3},
                {4, 9, 2},
                {5, 6, 10},
        };
        Main.displayInt(matrix);
        System.out.print("\n");

        // MAX va MIN matritsadagi ekstremumlar uchun
        int MAX = Integer.MIN_VALUE, MIN = Integer.MAX_VALUE;
        int indexOfMax = -1, indexOfMin = -1;

        for (int j = 0; j < matrix.length; j++) {

            // max va min har bir row uchun ekstremumlar
            int max = Integer.MIN_VALUE;
            int min = Integer.MAX_VALUE;

            for (int i = 0; i < matrix[0].length; i++) {
                if (min > matrix[j][i]) min = matrix[j][i];
                if (max < matrix[j][i]) max = matrix[j][i];
            }
            if (MAX < max) {
                MAX = max;
                indexOfMax = j;
            }
            if (MIN > min) {
                MIN = min;
                indexOfMin = j;
            }
        }
        System.out.println("Ekstremumlar : " + MAX + " va " + MIN);
        System.out.println("Ustunlar [indeks] : " + indexOfMax + " va " + indexOfMin);

        // satrlarni almashtirmiz
        for (int j = 0; j < matrix.length; j++) {
            int temp = matrix[j][indexOfMax];
            matrix[j][indexOfMax] = matrix[j][indexOfMin];
            matrix[j][indexOfMin] = temp;
        }
        Main.displayInt(matrix);
    }
}

