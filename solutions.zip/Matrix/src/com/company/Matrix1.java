package com.company;

import java.util.Arrays;

public class Matrix1 {

    public static void main(String[] args) {
        int m = 4;
        int n = 3;

        int[][] matrix = new int[m][n]; // pastga 4 yonga 3

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = 10 * i;
            }
        }
        System.out.println(Arrays.deepToString(matrix));
    }
}
