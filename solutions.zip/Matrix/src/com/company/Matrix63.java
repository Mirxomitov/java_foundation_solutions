package com.company;

import java.util.Arrays;

public class Matrix63 {
    public static void main(String[] args) {
        int[][] matrix = Main.AddElementsInt(6, 3);
        Main.displayInt(matrix);

        int MIN = Integer.MAX_VALUE;
        int index = -1;

        for (int i = 0; i < matrix.length; i++) {
            int min = Integer.MAX_VALUE;

            for (int j = 0; j < matrix[i].length; j++) {
                if (min > matrix[i][j]) min = matrix[i][j];
            }

            if (MIN > min) {
                MIN = min;
                index = i; // satr
            }
        }
        System.out.println(MIN);
        System.out.println(index);
        //MIN bor bo'lgan satr elementlarini o'chirish uchun
        for (int row = index; row < matrix.length - 1; row++) {
            matrix[row] = matrix[row + 1];
        }
        int[] arr0 = new int[matrix[0].length];
        matrix[matrix.length - 1] = arr0;

        System.out.println("\n Answer : ");
        Main.displayInt(matrix);

    }
}

class matrix_63 {
    public static void main(String[] args) {
        int matrix[][] = {
                {4, 5, 6,},
                {1, 2, 3,},
                {7, 8, 9,}};
        //----------------------------------------------------------------------//
        int MIN = Integer.MAX_VALUE; //barcha qatorlardagi minimumlar ichidan so'ngi eng kichigini oladi
        int index = -1;

        for (int i = 0; i < matrix.length; i++) {
            int min = Integer.MAX_VALUE;

            for (int j = 0; j < matrix[0].length; j++) {
                if (matrix[i][j] < min) {
                    min = matrix[i][j]; // bu i chi qatorning minimumi
                    System.out.println((i + 1) + " - qator minimumi = " + min);
                }
            }

            if (MIN > min) {
                MIN = min; // min lar ichida eng kichigini topadi
                index = i + 1;
            }
        }
        System.out.println(MIN + " matrix ning eng kichik elementi, " + index + " - qatorda");

        // index qatnashgan qatorni eng pastki qatorgacha surib chiqamiz
        int[] temp = new int[matrix[0].length];
        temp = matrix[index];

        for (int row = index; row < matrix.length - 1; row++) {
            matrix[row] = matrix[row + 1];
        }
        matrix[matrix.length - 1] = temp;
        System.out.println(Arrays.deepToString(matrix));
    }
}
