package com.company;

public class Matrix38 {
    public static void main(String[] args) {
        int[][] matrix = {
                {6, 6, 6, 4, 5},
                {5, 6, 5, 6, 6},
                {5, 6, 5, 6, 6}
        };


    }
}