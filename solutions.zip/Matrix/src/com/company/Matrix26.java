package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Matrix26 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int[][] arr = Main.AddElementsInt(4, 7);
        Main.displayInt(arr);

        int min = Integer.MAX_VALUE;
        int index = -1;

        for (int i = 0; i < arr[0].length; i++) {
            int product = 1;

            for (int j = 0; j < arr.length; j++) {
                product *= arr[j][i];
            }

            if (min >= product) {
                min = product;
                index = i + 1;
            }
        }
        System.out.println("col = " + index + ", final min product = " + min);
    }
}
