package com.company;

import java.util.Scanner;

public class Matrix5 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("row = ");
        int row = in.nextInt();
        System.out.print("col = ");
        int col = in.nextInt();

        double[][] arr = new double[row][col];

        System.out.print("D = ");
        double d = in.nextDouble();

        for (int i = 0; i < row; i++) {
            double value = in.nextDouble();
            for (int j = 0; j < col; j++) {
                arr[i][j] = value + d * j;
            }
        }
        Main.displayDouble(arr);
    }
}
