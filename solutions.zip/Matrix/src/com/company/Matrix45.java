package com.company;

public class Matrix45 {
    public static void main(String[] args) {

        int[][] matrix = {
                {1, 8, 6, 2, 1, 6},
                {2, 7, 5, 4, 5, 6},
                {3, 6, 4, 5, 4, 7},
                {7, 8, 3, 6, 5, 4}
        };
        int max = Integer.MIN_VALUE;
        int maxCol = Integer.MIN_VALUE;
        for (int col = 0; col < matrix[0].length; col++) {
            boolean ascending = true, descending = true;

            for (int row = 0; row < matrix.length - 1; row++) {
                if (!(matrix[row][col] < matrix[row + 1][col])) {
                    ascending = false;
                } else if (!(matrix[row][col] > matrix[row + 1][col])) {
                    descending = false;
                }

                if (maxCol < matrix[row][col]) maxCol = matrix[row][col];

            }
            if ((ascending || descending)) {
                if (ascending)System.out.println("Col at index " + col + " in ascending order");
                else System.out.println("Col at index " + col + " in descending order");

                if (max < maxCol) max = maxCol;
            }
        }
        System.out.println("Maximum element = " + max);
    }
}