package com.company;

public class Matrix32 {
    public static void main(String[] args) {
        int[][] arr = Main.AddElementsInt(3, 5);
        Main.displayInt(arr);
        System.out.println();

        int index = 0;
        for (int i = 0; i < arr.length; i++) {
            int plus = 0;
            int minus = 0;
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] > 0) plus++;
                else if (arr[i][j] < 0) minus++;
            }
            if (plus == minus) {
                index = i + 1;
                System.out.println(index);
                break;
            }
        }
        if (index == 0) System.out.println("Bunday satr yo'q");
    }
}