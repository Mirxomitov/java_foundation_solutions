package com.company;

public class Matrix35 {
    public static void main(String[] args) {
        int[][] arr = {
                {132, 122, 12, 2, 2},
                {12, 2, 36, 46, 51},
                {18, 16, 14, 12, 10},
                {21, 13, 23, 15, 25},
                {12, 13, 14, 25, 17}
        };
        Main.displayInt(arr);
        System.out.println();

        int index = 0;

        for (int i = 0; i < arr.length; i++) {
            boolean isOdd = true;
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] % 2 == 0) {
                    isOdd = false;
                    break;
                }
            }
            if (isOdd) index = i + 1;
        }
        System.out.println(index);
    }
}