package com.company;

public class Matrix13 {

    public static void main(String[] args) {

        double[][] arr = Main.AddElementsDouble(5, 5);
        Main.displayDouble(arr);

        System.out.println();

        for (int col = 0; col < arr.length; col++) {
            for (int row = 0; row < arr.length - col; row++) {
                System.out.print(arr[col][row] + " ");
            }
            System.out.println();
        }
        System.out.println();

        for (int col = arr.length - 1; col > 0; col--) {
            int breaker = 0;
            for (int row = arr.length - col; row < arr.length; row++) {

                int counter = 1;

                while (arr.length - col - counter != 0 && breaker == 0){
                    counter++;
                    System.out.print("     ");
                }
                breaker++;

                System.out.print(arr[row][col] + " ");
            }
            System.out.println();
        }
    }
}
