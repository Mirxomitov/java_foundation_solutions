package com.company;

import java.util.Scanner;

public class Matrix16 {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        System.out.print("M * M matrix   =>   M = ");
        int m = in.nextInt();

        int[][] arr = new int[m][m];
        Main.displayInt(arr);

        System.out.println();

        int N = 1;

        for (int a = 0; a < arr.length / 2; a++) {
            for (int row = a; row < a + 1; row++) {
                for (int col = arr.length - a - 1; col >= a; col--) {
                    arr[row][col] = N;
                    N++;
                }
            }

            for (int i = a + 1; i < arr.length - a; i++) {
                for (int j = a; j < a + 1; j++) {
                    arr[i][j] = N;
                    N++;
                }
            }

            for (int i = arr.length - a - 1; i > arr.length - a - 2; i--) {
                for (int j = a + 1; j < arr.length - a; j++) {
                    arr[i][j] = N;
                    N++;
                }
            }

            for (int i = arr.length - a - 2; i > a; i--) {
                for (int j = arr.length - a - 1; j > arr.length - a - 2; j--) {
                    arr[i][j] = N;
                    N++;
                }
            }
        }
        if (arr.length % 2 != 0) arr[arr.length / 2][arr.length / 2] = N;

        System.out.println("Final Answer : ");
        Main.displayInt(arr);
    }
}
