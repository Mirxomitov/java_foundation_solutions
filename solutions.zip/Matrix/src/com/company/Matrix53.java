package com.company;

public class Matrix53 {
    public static void main(String[] args) {
        int[][] matrix = {
                {12, 20, -3, 4, -5, 0},
                {13, -2, 30, 5, 52, 2},
                {-1, 25, 36, 6, 56, 4},
        };

        // eng oxirgi musbat ustunni aniqlash
        int indexOfCol = -1;
        for (int col = 1; col < matrix[0].length; col++) {
            boolean positive = true;

            for (int row = 0; row < matrix.length; row++) {
                if (!(matrix[row][col] >= 0)) positive = false;
            }
            if (positive) indexOfCol = col;
        }

        //1-ustun va musbat elementli ustunni almashtirish
        for (int row = 0; row < matrix.length; row++) {
            int temp = matrix[row][indexOfCol];
            matrix[row][indexOfCol] = matrix[row][0];
            matrix[row][0] = temp;
        }
        Main.displayInt(matrix);
    }
}