package com.company;

import java.util.Scanner;

public class Matrix18 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int[][] arr = Main.AddElementsInt(5, 6);
        Main.displayInt(arr);

        System.out.print("k = ");
        int k = in.nextInt();

        int sum = 0, multiple = 1;

        for (int col = 0; col < arr[k - 1].length; col++) {
            System.out.println(arr[k - 1][col]);
            sum += arr[k - 1][col];
            multiple *= arr[k - 1][col];
        }
        System.out.println("sum = " + sum);
        System.out.println("multiple = " + multiple);
    }
}
