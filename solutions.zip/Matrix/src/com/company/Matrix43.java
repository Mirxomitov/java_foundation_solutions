package com.company;

public class Matrix43 {
    public static void main(String[] args) {
        int[][] matrix = {
                {1, 2, 6, 6, 4, 5, 9},//0
                {2, 4, 4, 4, 5, 8, 6},//1
                {3, 2, 2, 2, 6, 5, 3} //2
        };

        for (int col = 0; col < matrix[0].length; col++) {
            boolean descending = true;
            for (int row = 0; row < matrix.length - 1; row++) {
                if (!(matrix[row][col] > matrix[++row][col])) {
                    descending = false;
                }
            }
            if (descending) System.out.println(" col at " + col + " - index in descending order ");
        }
    }
}
