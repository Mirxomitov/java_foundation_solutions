package com.company;

import java.util.HashSet;
import java.util.Set;

public class Matrix41 {
    public static void main(String[] args) {
        int[][] matrix = {
                {1, 2, 3}, // 0- satr
                {4, 8, 6}, // 1-satr
                {7, 8, 9}, // 2-satr
        };

        // 1-ustun bir xil
        int index = -1;
        for (int col = 0, colN = Integer.MAX_VALUE; col < matrix[0].length; col++) {
            Set<Integer> set = new HashSet<>();

            for (int row = 0; row < matrix.length; row++) {
                set.add(matrix[row][col]); // faqat bittadan oladi qiymatlarni
            }
            if(set.size() < colN) {
                colN = set.size();
                index = col;
            }
        }
        System.out.println(index);
    }
}