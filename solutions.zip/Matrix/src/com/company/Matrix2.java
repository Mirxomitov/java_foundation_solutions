package com.company;

public class Matrix2 {

    public static void main(String[] args) {
        int m = 4;
        int n = 3;

        double[][] arr = new double[m][n]; // pastga 4 yonga 3

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                arr[i][j] = 5 * j;
            }
        }
        Main.displayDouble(arr);
    }
}
