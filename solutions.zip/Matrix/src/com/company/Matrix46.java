//Teachers answer
package com.company;

public class Matrix46 {
    public static void main(String[] args) {
        double[][] mat = {
                {1, 2, 3, 8}, // 8
                {6, 5, 4, 9}, // 9
                {2, 0, -2, 10}, // 10
        };

        for (int row = 0; row < mat.length; row++) {
            double max = mat[row][0];
            int maxIndexCol = 0;
            int maxIndexRow = 0;
            for (int col = 0; col < mat[row].length; col++) {
                if (mat[row][col] > max) {
                    max = mat[row][col];
                    maxIndexCol = col;
                    maxIndexRow = row;
                }
            }
            if (isSmallInCol(mat, maxIndexCol, maxIndexRow)) {
                System.out.println(mat[maxIndexRow][maxIndexCol]);
            }
        }
    }

    private static boolean isSmallInCol(double[][] mat, int col, int row) {
        double value = mat[row][col];
        // mat[#][col]
        for (int r = 0; r < mat.length; r++) {
            if (row != r && mat[r][col] <= value) {
                return false;
            }
        }
        return true;
    }
}