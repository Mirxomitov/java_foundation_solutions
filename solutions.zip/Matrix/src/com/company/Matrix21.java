package com.company;

import java.util.Scanner;

public class Matrix21 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int[][] arr = Main.AddElementsInt(2, 7);
        Main.displayInt(arr);

        for (int row = 0; row < arr.length; row += 2) {
            int sum = 0;
            for (int i = 0; i < arr[row].length; i++) {
                sum += arr[row][i];
            }
            System.out.print(sum * 1.0 / arr[row].length + "  ");
        }
    }
}
