package com.company;

public class Matrix37 {
    public static void main(String[] args) {

        int[][] matrix= {
            {1,2,3,4,2},
            {1,2,3,4,5},
            {2,2,2,2,2},
            {1,1,1,2,3},
            {1,2,3,4,5}
        };
    }
}