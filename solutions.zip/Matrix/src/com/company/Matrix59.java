package com.company;

import java.util.Scanner;

public class Matrix59 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.print("M (juft son) = ");
        int M;

        do {
            M = in.nextInt();
            if (M % 2 != 0) System.out.print("M = ");
        } while (!(M % 2 == 0));

        System.out.print("N = ");
        int N = in.nextInt();

        double[][] matrix = Main.AddElementsDouble(M, N);
        Main.displayDouble(matrix);

        // i = 0; i < M / 2; i++     va      j = M - 1; ; j--
        // 2 - for column bo'yicha swap qiladi

        for (int i = 0, j = M - 1; i < M / 2; i++, j--) {
            for (int col = 0; col < matrix[0].length; col++) {
                double temp = matrix[i][col];
                matrix[i][col] = matrix[j][col];
                matrix[j][col] = temp;
            }
        }
        System.out.print("Answer : \n");
        Main.displayDouble(matrix);
    }
}
