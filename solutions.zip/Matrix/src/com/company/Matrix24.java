package com.company;

import java.util.Scanner;

public class Matrix24 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int[][] arr = Main.AddElementsInt(4, 3);
        Main.displayInt(arr);

        for (int i = 0; i < arr[0].length; i++) {
            int max = Integer.MIN_VALUE;
            for (int j = 0; j < arr.length; j++) {
                if (max < arr[j][i]) max = arr[j][i];
            }
            System.out.println(max + " ");
        }

    }
}
