package com.company;

import java.util.Arrays;

public class Matrix47 {
    public static void main(String[] args) {

        int[][] matrix = {
                {1, 2, 3, 4, 5},
                {2, 3, 4, 5, 6},
                {5, 6, 7, 8, 9},
                {4, 5, 6, 7, 8},
                {3, 4, 5, 6, 7},
        };

        int k1 = 2;
        int k2 = 4;

        for (int col = 0; col < matrix[0].length; col++) {
            int temp = matrix[k1][col];

            matrix[k1][col] = matrix[k2][col];
            matrix[k2][col] = temp;
        }
        Main.displayInt(matrix);
    }
}


class matrix_47 {
    public static void main(String[] args) {
        int[][] matrix = {
                {8, 9, 9, 15, 16, 17, 19},
                {2, 6, 10, 14, 15, 15, 18},//1
                {6, 7, 10, 10, 14, 16, 17},
                {5, 8, 12, -1, 3, 7, -4},//3
        };
        int k1 = 1;
        int k2 = 2;

        int[] temp = matrix[k1];
        matrix[k1] = matrix[k2];
        matrix[k2] = temp;
        System.out.println(Arrays.deepToString(matrix));
    }
}
