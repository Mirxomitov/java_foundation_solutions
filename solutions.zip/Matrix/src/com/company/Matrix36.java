package com.company;

import java.util.Arrays;

public class Matrix36 {
    public static void main(String[] args) {
        int[][] matrix = {
                {7, 7, 5, 6}, // o'xshash
                {5, 7, 7, 5},
                {7, 6, 5, 6}, // o'xshash
                {7, 7, 7, 7},
        };
        // 1. matrix[0][#] => alohida massivga saqlab olinsin. int[] massiv = new int[matrix[0].length]
        // 2. matrix[1-matrix.length][#] -> matrix[row][col] in massiv ? o'xshash counter++ else break;
        int[] first_row = matrix[0]; // refernce ob qo'ydi
        int counter = 0;

        for (int row = 1; row < matrix.length; row++) {
            boolean same = true;
            for (int col = 0; col < matrix[row].length; col++) {
                if (!contains(first_row, matrix[row][col])) {
                    same = false;
                }
            }
            if (same) {
                counter++;
                System.out.println(Arrays.toString(matrix[row]));
            }
        }

        System.out.println(counter);

    }

    public static boolean contains(int[] arr, int value) {
        for (int val : arr) {
            if (val == value) return true;
        }
        return false;
    }
}