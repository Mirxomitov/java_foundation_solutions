package com.company;

public class Human {
    int age = 18;

    public static void main(String[] args) {
        Human Tohir = new Human();
        System.out.println(Tohir.age);
    }

    int gerAge() {
        return age;
    }
}
