package com.company;

import java.util.Scanner;

public class Matrix15 {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        System.out.print("M * M matrix   =>   M = ");
        int m = in.nextInt();

        int[][] arr = new int[m][m];
        Main.displayInt(arr);

        System.out.println();

        int N = 1;

        for (int a = 0; a < arr.length / 2; a++) {
            for (int row = a; row < a + 1; row++) {
                for (int col = a; col < arr.length - a; col++) {
                    arr[row][col] = N;
                    N++;
                }
            }

            for (int i = arr.length - a - 1; i > arr.length - a - 2; i--) {
                for (int j = a + 1; j < arr.length - a; j++) {
                    arr[j][i] = N;
                    N++;
                }
            }

            for (int i = arr.length - a - 1; i > arr.length - a - 2; i--) {
                for (int j = arr.length - a - 2; j >= a; j--) {
                    arr[i][j] = N;
                    N++;
                }
            }

            for (int i = a; i < a + 1; i++) {
                for (int j = arr.length - a - 2; j > a; j--) {
                    arr[j][i] = N;
                    N++;
                }
            }
        }
        if (arr.length % 2 != 0) arr[arr.length / 2][arr.length / 2] = N;

        System.out.println("\nFinal Answer : ");
        Main.displayInt(arr);
    }
}
