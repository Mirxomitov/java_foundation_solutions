package com.company;

public class Matrix33 {
    public static void main(String[] args) {
        int[][] arr = {
                { 1,   2,  -1,  -2,   0},
                { 1,   2,   3,   4,   5},
                {-1,  -1,   1,   1,   0},
                { 2,   2,   2,   2,  -2},
                { 0,   0,   1,   2,   0}
        };
        Main.displayInt(arr);
        System.out.println();

        int index = 0;
        for (int i = 0; i < arr[0].length; i++) {
            int plus = 0;
            int minus = 0;
            for (int j = 0; j < arr.length; j++) {
                if (arr[j][i] > 0) plus++;
                else if (arr[j][i] < 0) minus++;
            }
            if (plus == minus) {
                index = i + 1;
            }
        }
        System.out.println(index);
    }
}