package com.company;

import java.util.Scanner;

public class Matrix7 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double[][] arr = Main.AddElementsDouble(4,3);
        Main.displayDouble(arr);
        System.out.println("k = ");
        int k = in.nextInt();

        for (int i = 0; i < arr[k].length; i++) {
            System.out.print(arr[k - 1][i] + " ");
        }
    }
}
