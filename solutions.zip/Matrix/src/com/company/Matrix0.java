package com.company;

public class Matrix0 {

    public static void main(String[] args) {

        double[][] arr = Main.AddElementsDouble(5, 5);
        Main.displayDouble(arr);

        System.out.println();

        for (int row = 0; row < arr.length; row++) {
            for (int col = 0; col < arr[row].length - row; col++) {
                System.out.print(arr[row][col] + " ");
            }
            System.out.println();
        }
        System.out.println();

        for (int row = 1; row < arr.length; row++) {
            int count = 0;
            for (int col = arr.length - row; col < arr.length; col++) {

                int space = row;
                if (count == 0) {
                    do {

                        System.out.print("     ");
                        space++;

                    } while (arr.length - space > 0);
                }
                count++;

                System.out.print(arr[row][col] + " ");
            }
            System.out.println();
        }
    }
}
