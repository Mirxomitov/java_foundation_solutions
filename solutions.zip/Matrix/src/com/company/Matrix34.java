package com.company;

public class Matrix34 {
    public static void main(String[] args) {
        int[][] arr = {
                {132, 122, 12, 2, 2},
                {12, 2, 36, 46, 51},
                {18, 16, 14, 12, 14},
                {21, 22, 23, 24, 25},
                {12, 13, 14, 25, 17}
        };
        Main.displayInt(arr);
        System.out.println();

        int index = 0;

        for (int i = 0; i < arr.length; i++) {
            boolean isEven = true;
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] % 2 != 0) {
                    isEven = false;
                    break;
                }
            }
            if (isEven) index = i + 1;
        }
        if (index == 0) System.out.println("Bunday satr yo'q");
        else System.out.println(index);
    }
}