package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class matrix_51 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[][] matrix = {
                {8, 5, 9, 15,},///15
                {6, 100, 11, 7,},//100
                {7, 6, 11, 10,},//11
                {5, 8, 12, 71,},//71
        };
        //       5   5   9   7

        int max = Integer.MIN_VALUE;
        int min = Integer.MAX_VALUE;
        for (int row = 0; row < matrix.length; row++) {
            int indexOfMax = -1;
            int indexOfMin = -2;

            for (int col = 0; col < matrix[0].length; col++) {
                if (matrix[row][col] >= max) {
                    max = matrix[row][col];
                    indexOfMax = row;
                }
                if (matrix[row][col] < min) {
                    min = matrix[row][col];
                    indexOfMin = row;
                }
            }
            if (indexOfMax == indexOfMin) {
                int[] temp = matrix[indexOfMax];
                matrix[indexOfMax] = matrix[indexOfMin];
                matrix[indexOfMin] = temp;
            }
            System.out.println(Arrays.deepToString(matrix));
        }
    }
}