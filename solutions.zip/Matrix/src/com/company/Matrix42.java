package com.company;

public class Matrix42 {
    public static void main(String[] args) {
        int[][] matrix = {
                {1,2,3,4,5,6},//0
                {2,4,6,5,8,9},//1
                {6,1,9,2,5,4},//2
                {3,0,1,2,3,4},//3
                {1,2,3,4,5,7} //4
        };

        for (int row = 0; row < matrix.length; row++) {
            boolean ascending = true;
            for (int col = 0; col < matrix[0].length - 1; col++) {
                if (!(matrix[row][col] < matrix[row][col + 1])){
                    ascending = false;
                }
            }
            if (ascending) System.out.println(" row at " + row + " - index in ascending order ");
        }
    }
}
