package com.company;

import java.util.Scanner;

public class Matrix27_2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int[][] arr = Main.AddElementsInt(2, 3);
        Main.displayInt(arr);

        int minSum = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;

        int index = -1;

        for (int i = 0; i < arr.length; i++) {
            int sum = 0;
            for (int j = 0; j < arr[i].length; j++) {
                sum += arr[i][j];
            }
            if(sum < minSum) {
                index = i;
                minSum = sum;
            }
        }
        System.out.println(minSum);

        for (int j = 0; j < arr[index].length; j++) {
            if (max < arr[index][j]) max = arr[index][j];
        }
        System.out.println(max);
    }
}
