package com.company;

public class Matrix44 {
    public static void main(String[] args) {

        int[][] matrix = {
                {1, 3, 4, 2, 1, 6},
                {1, 2, 3, 4, 5, 6},
                {3, 2, 1, 5, 4, 7},
                {9, 8, 7, 6, 5, 4}
        };
        int min = Integer.MAX_VALUE;
        int minCol = Integer.MAX_VALUE;
        for (int row = 0; row < matrix.length; row++) {
            boolean ascending = true, descending = true;

            for (int col = 0; col < matrix[0].length - 1; col++) {
                if (!(matrix[row][col] < matrix[row][col + 1])) {
                    ascending = false;
                } else if (!(matrix[row][col] > matrix[row][col + 1])) {
                    descending = false;
                }

                if (minCol > matrix[row][col]) minCol = matrix[row][col];

            }
            if ((ascending || descending)) {
                if (ascending)System.out.println("Row at index " + row + " in ascending order");
                else System.out.println("Row at index " + row + " in descending order");

                if (min > minCol) min = minCol;
            }
        }
        System.out.println("Minimum element = " + min);
    }
}