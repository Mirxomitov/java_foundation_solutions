package com.company;

import java.util.Scanner;

public class Pr6 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a, b;

        System.out.print("a=");
        a = in.nextInt();
        System.out.print("b=");
        b = in.nextInt();

        boolean c ;
        c = ((a % 2 == 0) || (b % 2 == 0)) && ((a % 2 != 0) || (b % 2 != 0));

        System.out.println("biri toq, boshqasi juft bo'lsa true chiqarilsin:\n" + c);
    }
}
