package com.company;

import java.util.Scanner;

public class Pr4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a;

        System.out.print("a=");
        a = in.nextInt();

        boolean b = a % 2 == 0;

        System.out.println("a juft bo'lsa true yo'qsa false:\n" + b);
    }
}
