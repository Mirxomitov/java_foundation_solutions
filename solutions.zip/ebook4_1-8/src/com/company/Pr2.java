package com.company;

import java.util.Scanner;

public class Pr2 {
    public static void main(String[] args) {
        double a, b;
        Scanner in = new Scanner(System.in);

        a = in.nextDouble();
        b = in.nextDouble();

        boolean natija = a < 0 || b < 0;
        System.out.println(natija);

    }
}
