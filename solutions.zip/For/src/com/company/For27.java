package com.company;

import java.util.Scanner;

public class For27 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double x = in.nextDouble();
        int N = in.nextInt();

        double sum = 0;
        int multi1 = 1, multi2 = 1;

        for (int i = 1; i <= N; i++) {

            multi2 *= 2 * i - 1;
            multi1 *= 2 * i;
            sum += multi2 * Math.pow(x, 2 * i + 1) / (multi1 * (2 * i + 1));

        }
        System.out.println(x + sum);
    }
}
