package com.company;

import java.util.Scanner;

public class For17 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a = in.nextInt();
        int n = in.nextInt();
        double i;
        int sum = 0;

        for (i = 0; i <= n; i++){
            sum += Math.pow(a, i);
        }
        System.out.println(sum);
    }
}
