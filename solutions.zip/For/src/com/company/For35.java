package com.company;

import java.util.Scanner;

public class For35 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        double a1 = 1;
        double a2 = 2;
        double a3 = 3;

        System.out.println(a1);
        System.out.println(a2);
        System.out.println(a3);

        for (int i = 4; i <= n; i++) {
            double a;
            a = a3 + a2 - 2 * a1;
            a1 = a2;
            a2 = a3;
            a3 = a;

            System.out.println(a);
        }
    }
}
