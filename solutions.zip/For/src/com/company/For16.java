package com.company;

import java.util.Scanner;

public class For16 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a = in.nextDouble();
        int n = in.nextInt();
        int i;
        double s = 1;

        for (i = 1; i <= n; i++){
            s *= a;
            System.out.println(s);
        }
    }
}
