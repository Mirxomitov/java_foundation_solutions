package com.company;

import java.util.Scanner;

public class For30 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();
        double a = in.nextDouble();
        double b = in.nextDouble();
        double x, Fx;
        int i;

        for (i = 0; i <= n; i++) {

            x = a + (b - a) * i / n;
            Fx = 1 - Math.sin(x);
            System.out.println(Fx);
        }
    }
}
