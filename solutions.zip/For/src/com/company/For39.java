package com.company;

import java.util.Scanner;

public class For39 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a = in.nextInt();
        int b = in.nextInt();

        for (int i = 1; i <= b - a + 1; i++) {

            for (int j = 1; j <= i; j++) {
                System.out.println(i);
            }
        }
    }
}
