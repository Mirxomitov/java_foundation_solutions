package com.company;

import java.util.Scanner;

public class For21 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        double i;
        double s = 1;
        double sum = 0;

        for (i = 1; i <= n; i++){
            s *= i;
            sum += 1/s;

        }
        System.out.println(sum + 1);
    }
}
