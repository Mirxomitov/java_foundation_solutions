package com.company;

import java.util.Scanner;

public class For6 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a = in.nextDouble();
        double i;

        for (i = 12; i <= 20 ; i+=2)
            System.out.println(i/10 + " kg konfet narxi = " + i / 10 * a);
        }
}
