package com.company;

import java.util.Scanner;

public class For22 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double x = in.nextDouble();
        int n = in.nextInt();

        int i, s = 1;
        double sum = 0, Mult = 1;

        for (i = 1; i <= n; i++){

            s *= i;
            Mult *= x;
            sum += Mult / s;

        }
        System.out.println(sum + 1);
    }
}