package com.company;

import java.util.Scanner;

public class For15 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a = in.nextInt();
        int n = in.nextInt();
        int i;
        int s = 1;

        for (i = 1; i <= n; i++){
            s *= a;
        }
        System.out.println(s);
    }
}
