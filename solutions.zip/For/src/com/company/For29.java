package com.company;

import java.util.Scanner;

public class For29 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a = in.nextDouble();
        double b = in.nextDouble();
        int n = in.nextInt();

        double h;
        double i;

        h = (b - a) / n;

        for (i = 1; i <= n; i++) {
            System.out.println(a);
            a += h;
        }
        System.out.println(a);
    }
}
