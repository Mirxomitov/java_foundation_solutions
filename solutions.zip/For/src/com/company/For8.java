package com.company;

import java.util.Scanner;

public class For8 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a = in.nextInt();
        int b = in.nextInt();

        int i;
        int multiplication = 1;

        for (i = a; i <=b; i++){
            multiplication *= i;
        }
        System.out.println(multiplication);
    }
}
