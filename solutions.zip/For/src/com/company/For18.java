package com.company;

import java.util.Scanner;

public class For18 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a = in.nextInt();
        int n = in.nextInt();
        int i;
        double sum = 0;

        for (i = 0; i <= n; i++){
            sum += Math.pow(-1, i) * Math.pow(a, i);
        }
        System.out.println("daraja = " + Math.pow(a, i - 1));
        System.out.println(sum);
    }
}
