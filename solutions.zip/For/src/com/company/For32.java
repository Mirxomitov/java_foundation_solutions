package com.company;

import java.util.Scanner;

public class For32 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        double a0 = 1;
        double a = 0;

        for (int i = 1; i <= n; i++) {
            a = (a0 + 1) / i;
            a0 = a;
            System.out.println(a);
        }
    }
}
