package com.company;

import java.util.Scanner;

public class For13 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        int i;
        double s1 = 0;

        for (i = 11; i < (n + 11); i++){

            s1 += Math.pow(-1, i - 1) * i / 10.0;

        }
        System.out.println(s1);
    }
}
