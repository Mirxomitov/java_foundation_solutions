package com.company;

import java.util.Scanner;

public class For14 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        int i;
        int s = 0;

        for (i = 1; i <= n; i++){

            s += 2 * i - 1;

            System.out.println(s);
        }
    }
}
