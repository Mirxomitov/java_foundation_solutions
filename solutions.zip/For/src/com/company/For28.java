package com.company;

import java.util.Scanner;

public class For28 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double x = in.nextDouble();
        int n = in.nextInt();

        double sum = 0, multi1 = 1, multi2 = 1, k = 2;


        for (int i = 1; i <= n; i++) {

            multi1 *= 2 * i - 3;
            multi2 *= k; // 2

            k += 2;

            if( i == 0) sum += -multi1 * Math.pow(x, i) / multi2;
            else sum += Math.pow(-1, i) * multi1 * Math.pow(x, i) / multi2;
        }
        System.out.println(1 + sum);
    }
}
