package com.company;

import java.util.Scanner;

public class For38 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        double sum = 0;

        for (int i = 1; i <= n; i++) {

            double a = 1;
            for (int j = 1; j <= n - i + 1; j++) {
                a *= i;
            }
            sum += a;
        }
        System.out.println(sum);
    }
}
