package com.company;

import java.util.Scanner;

public class For12 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        int i;
        double s = 1;

        for (i = 11; i < (n + 11); i++){
            s *= i/10.0;
        }
        System.out.println(s);
    }
}
