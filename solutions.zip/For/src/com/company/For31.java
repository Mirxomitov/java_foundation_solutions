package com.company;

import java.util.Scanner;

public class For31 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        double a0 = 2;
        double a = 0;

        for (int i = 1; i <= n; i++) {
            a = 2 + 1.0 / a0;
            a0 = a;
            System.out.println(a);
        }
    }
}
