package com.company;

import java.util.Scanner;

public class For33 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        double f0 = 0;
        double f1 = 1;
        double f2 = 1;

        for (int i = 0; i < n; i++) {

            f0 = f1;
            f1 = f2;
            f2 = f0 + f1;

            System.out.println(f0);
        }
    }
}
