package com.company;

import java.util.Scanner;

public class For5 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a = in.nextDouble();
        double i;

        for(i = 1; i <= 10; i++){

            System.out.println((i / 10) + " kg konfet narxi = " + i * (a / 10));
        }
    }
}
