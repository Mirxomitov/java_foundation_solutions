package com.company;

import java.util.Scanner;

public class For10 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

         int n = in.nextInt();

        int i;
        double s = 0;

        for (i = 1; i <= n; i++){
            s += 1.0 / i;
        }
        System.out.println(s);
    }
}
