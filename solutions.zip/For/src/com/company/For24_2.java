package com.company;

import java.util.Scanner;

public class For24_2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double x = in.nextDouble();
        int n = in.nextInt();

        int fact = 1;
        double sum = 0;

        for (int i = 0; i < n; i++) {
            if (i == 0) fact = 1;
            else fact *= 2 * i * (2 * i - 1);

            if(i == 0) sum = 1;
            else sum += Math.pow(-1, i) * Math.pow(x, 2 * i) / fact;
        }
        System.out.println(sum);
    }
}
