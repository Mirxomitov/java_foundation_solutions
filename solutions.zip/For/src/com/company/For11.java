package com.company;

import java.util.Scanner;

public class For11 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        int i;
        double s = 0;

        for (i = n; i <= 2 * n; i++){
            s += Math.pow(i, 2);
        }
        System.out.println(s);
    }
}
