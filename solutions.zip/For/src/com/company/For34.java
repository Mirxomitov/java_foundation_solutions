package com.company;

import java.util.Scanner;

public class For34 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();
        double a1 = 1;
        double a2 = 2;

        System.out.println(a1);
        System.out.println(a2);

        for (int i = 2; i < n; i++) {

            double a;
            a = (a1 + 2 * a2) / 3;
            System.out.println(a);

            a1 = a2;
            a2 = a;

        }
    }
}
