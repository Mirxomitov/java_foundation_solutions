package com.company;

import java.util.Scanner;

public class For9 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a = in.nextInt();
        int b = in.nextInt();

        int i;
        int sum_square = 0;

        for(i = a; i <= b; i++){

        sum_square += i*i;
        }
        System.out.println(sum_square);
    }
}
