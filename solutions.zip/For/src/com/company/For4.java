package com.company;

import java.util.Scanner;

public class For4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a = in.nextDouble();
        int i;
        for(i = 1; i <= 10 ; i++){
            System.out.println(i +  "kg shokolad narxi = " + i * a);
        }

    }
}
