package com.company;

import java.util.Scanner;

public class For19 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double n = in.nextInt();
        int i;
        double s = 1;

        for (i = 1; i <= n; i++){
            s *= i;
        }
        System.out.println(s);
    }
}
