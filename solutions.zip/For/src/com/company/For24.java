package com.company;

import java.util.Scanner;

public class For24 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double x = in.nextDouble();
        int n = in.nextInt();

        double X = 1;
        double I = 1;
        double sum = 0;
        int i1 = 1;
        int Counter = 1;

        for (int i = 2; i <= n + 1; i += 2) {

            I *= i * i1;
            i1 += 2;

            X *= x * x;

            if (Counter % 2 != 0) sum -= X / I;
            if (Counter % 2 == 0) sum += X / I;

            Counter++;
        }
        System.out.println("sum = " + (1 + sum));
    }
}
