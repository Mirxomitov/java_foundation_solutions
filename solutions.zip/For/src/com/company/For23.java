package com.company;

import java.util.Scanner;

public class For23 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double x = in.nextDouble();
        int n = in.nextInt();

        double Mx = 1;
        int fact = 1;

        for (int i = 0; i <= n; i++) {

            if (i == 0) fact = 1;
            else fact *= (2 * i) * (2 * i + 1);

            if (i == 0) Mx = x;
            else Mx += Math.pow(-1, i) * Math.pow(x, 2 * i + 1) / fact;
        }
        System.out.println("sum = " + Mx);
    }
}
