package com.company;

import java.util.Scanner;

public class For26 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double x = in.nextDouble();
        int n = in.nextInt();
        double sum = 0;
        int k = 0;

        for (int i = 0; i <= n; i++) {
            sum += Math.pow(-1, k) * Math.pow(x, 2 * k + 1) / (2 * k + 1);
            k++;
        }
        System.out.println(sum);
    }
}
