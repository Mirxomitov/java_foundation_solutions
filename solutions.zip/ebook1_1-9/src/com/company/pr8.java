//Muallif: Mirxomitov Tohir
//Sana:13.11.2022
//Maqsad:Umumiy qarshilikni topish
package com.company;

import java.util.Scanner;

public class pr8 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double r, r1, r2, r3;

        System.out.print("r1=");
        r1 = num.nextDouble();
        System.out.print("r2=");
        r2 = num.nextDouble();
        System.out.print("r3=");
        r3 = num.nextDouble();

        r = r1 * r2 * r3 * (r1 * r2 + r2 * r3 + r1 * r3);

        System.out.println("Umumiy qarshilik R=" + r);
    }
}
