//Muallif: Mirxomitov Tohir
//Sana:13.11.2022
//Maqsad:2 idishdagi suvni aralashtirishdan hosil bo'lgan suvning hajmi va haroratini aniqlash
package com.company;

import java.util.Scanner;

public class pr7 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double t1, t2, v1, v2, t;

        System.out.print("t1=");
        t1 = num.nextDouble();
        System.out.print("t2=");
        t2 = num.nextDouble();
        System.out.print("v1=");
        v1 = num.nextDouble();
        System.out.print("v2=");
        v2 = num.nextDouble();

        t = ((v1 + v2) * t2 + v1 * t1) / (2 *v1 + v2);

        System.out.println("t=" + t);
        System.out.println("V=" + (v1 + v2));
    }

}
