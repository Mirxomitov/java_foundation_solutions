//Muallif: Mirxomitov Tohir
//Sana:13.11.2022
//Maqsad:To'g'ri burchakli uchburchak gipotenuzasisi va yuzasini aniqlash
package com.company;

import java.util.Scanner;

public class pr2 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a, b;

        System.out.print("a=");
        a = num.nextDouble();
        System.out.print("b=");
        b = num.nextDouble();

        System.out.println("To'g'ri burchakli uchburchak gipotenuzasisi  c=" + Math.sqrt(a * a + b * b));
        System.out.println("To'g'ri burchakli uchburchak yuzasi S=" + a * b / 2);
    }
}
