//Muallif: Mirxomitov Tohir
//Sana:13.11.2022
//Maqsad:H balandlikdan erkin tushgan jismning uchish vaqtini aniqlash
package com.company;

import java.util.Scanner;

public class pr4 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double h;
        final double g = 10;

        System.out.print("Balandlik H=");
        h = num.nextDouble();

        System.out.println("t = " + Math.sqrt(2 * h / g));
    }
}



