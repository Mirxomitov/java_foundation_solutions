//Muallif: Mirxomitov Tohir
//Sana:13.11.2022
//Maqsad:Ifodaning qiyamtini topish
package com.company;

import java.util.Scanner;

public class pr9 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);
        double x, y;
        System.out.print("x=");
        x = num.nextDouble();
        System.out.print("y=");
        y = num.nextDouble();

        System.out.println("([x] - [y]) / (1 + [xy]) = " +  (Math.abs(x) - Math.abs(y)) / (1 + Math.abs(x * y)));

    }
}

