//Muallif: Mirxomitov Tohir
//Sana:13.11.2022
//Maqsad:Ikki sonning o'rta arifmetigi va o'rta geometrigini aniqlash
package com.company;

import java.util.Scanner;

public class pr3 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a, b;

        System.out.print("a=");
        a = num.nextDouble();
        System.out.println("b=");
        b = num.nextDouble();

        System.out.println("o'rta arifmetigi=" + (a / 2 + b / 2));
        System.out.println("o'rta geometrigi=" + Math.sqrt(a * b));

    }
}

