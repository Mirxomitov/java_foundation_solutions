//Muallif: Mirxomitov Tohir
//Sana:13.11.2022
//Maqsad:Kubning hajmi va to'la sirtini aniqlash
package com.company;

import java.util.Scanner;

public class pr1 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a;

        System.out.print("kub tomoni a=");
        a = num.nextDouble();

        System.out.println("Hajmi V=" + a * a * a);
        System.out.println("To'la sirti=" + 6 * a * a);
    }
}
