//Muallif: Mirxomitov Tohir
//Sana:13.11.2022
//Maqsad:Teng tomonli uchburchakning yuzini hisoblash

package com.company;

import java.util.Scanner;

public class pr5 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a;

        System.out.print("Uchburchak tomoni a=");
        a = num.nextDouble();

        System.out.println("S=" + a * a * Math.sqrt(3) / 4);
    }

}
