//Muallif: Mirxomitov Tohir
//Sana:13.11.2022
//Maqsad:Mayatninkning tebranish davrini aniqlash

package com.company;

import java.util.Scanner;

public class pr6 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double L;
        final double g = 10;

        System.out.print("L=");
        L = num.nextDouble();

        System.out.println("T=" + 2 * Math.PI * Math.sqrt(L / g));
    }
}
