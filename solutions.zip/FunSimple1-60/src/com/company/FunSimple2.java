package com.company;

import java.util.Scanner;

public class FunSimple2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double a = in.nextDouble();
        double b = in.nextDouble();
        double c = in.nextDouble();
        PowerA234(a);
        PowerA234(b);
        PowerA234(c);
    }

    static void PowerA234(double n) {
        System.out.println(n * n);
        System.out.println(n * n * n);
        System.out.println(n * n * n * n);
    }
}
