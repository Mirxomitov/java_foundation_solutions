package com.company;

import java.util.Scanner;

public class FunSimple4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b, c;
        a = in.nextDouble();
        b = in.nextDouble();
        c = in.nextDouble();
        Triangle(a);
        Triangle(b);
        Triangle(c);

    }
    static void Triangle(double n) {
        double S, P;
        P = 3 * n;
        S = Math.sqrt(3) * n * n / 4;
        System.out.println(S);
        System.out.println(P);
    }
}
