package com.company;

public class FunSimple25 {
    public static void main(String[] args) {

        IsSquare(25);
    }

    static void IsSquare(int A) {
        if (Math.sqrt(A) % 1 == 0) {
            System.out.println("Kvadrati");
        } else System.out.println("Kvadrati emas");
    }
}


