package com.company;

import java.util.Scanner;

public class FunSimple27 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("nechta son kiritasiz ");
        int n = in.nextInt();

        int Counter = 0;

        for (int i = 0; i < n; i++) {
            System.out.println((i + 1) + "- sonni kiriting :");
            int A = in.nextInt();
            if (IsPower5(A) == true) {
                Counter++;
            }
        }
        System.out.println("Counter = " + Counter);
    }

    static boolean IsPower5(double K) {

        int a = 1;
        for (int i = 0; i <= Math.sqrt(K); i++) {
            a *= 5;

            if (a == K) {
                return true;
            }
        }
        return false;
    }
}

