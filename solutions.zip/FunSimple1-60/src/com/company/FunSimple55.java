package com.company;

import java.util.Scanner;

public class FunSimple55 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        for (int i = 0; i < 3; i++) {

            int date = in.nextInt();
            int month = in.nextInt();
            int year = in.nextInt();

            NextDate(date, month, year);
        }

    }

    static void NextDate(int d, int m, int y) {
        int temp_y = y;

        if ((y % 100 == 0 || y % 200 == 0 || y % 300 == 0) && y % 400 != 0) y = 0;
        else if (y % 4 == 0 || y % 400 == 0) y = 1;
        else y = 0;

        switch (m) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
                if (d == 31) {
                    m += 1;
                    d = 1;
                } else d += 1;
                break;

            case 4:
            case 6:
            case 9:
            case 11:
                if (d == 30) {
                    m += 1;
                    d = 1;
                } else d += 1;
                break;

            case 2:
                if ((y == 0 && d == 28) || (y == 1 && d == 29)) {
                    m += 1;
                    d = 1;
                } else d += 1;
                break;

            case 12:
                if (d == 31) {
                    d = 1;
                    m = 1;
                    temp_y += 1;
                }
                break;
            default:
                System.out.println("Yilda 12 oy mavjud !");
        }

        System.out.println(d);
        System.out.println(m);
        System.out.println(temp_y);
    }
}
