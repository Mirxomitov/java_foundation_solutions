package com.company;

import java.util.Scanner;

class FunSimple21 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a, b;
        a = in.nextInt();
        b = in.nextInt();
        SumRange(a, b);
    }

    static double SumRange(int a, int b) {

        int sum = 0;
        for (int i = a; i <= b; i++) {
            sum += i;
        }
        System.out.println(sum);
        return 0;
    }

}


