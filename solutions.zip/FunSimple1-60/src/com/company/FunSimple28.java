package com.company;

import java.util.Scanner;

public class FunSimple28 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
int Counter = 0;
        System.out.println("nechta son kiritasiz ");
        int n = in.nextInt();

        for (int i = 0; i < n; i++) {
            int son = in.nextInt();
            if(IsPrime(son) == true) Counter++;
        }
        System.out.println(Counter);
    }

    static boolean IsPrime(double N) {
        for (int i = 2; i < N ; i++) {
            if (N % i == 0) return false;
        }

        return true;
    }
}

