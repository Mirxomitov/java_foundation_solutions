package com.company;

import java.util.Scanner;

public class FunSimple6 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a = in.nextInt();
        DigitCountSum(a);
        int b = in.nextInt();
        DigitCountSum(b);
        int c = in.nextInt();
        DigitCountSum(c);

    }

    static void DigitCountSum(int son) {
        int  sum = 0, soni = 0;
        while (son > 0){

            sum += son % 10;

            son /= 10;
            soni++;
        }
        System.out.println("soni = " + soni);
        System.out.println("sum =" + sum);
    }

}
