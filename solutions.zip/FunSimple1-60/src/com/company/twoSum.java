package com.company;

import java.util.Arrays;

public class twoSum {
    public static void main(String[] args) {
//        int[] nums = {2,6,5,7,5};
//        int target = 9;
//
//        int[] nums2 = new int[2];
//
//        for (int i = 0; i < nums.length; i++) {
//            for (int j = i + 1; j < nums.length; j++) {
//                if (nums[i] + nums[j] == target){
//                    nums2[0] = i;
//                    nums2[1] = j;
//                }
//            }
//        }
//        System.out.println(Arrays.toString(nums2));

    }
}

class Solution {
    public int divide(int dividend, int divisor) {

        if (dividend == 0) return 0;
        if (divisor == 1) return dividend;
        if (divisor == -1) return -dividend;

        int a = Math.abs(dividend);
        int b = Math.abs(divisor);

        int counter = 0;

        while (a >= b) {
            a -= b;
            counter++;
        }

        if (dividend > 0 && divisor > 0 || dividend < 0 && divisor < 0)return counter;
        if (dividend > 0 && divisor < 0 || dividend < 0 && divisor > 0)return -counter;
        else return Integer.MAX_VALUE;
    }
}
