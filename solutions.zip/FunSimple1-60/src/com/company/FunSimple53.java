package com.company;

import java.util.Scanner;

public class FunSimple53 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int year = in.nextInt();

        for (int i = 0; i < 3; i++) {
            int month = in.nextInt();

            if (month >= 1 && month <= 12) System.out.println(MonthsDays(month, year));
            else System.out.println("Yilda 12 oy mavjud !");
        }
    }

    public static int MonthsDays(int m, int y) {

        if ((y % 100 == 0 || y % 200 == 0 || y % 300 == 0) && y % 400 != 0) y = 0;
        else if (y % 4 == 0 || y % 400 == 0) y = 1;
        else y = 0;

        switch (m) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                return 31;
            case 4:
            case 6:
            case 9:
            case 11:
                return 30;
        }
        if (y == 0 && m == 2) return 28;
        else if (y == 1 && m == 2) return 29;
        return 0;
    }
}