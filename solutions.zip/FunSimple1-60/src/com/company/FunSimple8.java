package com.company;

public class FunSimple8 {
    public static void main(String[] args) {
        RightDigit(15, 5);
    }
    static int RightDigit(int newnum,int R){

        newnum = newnum * 10 + R;

        System.out.println(newnum);
        return newnum;
    }
}
