package com.company;

import java.util.Scanner;

public class FunSimple29 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        for (int i = 0; i < 5; i++) {
            int K = in.nextInt();
            System.out.println(DigitCount(K));
        }
    }

    static int DigitCount(int son) {
        int Counter = 0;
        while (son > 0) {
            son /= 10;
            Counter++;
        }
        return Counter;
    }
}
