package com.company;

import java.util.Scanner;

public class FunSimple18 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b, c;
        System.out.print("R1 = ");
        a = in.nextDouble();
        CircleS(a);
        System.out.print("R2 = ");
        b = in.nextDouble();
        CircleS(b);
        System.out.print("R3 = ");
        c = in.nextDouble();
        CircleS(c);
    }

    static double CircleS(double R) {

        double S = 3.14 * R * R;

        System.out.print(S);
        return 0;
    }
}