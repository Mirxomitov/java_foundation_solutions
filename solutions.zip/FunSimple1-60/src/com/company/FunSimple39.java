package com.company;

import java.util.Scanner;

public class FunSimple39 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("A = ");
        double a = in.nextDouble();
        for (int i = 0; i < 3; i++) {
            System.out.print("N = ");
            double b = in.nextDouble();
            if(b % 1 == 0) System.out.println(Power2(a, b));
            else System.out.println(Power1(a, b));
        }

    }
    static double Power2(double A, double N) {
        double multiplication = 1;

        if (N >= 0) {
            for (int i = 0; i < N; i++) {
                multiplication *= A;
            }
        }
        else {
            for (int i = -1; i >= N; i--) {
                multiplication /= A;
            }
        }
        return multiplication;
    }
    static double Power1(double A, double B) {
        double c = Math.pow(A, B);
        return c;
    }
}
