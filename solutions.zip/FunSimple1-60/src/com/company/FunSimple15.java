package com.company;

import java.util.Scanner;

public class FunSimple15 {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        int a1, b1, c1;

        System.out.print("a1 = ");
        a1 = in.nextInt();
        System.out.print("b1 = ");
        b1 = in.nextInt();
        System.out.print("c1 = ");
        c1 = in.nextInt();

        ShiftLeft3(a1, b1, c1);
        int a2, b2, c2;
        System.out.print("a2 = ");
        a2 = in.nextInt();
        System.out.print("b2 = ");
        b2 = in.nextInt();
        System.out.print("c2 = ");
        c2 = in.nextInt();

        ShiftLeft3(a2, b2, c2);

    }

    static void ShiftLeft3(int a, int b, int c) {

        int temp = a;
        a = b;
        b = c;
        c = temp;

        System.out.println(a);
        System.out.println(b);
        System.out.println(c);

    }
}