package com.company;

import java.util.Scanner;

public class FunSimple1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a = in.nextDouble();
        System.out.println(PowerA3(a));
    }
    static double PowerA3(double n){
        return n * n * n;
    }
}
