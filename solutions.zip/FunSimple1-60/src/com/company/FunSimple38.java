package com.company;

import java.util.Scanner;

public class FunSimple38 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("A = ");
        double a = in.nextDouble();
        for (int i = 0; i < 3; i++) {
            System.out.print("N = ");
            double b = in.nextDouble();
            System.out.println("A^N = " + Power(a, b));
        }

    }

    static double Power(double A, double N) {
      double multiplication = 1;

      if (N >= 0) {
          for (int i = 0; i < N; i++) {
              multiplication *= A;
          }
      }
      else {
          for (int i = -1; i >= N; i--) {
              multiplication /= A;
          }
      }
      return multiplication;
    }
}
