package com.company;

import java.util.Scanner;

public class FunSimple52 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        for (int i = 0; i < 5; i++) {

            int Year = in.nextInt();
            System.out.println(IsLeapYear(Year));
        }
    }

    static boolean IsLeapYear(int year) {

        if ((year % 100 == 0 || year % 200 == 0 || year % 300 == 0) && year % 400 != 0) return false;
        else return year % 4 == 0 || year % 400 == 0;

    }
}