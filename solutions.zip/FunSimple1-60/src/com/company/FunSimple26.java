package com.company;

public class FunSimple26 {
    public static void main(String[] args) {

        System.out.println(IsPower5(125));
        System.out.println(IsPower5(126));
        System.out.println(IsPower5(127));
        System.out.println(IsPower5(625));
    }

    static boolean IsPower5(double K) {
        while (K > 5){
            K = K / 5;
        }
        if(K % 5 == 0) return true;
        else return false;
    }
}

