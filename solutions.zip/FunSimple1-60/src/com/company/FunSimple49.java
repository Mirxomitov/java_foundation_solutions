package com.company;

import java.util.Random;
import java.util.Scanner;

public class FunSimple49 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a = in.nextInt();
        int b = in.nextInt();
        int c = in.nextInt();
        int d = in.nextInt();
        EKUB3(a, b, c);
        EKUB3(a, c, d);
        EKUB3(b, c, d);

    }

    static void EKUB3(int a, int b, int c) {
        int x;

        if (a >= b && a >= c) x = a;
        else if (b >= a && b >= c) x = b;
        else x = c;

        int multiple = 1;
        for (int i = 2; i <= x / 2; i++) {
            for (int j = 2; j <= x / 2; j++) {
                if (a % j == 0 && b % j == 0 && c % j == 0) {
                    multiple *= j;
                    a /= j;
                    b /= j;
                    c /= j;
                }
            }
        }
        System.out.println(multiple);
    }
}

class Func49 {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        Random ran = new Random();


        int A, B, C, D;

        System.out.print("Enter A: ");
        A = in.nextInt();

        System.out.print("Enter B: ");
        B = in.nextInt();


        System.out.print("Enter C: ");
        C = in.nextInt();

        Frac(A, B, C);

        System.out.print("Enter D: ");
        D = in.nextInt();

        Frac(A, C, D);


    }

    public static void Frac(int a, int b, int c) {

        if (a > b && c > b) {
            for (int i = b; i > 0; i--) {

                if (a % i == 0 && b % i == 0 && c % i == 0) {
                    System.out.println(a * b * c / i);
                    break;
                }
            }
        } else if (a < b && a < c) {
            for (int i = a; i > 0; i--) {

                if (a % i == 0 && b % i == 0 && c % i == 0) {
                    System.out.println(a * b * c / i);
                    break;
                }

            }
        } else if (a > c && b > c) {
            for (int i = c; i > 0; i--) {

                if (a % i == 0 && b % i == 0 && c % i == 0) {
                    System.out.println(a * b * c / i);
                    break;
                }

            }
        } else System.out.println(0);


    }
}

class num {
    public static void main(String[] args) {
        int n = 10;
        for (int i = 1; i < 10; i++) if (n % i == 0) System.out.println(i);
    }
}