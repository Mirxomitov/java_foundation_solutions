package com.company;

import java.util.Scanner;

public class FunSimple19 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a1, a2, b1, b2, c1, c2;
        System.out.print("R1 = ");
        a1 = in.nextDouble();
        System.out.print("R2 = ");
        a2 = in.nextDouble();
        RingS(a1, a2);
        System.out.print("R1 = ");
        b1 = in.nextDouble();
        System.out.print("R2 = ");
        b2 = in.nextDouble();
        RingS(b1, b2);
        System.out.print("R1 = ");
        c1 = in.nextDouble();
        System.out.print("R2 = ");
        c2 = in.nextDouble();
        RingS(c1, c2);
    }

    static double RingS(double R1, double R2) {

        double S1 = 3.14 * R1 * R1;
        double S2 = 3.14 * R2 * R2;

        System.out.println("RingS = " + (S1 - S2));
        return 0;
    }
}


