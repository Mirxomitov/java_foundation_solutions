package com.company;

import java.util.Scanner;

public class FunSimple3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("A = ");
        double a1 = in.nextDouble();
        System.out.print("B = ");
        double a2 = in.nextDouble();
        System.out.print("C = ");
        double a3 = in.nextDouble();
        System.out.print("D = ");
        double a4 = in.nextDouble();
        mean(a1, a2, a3, a4);
    }

    static void mean(double n1, double n2, double n3, double n4) {

        System.out.println("o'rta arifmetik A va B = " + (n1 + n2) / 2);
        System.out.println("o'rta arifmetik A va C = " + (n1 + n3) / 2);
        System.out.println("o'rta arifmetik A va D = " + (n1 + n4) / 2);
        System.out.println("");
        System.out.println("o'rta geometrik A va B = " + Math.sqrt(n1 * n2));
        System.out.println("o'rta geometrik A va C = " + Math.sqrt(n1 * n3));
        System.out.println("o'rta geometrik A va D = " + Math.sqrt(n1 * n4));
    }
}
