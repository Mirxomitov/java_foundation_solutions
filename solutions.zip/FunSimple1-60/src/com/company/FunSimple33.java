package com.company;

import java.util.Scanner;

public class FunSimple33 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        for (int i = 0; i < 3; i++) {
            double a = in.nextDouble();
            System.out.print(RadtoReg(a));
        }
    }

    static double RadtoReg(double D) {

            D = D / 3.14 * 180;
            return D;

    }
}
