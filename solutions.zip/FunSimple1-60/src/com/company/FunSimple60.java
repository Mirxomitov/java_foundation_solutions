package com.company;

import java.util.Scanner;

public class FunSimple60 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("A : ");
        double xA = in.nextDouble();
        double yA = in.nextDouble();
        System.out.print("B : ");
        double xB = in.nextDouble();
        double yB = in.nextDouble();
        System.out.print("C : ");
        double xC = in.nextDouble();
        double yC = in.nextDouble();
        System.out.print("D : ");
        double xD = in.nextDouble();
        double yD = in.nextDouble();

        Dist(xA, yA, xB, yB, xC, yC);
        Dist(xA, yA, xB, yB, xD, yD);
        Dist(xA, yA, xC, yC, xD, yD);

    }

    static void Dist(double xA, double yA, double xB, double yB, double xC, double yC) {

        double AB = Math.sqrt((xA - xB) * (xA - xB) + (yA - yB) * (yA - yB));
        double AC = Math.sqrt((xA - xC) * (xA - xC) + (yA - yC) * (yA - yC));
        double BC = Math.sqrt((xB - xC) * (xB - xC) + (yB - yC) * (yB - yC));

        double p = (AB + AC + BC) / 2;
        double s = Math.sqrt(p * (p - AB) * (p - AC) * (p - BC));

        System.out.println("h1 = " +  2 * s / BC);
        System.out.println("h2 = " +  2 * s / AC);
        System.out.println("h3 = " +  2 * s / AB + "\n");
    }
}

