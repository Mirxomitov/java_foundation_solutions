package com.company;

import java.util.Scanner;

public class FunSimple48 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a = in.nextInt();
        for (int i = 0; i < 3; i++) {
            int X = in.nextInt();
            EKUK(a, X);
        }
    }

    static void EKUK(int a, int b) {
        int ekuk = a * b;

        while (a != b) {
            if (a > b) a = a - b;
            else b = b - a;
        }

        ekuk /= a;
        System.out.println(ekuk);
    }
}