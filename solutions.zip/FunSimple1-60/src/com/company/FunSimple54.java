package com.company;

import java.util.Scanner;

public class FunSimple54 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        for (int i = 0; i < 3; i++) {

            int date = in.nextInt();
            int month = in.nextInt();
            int year = in.nextInt();

            PrevDate(date, month, year);
        }

    }

    static void PrevDate(int d, int m, int y) {
        int temp_y = y;

        if ((y % 100 == 0 || y % 200 == 0 || y % 300 == 0) && y % 400 != 0) y = 0;
        else if (y % 4 == 0 || y % 400 == 0) y = 1;
        else y = 0;

        switch (m) {
            case 1:
                if (d == 1){
                    temp_y -= 1;
                    d = 31;
                    m = 12;
                }
                else d -= 1;
                break;
            case 3:
                if (y == 0 && d == 1) {
                    d = 28;
                    m -= 1;
                }
                else if (y == 1 && d == 1){
                    d = 29;
                    m -= 1;
                }
                else d -= 1;
                break;
            case 5:
            case 7:
            case 10:
            case 12:
                if (d == 1) {
                    m = m - 1;
                    d = 30;
                }
                else d = d - 1;
                break;
            case 2:
            case 4:
            case 6:
            case 8:
            case 9:
            case 11:
                if (d == 1){
                    d = 31;
                    m = m - 1;
                }
                else d = d - 1;
                break;
        }
        System.out.println(d);
        System.out.println(m);
        System.out.println(temp_y);
    }
}
