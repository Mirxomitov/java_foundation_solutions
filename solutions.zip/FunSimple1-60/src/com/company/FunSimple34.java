package com.company;

import java.util.Scanner;

public class FunSimple34 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        for (int i = 0; i < 3; i++) {
            int a = in.nextInt();
            System.out.println(Fact(a));
        }

    }

    static int Fact(int N) {
        int fact = 1;
        for (int i = 1; i <= N; i++) {
            fact *= i;
        }
        return fact;
    }
}
