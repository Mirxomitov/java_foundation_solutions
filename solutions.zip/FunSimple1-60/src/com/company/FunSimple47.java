package com.company;

import java.util.Scanner;

public class FunSimple47 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a = in.nextInt();
        for (int i = 0; i < 3; i++) {
            int X = in.nextInt();
            Frac_1(a, X);
        }
    }

    static void Frac_1(int a, int b) {
        int p, q;

        p = a;
        q = b;

        while (a != b) {
            if (a > b) a = a - b;
            else b = b - a;
        }

        p /= a;
        q /= b;

        System.out.println(p + " / " + q);
    }
}
