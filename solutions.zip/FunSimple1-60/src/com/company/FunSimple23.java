package com.company;

import java.util.Scanner;

public class FunSimple23 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int x1, y1;
        x1 = in.nextInt();
        y1 = in.nextInt();
        Quarter(x1, y1);

        int x2, y2;
        x2 = in.nextInt();
        y2 = in.nextInt();
        Quarter(x2, y2);

        int x3, y3;
        x3 = in.nextInt();
        y3 = in.nextInt();
        Quarter(x3, y3);
        int x4, y4;
        x4 = in.nextInt();
        y4 = in.nextInt();
        Quarter(x4, y4);
    }

    static int Quarter(int X, int Y){

        if (X > 0 && Y > 0) System.out.println("II");
        else if (X > 0 && Y < 0) System.out.println("III");
        else if (X < 0 && Y > 0) System.out.println("I");
        else if (X < 0 && Y < 0) System.out.println("IV");
        else System.out.println(0);

            return 0;
    }
}
