package com.company;

import java.util.Scanner;

public class FunSimple5 {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        double x1, y1, x2, y2;
        x1 = in.nextDouble();
        y1 = in.nextDouble();
        x2 = in.nextDouble();
        y2 = in.nextDouble();

        RectS(x1, y1, x2, y2);
        RectP(x1, y1, x2, y2);
    }

    static double RectS(double x1, double y1, double x2, double y2) {

        double s;

        s = Math.abs(x1 - x2) * Math.abs(y1 - y2);
        System.out.println(s);
        return s;
    }

    static double RectP(double x1, double y1, double x2, double y2) {

        double p;

        p = 2 * (Math.abs(x1 - x2) + Math.abs(y1 - y2));
        System.out.println(p);
        return p;
    }
}
