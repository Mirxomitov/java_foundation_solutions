package com.company;

import java.util.Scanner;

public class FunSimple16 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a1 = in.nextInt();
        Ishora(a1);
        int a2 = in.nextInt();
        Ishora(a2);
        int a3 = in.nextInt();
        Ishora(a3);
    }

    static double Ishora(int a) {
        if (a > 0) System.out.println(1);
        else if (a < 0) System.out.println(-1);
        else System.out.println(0);
        return 0;
    }
}