package com.company;

import java.util.Scanner;

public class FunSimple7 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int A = in.nextInt();
        InvertDigit(A);
        int B = in.nextInt();
        InvertDigit(B);
        int C = in.nextInt();
        InvertDigit(C);
        int D = in.nextInt();
        InvertDigit(D);
    }

    static int InvertDigit(int son) {

        int saqlagich, teskari = 0;

        while (son > 0) {

            saqlagich = son % 10;

            teskari = teskari * 10 + saqlagich;

            son /= 10;
        }
        System.out.println(teskari);
       return teskari;
    }
}
