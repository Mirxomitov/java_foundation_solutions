package com.company;

import java.util.Scanner;

class FunSimple20 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b;
        a = in.nextInt();
        b = in.nextInt();
        RightTriangleP(a, b);
    }

    static double RightTriangleP(double a, double b) {

        double c = Math.sqrt(a * a + b * b);
        System.out.println(a + b +c);
        return 0;
    }
}


