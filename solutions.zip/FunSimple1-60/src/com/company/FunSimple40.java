package com.company;

import java.util.Scanner;

import static java.lang.System.*;

public class FunSimple40 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        out.println("x = ");
        double x = in.nextDouble();

        for (int i = 0; i < 3; i++) {
            out.println((i + 1 ) +  ". e = ");
            double e = in.nextDouble();


            out.println(Double(-9, 3));
        }
    }

    static Double Double (double x, double e) {
        double sum = 1;
        int i = 1;

        while (sum > e){
            int fact = 1;
            fact *= i;
            sum += Math.pow(x, i) / fact;

            i++;
        }
        System.out.print(sum);
        return sum;
    }
}
