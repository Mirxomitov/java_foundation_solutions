package com.company;

public class FunSimple9 {
    public static void main(String[] args) {
        AddLeftDigit(12, 3);
    }

    static int AddLeftDigit(int newnum, int R) {
        int soni = 0;
        int remainder = newnum;
        while (newnum > 0) {
            soni++;
            newnum /= 10;
        }

        newnum = (int) (R * Math.pow(10, soni) + remainder);

        System.out.println(newnum);
        return newnum;
    }
}
