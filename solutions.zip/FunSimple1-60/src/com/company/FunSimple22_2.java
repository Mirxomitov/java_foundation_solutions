package com.company;

public class FunSimple22_2 {
    public static void main(String[] args) {

    }
    static double Calc(double a, double b, String op){



        return 0;
    }
}
