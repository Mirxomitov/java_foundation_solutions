package com.company;

public class FunSimple50 {
    public static void main(String[] args) {

        TimetoHMS(98869);

    }

    static void TimetoHMS(int T) {

        int H, M, S;

        H = T / 3600;
        M = T % 3600 / 60;
        S = T % 60;

        if (H < 10 && M < 10) System.out.println("0" + H + ":" + "0" + M + ":" + S);
        else if (H < 10) System.out.println("0" + H + ":" + M + ":" + S);
        else if (M < 10) System.out.println(H + ":" + "0" + M + ":" + S);
        else System.out.println(H + ":" + M + ":" + S);
    }
}
