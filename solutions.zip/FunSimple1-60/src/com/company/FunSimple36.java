package com.company;

import java.util.Scanner;

public class FunSimple36 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        System.out.println(Fib(n));

    }

    static int Fib(int N) {
        int f1 = 1;
        int f2 = 1;
        int f3 = 2;

        for (int i = 1; i <= N; i++) {
            f1 = f2;
            f2 = f3;
            f3 = f1 + f2;

        }
        return f1;
    }
}
