package com.company;

public class FunSimple51 {
    public static void main(String[] args) {
        int H = 10;
        int M = 59;
        int S = 53;
        int T = 3669;

        IncTime(H, M, S, T);

    }
    static void IncTime(int H, int M, int S, int T){
        H = H * 3600;
        M = M * 60;

        int seconds;

        seconds = S + M + H + T;

        H = seconds / 3600;
        M = seconds % 3600 / 60;
        S = seconds % 60;

        if (H < 10 && M < 10) System.out.println("0" + H + ":" + "0" + M + ":" + S);
        else if (H < 10) System.out.println("0" + H + ":" + M + ":" + S);
        else if (M < 10) System.out.println(H + ":" + "0" + M + ":" + S);
        else System.out.println(H + ":" + M + ":" + S);
    }
}
