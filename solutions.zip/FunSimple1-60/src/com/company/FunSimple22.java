package com.company;

import java.util.Scanner;

public class FunSimple22 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("N1 +    N2 -    N3 *    N4 /");

        double a, b;
        a = in.nextDouble();
        b = in.nextDouble();

        String op1 = in.next();
        Calc(a, b, op1);
        String op2 = in.next();
        Calc(a, b, op2);
        String op3 = in.next();
        Calc(a, b, op3);
        String op4 = in.next();
        Calc(a, b, op4);
    }

    static double Calc(double a, double b, String op) {
        double sum = 0;

        switch (op) {
            case "N1":
            case "n1":
                sum = a + b;
                break;
            case "N2":
            case "n2":
                sum = a - b;
                break;
            case "N3":
            case "n3":
                sum = a * b;
                break;
            case "N4":
            case "n4":
                sum = a / b;
                break;
        }
        System.out.println(sum);
        return 0;
    }
}
