package com.company;

import java.util.Scanner;

public class FunSimple32 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        for (int i = 0; i < 3; i++) {
            double a = in.nextDouble();
            System.out.print(DegToRad(a));
        }
    }

    static double DegToRad(double D) {
        if (D > 0 && D < 360){
            D = D * 3.14 / 180;
            return D;
        }
        return 0;
    }
}
