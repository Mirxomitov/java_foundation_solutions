package com.company;

import java.util.Scanner;

public class FunSimple17 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a, b, c;
        System.out.println("A = ");
        a = in.nextInt();
        System.out.println("B = ");
        b = in.nextInt();
        System.out.println("C = ");
        c = in.nextInt();
        KvTenglama(a, b, c);
    }

    static double KvTenglama(int a, int b, int c) {

        double D = b * b - 4 * a * c;

        if(D > 0) System.out.println(2);
        else if(D == 0) System.out.println(1);
        else System.out.println(0);
        return 0;
    }
}