package com.company;

import java.util.Scanner;

public class FunSimple10 {
    public static void main(String[] args) {

        Scanner in= new Scanner(System.in);

        int a, b, c, d;
        System.out.print("a = ");
        a = in.nextInt();
        System.out.print("b = ");
        b = in.nextInt();
        Swap(a,b);
        System.out.print("c = ");
        c = in.nextInt();
        System.out.print("d = ");
        d = in.nextInt();
        Swap(c, d);

    }
    static void Swap(int a, int b){

        a = b ^ a;
        b = a ^ b;
        a = a ^ b;

        System.out.println("a = " + a);
        System.out.println("b = " + b);
    }
}
