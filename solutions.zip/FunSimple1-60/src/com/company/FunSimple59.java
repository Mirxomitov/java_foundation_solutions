package com.company;

import java.util.Scanner;

public class FunSimple59 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("A : ");
        double xA = in.nextDouble();
        double yA = in.nextDouble();
        System.out.print("B : ");
        double xB = in.nextDouble();
        double yB = in.nextDouble();
        System.out.print("C : ");
        double xC = in.nextDouble();
        double yC = in.nextDouble();
        System.out.print("P : ");
        double xP = in.nextDouble();
        double yP = in.nextDouble();

        System.out.println("H ab = " + Dist(xA, yA, xB, yB, xP, yP));
        System.out.println("H ac = " + Dist(xA, yA, xC, yC, xP, yP));
        System.out.println("H bc = " + Dist(xB, yB, xC, yC, xP, yP));

    }

    static double Dist(double xA, double yA, double xB, double yB, double xP, double yP) {

        double AB = Math.sqrt((xA - xB) * (xA - xB) + (yA - yB) * (yA - yB));
        double AP = Math.sqrt((xA - xP) * (xA - xP) + (yA - yP) * (yA - yP));
        double BP = Math.sqrt((xB - xP) * (xB - xP) + (yB - yP) * (yB - yP));

        double p = (AB + AP + BP) / 2;
        double s = Math.sqrt(p * (p - AB) * (p - AP) * (p - BP));

        return 2 * s / AB;
    }
}

