package com.company;

import java.util.Scanner;

public class FunSimple46 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int A = in.nextInt();

        for (int i = 0; i < 3; i++) {
            int X = in.nextInt();
            System.out.println(Euclid(A, X));
            System.out.println(Euclid2(A, X));
        }
    }

    static int Euclid(int a, int b) {

        while (a != 0 && b != 0) {
            if (a > b) a = a % b;
            else b = b % a;
        }
        return a + b;
    }
    static int Euclid2(int a, int b){

        while (a != b){
            if (a > b) a = a - b;
            else b = b - a;
        }
        return a;
    }
}

