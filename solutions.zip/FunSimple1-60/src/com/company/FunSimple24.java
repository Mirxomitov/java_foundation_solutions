package com.company;

import java.util.Scanner;

public class FunSimple24 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        for (int i = 0; i < 3; i++) {
            int a = in.nextInt();
            System.out.println(EvenK(a));
        }
    }

    static boolean EvenK(int K) {
        if (K % 2 == 0) return true;
        else return false;
    }
}
