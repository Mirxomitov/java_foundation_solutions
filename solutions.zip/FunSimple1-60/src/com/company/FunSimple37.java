package com.company;

import java.util.Scanner;

public class FunSimple37 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("b = ");
        double a = in.nextDouble();
        for (int i = 0; i < 3; i++) {
            System.out.print("a" + (i + 1) + ". =" );
            double b = in.nextDouble();
            System.out.println("A^B = "+Power(a, b));
        }

    }

    static double Power(double A, double B) {
        double c = Math.pow(A, B);
        return c;
    }
}
