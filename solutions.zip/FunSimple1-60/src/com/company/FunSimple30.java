package com.company;

import java.util.Scanner;

public class FunSimple30 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        for (int i = 0; i < 3; i++) {
            int K = in.nextInt();
            int N = in.nextInt();
            System.out.println(DigitCount(K, N));
        }
    }

    static int DigitCount(int son, int N) {
        int temp = son;
        double Counter = 0;
        while (son > 0) {
            son /= 10;
            Counter++;
        }
        if (N > Counter) return -1;
        else {
            temp = (int) (temp / Math.pow(10, N) % 10);
            return temp;
        }
    }
}
