package com.company;

import java.util.Scanner;

public class FunSimple31 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        for (int i = 0; i < 5; i++) {
            int K = in.nextInt();
            System.out.println(isPolindrom(K));
        }
    }

    static boolean isPolindrom(int son) {
        int teskari = 0;
        int temp = son;

        while (son > 0) {
            int remainder = son % 10;

            teskari = teskari * 10 + remainder;

            son /= 10;
        }
        if (temp == teskari) return true;
        else return false;
    }
}

