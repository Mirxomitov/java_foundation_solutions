package com.company;

import java.util.Scanner;

public class FunSimple13 {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        int a1, b1, c1;

        System.out.print("a1 = ");
        a1 = in.nextInt();
        System.out.print("b1 = ");
        b1 = in.nextInt();
        System.out.print("c1 = ");
        c1 = in.nextInt();

        SortDec3(a1, b1, c1);
        int a2, b2, c2;
        System.out.print("a2 = ");
        a2 = in.nextInt();
        System.out.print("b2 = ");
        b2 = in.nextInt();
        System.out.print("c2 = ");
        c2 = in.nextInt();

        SortDec3(a2, b2, c2);

    }

    static void SortDec3(int a, int b, int c) {

        if (a > b && a > c && b != c) {
            System.out.println(a);
            if (b > c) {
                System.out.println(b);
                System.out.println(c);
            }
            if (c > b) {
                System.out.println(c);
                System.out.println(b);
            }
        } else if (b > a && b > c && a != c) {
            System.out.println(b);

            if (a > c) {
                System.out.println(a);
                System.out.println(c);
            }
            if (c > a) {
                System.out.println(c);
                System.out.println(a);
            }
        } else if (c > b && c > a && a != b) {
            System.out.println(c);
            if (b > a) {
                System.out.println(b);
                System.out.println(a);
            }
            if (a > b) {
                System.out.println(a);
                System.out.println(b);
            }
        } else System.out.println("a yoki b yoki c o'zaro teng");
    }
}