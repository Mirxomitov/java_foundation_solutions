package com.company;

public class Project1 {
    public static void main(String[] args) {
        System.out.println("JUDA OSON EKAN");
    }
}
