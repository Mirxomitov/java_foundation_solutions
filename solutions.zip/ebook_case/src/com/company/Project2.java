package com.company;

public class Project2 {
    public static void main(String[] args) {
        System.out.println("JUDA OSON EKAN");
    }
}
