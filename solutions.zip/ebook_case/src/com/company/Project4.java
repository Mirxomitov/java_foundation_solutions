package com.company;

import java.util.Scanner;

public class Project4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n;
        n = in.nextInt();

        int a, b;

        a = n % 10;
        b = n / 10;
    if (n > 0 && n < 100){
        switch (b){
            case 0: System.out.println("");
                break;
            case 1: System.out.println("O'n");
            break;
            case 2: System.out.println("Yigirma");
                break;
            case 3: System.out.println("O'ttiz");
                break;
            case 4: System.out.println("Qirq");
                break;
            case 5: System.out.println("Ellik");
                break;
            case 6: System.out.println("Oltmish");
                break;
            case 7: System.out.println("Yetmish");
                break;
            case 8: System.out.println("Sakson");
                break;
            case 9: System.out.println("To'qson");
                break;
        }
        switch (a){
            case 0: System.out.println("nol");
                break;
            case 1: System.out.println("bir");
                break;
            case 2: System.out.println("ikki");
                break;
            case 3: System.out.println("uch");
                break;
            case 4: System.out.println("to'rt");
                break;
            case 5: System.out.println("besh");
                break;
            case 6: System.out.println("olti");
                break;
            case 7: System.out.println("yetti");
                break;
            case 8: System.out.println("sakkiz");
                break;
            case 9: System.out.println("to'qqiz");
                break;
        }
    }
    }
}
