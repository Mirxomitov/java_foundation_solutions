package com.company;

import java.util.Scanner;

public class Case11 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("tomonlar    : N , S , W, E ");
        char c; c = in.next().charAt(0);
        System.out.println("harakatlar  : 1 - chapga buril, -1 - o'ngga buril, 2 - 180 gradusga buril ");
        int n1; n1 = in.nextInt();
        int n2; n2 = in.nextInt();

        switch (c){
            case 'N':
            case 'n':
                if (n1 == 1 && n2 == -1 || n1 == -1 && n2 == 1 || n1 == 2 && n2 == 2) System.out.println("N");
                if (n1 == 1 && n2 == 1  || n1 == -1 && n2 == -1)  System.out.println("S");
                if (n1 == -1 && n2 == 2 || n1 == 2  && n2 == -1)  System.out.println("E");
                if (n1 == 1 && n2 == 2  || n1 == 2  && n2 == 1)  System.out.println("W");

                break;

            case 'S':
            case 's':
                if (n1 == -1 && n2 == 1 || n1 == 1 && n2 == -1 || n1 == 2 && n2 == 2)  System.out.println("S");
                if (n1 == -1 && n2 == -1 || n1 == 1 && n2 == 1)  System.out.println("N");
                if (n1 == 2 && n2 == -1 || n1 == -1 && n2 == 2)  System.out.println("E");
                if (n1 == 2 && n2 == 1 || n1 == 1 && n2 == 2)  System.out.println("W");

                break;

            case 'W':
            case 'w':
                if (n1 == 2 && n2 == 2 ||n1 == -1 && n2 == 1 || n1 == 1 && n2 == -1) System.out.println("W");
                if (n1 == -1 && n2 == -1 || n1 == 1 && n2 == 1)  System.out.println("E");
                if (n1 == -1 && n2 == 2 || n1 == 2 && n2 == -1)  System.out.println("S");
                if (n1 == 1 && n2 == 2 || n1 == 2 && n2 == 1) System.out.println("N");

                break;

            case 'E':
            case 'e':
                if (n1 == 1 && n2 == -1 || n1 == 2 && n2 == 2 || n1 == -1 && n2 == 1) System.out.println("E");
                if (n1 == 1 && n2 == 1 || n1 == -1 && n2 == -1)  System.out.println("W");
                if (n1 == -1 && n2 == 2 || n1 == 2 && n2 == -1)  System.out.println("S");
                if (n1 == 1 && n2 == 2 || n1 == 2 && n2 == 1)  System.out.println("N");

                break;

            default:
                System.out.println("xato");
        }
    }
}
