package com.company;

import java.util.Scanner;

public class Case3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n;
        n = in.nextInt();

        switch (n){
            case 1:
                System.out.println("Qish");
                break;
            case 2:
                System.out.println("Qish");
                break;
            case 3:
                System.out.println("Bahor");
                break;
            case 4:
                System.out.println("Bahor");
                break;
            case 5:
                System.out.println("Bahor");
                break;
            case 6:
                System.out.println("Yoz");
                break;
            case 7:
                System.out.println("Yoz");
                break;
            case 8:
                System.out.println("Yoz");
                break;
            case 9:
                System.out.println("Kuz");
                break;
            case 10:
                System.out.println("Kuz");
                break;
            case 11:
                System.out.println("Kuz");
                break;
            case 12:
                System.out.println("Qish");
                break;
            default:
                System.out.println("xato");
        }
    }
}
