package com.company;

import java.util.Scanner;

public class Case19 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();
        int a, b;
        a = n % 5;
        b = n % 12;

        switch (a){
            case 1:
                System.out.println("qizil");
                break;
            case 2:
                System.out.println("sariq");
                break;
            case 3:
                System.out.println("oq");
                break;
            case 4:
                System.out.println("qora");
                break;
            case 0:
                System.out.println("yashil");
                break;
            }
        switch (b){
            case 4:
                System.out.println("sichqon");
                break;
            case 5:
                System.out.println("sigir");
                break;
            case 6:
                System.out.println("yo'lbars");
                break;
            case 7:
                System.out.println("quyon");
                break;
            case 8:
                System.out.println("ajdar");
                break;
            case 9:
                System.out.println("ilon");
                break;
            case 10:
                System.out.println("ot");
                break;
            case 11:
                System.out.println("qo'y");
                break;
            case 0:
                System.out.println("maymun");
                break;
            case 1:
                System.out.println("tovuq");
                break;
            case 2:
                System.out.println("it");
                break;
            case 3:
                System.out.println("to'ng'iz");
                break;
        }


    }
}
