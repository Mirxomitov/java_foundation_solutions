package com.company;

import java.util.Scanner;

public class Case9 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int d, m;

        System.out.print("Month = ");
        m = in.nextInt();
        System.out.print("Date = ");
        d = in.nextInt();


        switch (m) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
                if (d > 0 && d < 32) {
                    if (d < 31) {
                        System.out.println(m);
                        System.out.println(++d);
                    } else {
                        System.out.println(++m);
                        System.out.println(1);
                    }
                }
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                if (d > 0 && d < 31) {
                    if (d < 30) {
                        System.out.println(m);
                        System.out.println(++d);
                    } else {
                        System.out.println(++m);
                        System.out.println(1);
                    }
                }
                break;
            case 2:
                if (d > 0 && d < 29) {
                    if (d < 28) {
                        System.out.println(m);
                        System.out.println(++d);
                    } else {
                        System.out.println(++m);
                        System.out.println(1);
                    }
                }
                    break;
            case 12:
                if (d > 0 && d < 32) {
                    if (d < 31) {
                        System.out.println(m);
                        System.out.println(++d);
                    }
                    else {
                        System.out.println(1);
                        System.out.println(1);
                    }
                }
                break;
                default:
                     System.out.println("xato");
                }
        }
    }
