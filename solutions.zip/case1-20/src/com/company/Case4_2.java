package com.company;

import java.util.Scanner;

public class Case4_2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n;
        n = in.nextInt();

        if(n > 0 && n <= 7){
            if(n == 2) {
                System.out.println("28-29 kun");
            }
                else if(n % 2 == 0) {
                    System.out.println("30");
                }
                else{
                System.out.println("31");
                }
        }
        else if(n > 7 && n <= 12){
            if(n % 2 == 0){
                System.out.println("31");
            }
            else{
                System.out.println("30");
            }
        }
        else {
            System.out.println("xato");
        }
    }
}

