package com.company;

import java.util.Scanner;

public class Case18 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();
        int a, b, c;

        a = n / 100;
        b = n / 10 % 10;
        c = n % 10;
        if (n >= 1 && n <= 999) {
            switch (a) {
                case 0:
                    System.out.print("");
                    break;
                case 1:
                    System.out.print("Bir yuz ");
                    break;
                case 2:
                    System.out.print("Ikki yuz ");
                    break;
                case 3:
                    System.out.print("Uch yuz ");
                    break;
                case 4:
                    System.out.print("To'tr yuz ");
                    break;
                case 5:
                    System.out.print("Besh yuz ");
                    break;
                case 6:
                    System.out.print("Olti yuz ");
                    break;
                case 7:
                    System.out.print("Yetti yuz ");
                    break;
                case 8:
                    System.out.print("Sakkiz yuz ");
                    break;
                case 9:
                    System.out.print("To'qqiz yuz ");
                    break;
            }

            switch (b) {
                case 0:
                    System.out.print("");
                    break;
                case 1:
                    System.out.print("o'n ");
                    break;
                case 2:
                    System.out.print("yigirma ");
                    break;
                case 3:
                    System.out.print("o'ttiz ");
                    break;
                case 4:
                    System.out.print("qirq ");
                    break;
                case 5:
                    System.out.print("ellik ");
                    break;
                case 6:
                    System.out.print("oltmish ");
                    break;
                case 7:
                    System.out.print("yetmish ");
                    break;
                case 8:
                    System.out.print("sakson ");
                    break;
                case 9:
                    System.out.print("to'qson ");
                    break;
            }
            switch (c) {
                case 0:
                    System.out.print("");
                    break;
                case 1:
                    System.out.print("bir");
                    break;
                case 2:
                    System.out.print("ikki");
                    break;
                case 3:
                    System.out.print("uch");
                    break;
                case 4:
                    System.out.print("to'tr");
                    break;
                case 5:
                    System.out.print("besh");
                    break;
                case 6:
                    System.out.print("olti");
                    break;
                case 7:
                    System.out.print("yetti");
                    break;
                case 8:
                    System.out.print("sakkiz");
                    break;
                case 9:
                    System.out.print("to'qqiz");
                    break;
            }
        }
        else System.out.println("Xato");
    }
}