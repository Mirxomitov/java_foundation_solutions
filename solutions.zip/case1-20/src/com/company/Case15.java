package com.company;

import java.util.Scanner;

public class Case15 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("N = ");
        int n = in.nextInt();
        System.out.print("M = ");
        int m = in.nextInt();

        switch (n){
            case 6:
            case 7:
            case 8:
            case 9:
            case 10:
                System.out.print(n);
                break;
            case 11: System.out.print("Valet");
                break;
            case 12: System.out.print("Dama");
                break;
            case 13: System.out.print("Karol");
                break;
            case 14: System.out.print("Tuz");
                break;
            default:
                System.out.println("Xato1");
        }

        switch (m){
            case 1:
                System.out.println("  G'ihst");
                break;
            case 2:
                System.out.println("  Olma");
                break;
            case 3:
                System.out.println("  Chillak");
                break;
            case 4:
                System.out.println("  Qarg'a");
                break;
            default:
                System.out.println("Xato2");
        }
    }
}
