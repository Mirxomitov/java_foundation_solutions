package com.company;

import java.util.Scanner;

public class Case12 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("Birlikni tanlang");
        System.out.println("1 - radius, 2 - diametr, 3 - uzunligi, 4 - yuzasi");
        int n;
        n = in.nextInt();

        System.out.println("son kiriting");
        double a;
        a = in.nextDouble();

        switch (n){
            case 1:
                System.out.println("D = " + 2 * a);
                System.out.println("L = " + 2 * Math.PI * a);
                System.out.println("S = " + Math.PI * a * a);
                break;

            case 2:
                System.out.println("R = " + a / 2);
                System.out.println("L = " + Math.PI * a);
                System.out.println("S = " + Math.PI * a * a / 4);

                break;

            case 3:
                System.out.println("R = " + (a / 2) * Math.PI);
                System.out.println("D = " + a / Math.PI);
                System.out.println("S = " + a * (a / 2) * Math.PI / 2);

                break;
            case 4:
                System.out.println("R = " + Math.sqrt(a / Math.PI));
                System.out.println("D = " + 2 * Math.sqrt(a / Math.PI));
                System.out.println("L = " + 2 * a / Math.sqrt(a / Math.PI));

        }
    }
}
