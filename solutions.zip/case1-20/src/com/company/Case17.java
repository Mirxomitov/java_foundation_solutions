package com.company;

import java.util.Scanner;

public class Case17 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("Yoshni kiriting");
        int n = in.nextInt();

        int a, b;
        a = n / 10;
        b = n % 10;

        switch (a){
            case 1:
                System.out.print("O'n");
                break;
            case 2:
                System.out.print("Yigirma");
                break;
            case 3:
                System.out.print("O'ttiz");
                break;
            case 4:
                System.out.print("Qirq");
                break;
        }
        switch (b){
            case 0:
                System.out.println("ta masala");
            case 1:
                System.out.print(" bitta masala");
                break;
            case 2:
                System.out.print(" ikkita masala");
                break;
            case 3:
                System.out.print(" uchta masala");
                break;
            case 4:
                System.out.print(" to'rtta masala");
                break;
            case 5:
                System.out.print(" beshta masala");
                break;
            case 6:
                System.out.print(" oltita masala");
                break;
            case 7:
                System.out.print(" yettita masala");
                break;
            case 8:
                System.out.print(" sakkizta masala");
                break;
            case 9:
                System.out.print(" to'qqizta masala");
                break;
        }
    }
}
