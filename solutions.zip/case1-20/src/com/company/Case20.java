package com.company;

import java.util.Scanner;

public class Case20 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int m, d;
        System.out.println("D = ");
        d = in.nextInt();
        System.out.println("M = ");
        m = in.nextInt();

        switch (m){
            case 1:
                if(d <= 19 && d >= 0) System.out.println("Echki");
                if(d >= 20 && d <= 31) System.out.println("Qovg'a");
                break;
            case 2:
                if(d <= 18 && d >= 0 ) System.out.println("Qovg'a");
                if(d >= 19 && d <= 29) System.out.println("Baliq");
                break;
            case 3:
                if(d <= 20 && d >= 0) System.out.println("Baliq");
                if(d >= 21 && d <= 31) System.out.println("Qo'y");
                break;
            case 4:
                if(d <= 19 && d >= 0) System.out.println("Qo'y");
                if(d >= 20 && d <= 30) System.out.println("Buzoq");
                break;
            case 5:
                if(d <= 20 && d >= 0) System.out.println("Buzoq");
                if(d >= 21 && d <= 31) System.out.println("Egizaklar");
                break;
            case 6:
                if(d <= 21 && d >= 0) System.out.println("Egizaklar");
                if(d >= 22 && d <= 30) System.out.println("Qisqichbaqa");
                break;
            case 7:
                if(d <= 22 && d >= 0) System.out.println("Qisqichbaqa");
                if(d >= 23 && d <= 31) System.out.println("Arslon");
                break;
            case 8:
                if(d <= 22 && d >= 0) System.out.println("Arslon");
                if(d >= 23 && d <= 31) System.out.println("Parizod");
                break;
            case 9:
                if(d <= 22 && d >= 0) System.out.println("Parizod");
                if(d >= 23 && d <= 30) System.out.println("Tarozi");
                break;
            case 10:
                if(d <= 22 && d >= 0) System.out.println("Tarozi");
                if(d >= 23 && d <= 31) System.out.println("Chayon");
                break;
            case 11:
                if(d <= 22 && d >= 0) System.out.println("Chayon");
                if(d >= 23 && d <= 30) System.out.println("O'qotar");
                break;
            case 12:
                if(d <= 21 && d >= 0) System.out.println("O'qotar");
                if(d >= 22 && d <= 31) System.out.println("Echki");
                break;
            default:
                System.out.println("xato");
        }
    }
}
