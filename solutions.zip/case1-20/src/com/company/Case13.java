package com.company;

import java.util.Scanner;

public class Case13 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("1 - katet, 2-gipotenuza, 3-gipotenuzaga tushirilgan balandlik, 4-yuza");
        int n; n = in.nextInt();

        System.out.println("son kiriting");
        double k;
        k = in.nextDouble();

        switch (n){
            case 1:
                System.out.println("c = " + k * Math.sqrt(2));
                System.out.println("h = " + k / Math.sqrt(2));
                System.out.println("S = " + k * k / 2);
                break;
            case 2:
                System.out.println("a = " + k / Math.sqrt(2));
                System.out.println("h = " +  k / 2);
                System.out.println("S = " + k *  k / 4);
                break;
            case 3:
                System.out.println("a = " + k * Math.sqrt(2));
                System.out.println("c = " + 2 * k);
                System.out.println("S = " + k * k );
                break;
            case 4:
                System.out.println("a = " + Math.sqrt(2 * k));
                System.out.println("c = " + 2 * Math.sqrt(k) );
                System.out.println("h = " + Math.sqrt(k));
                break;
            default:
                System.out.println("xato");
        }
    }
}
