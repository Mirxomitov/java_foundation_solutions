package com.company;

import java.util.Scanner;

public class Case10 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("tomonlar    :     N , S , W, E ");
        char c; c = in.next().charAt(0);
        System.out.println("harakatlar  :     0 - davom et, 1 - chapga buril, 2 -o'ngga buril ");
        int n; n = in.nextInt();


        switch (c){
            case 'N':
            case 'n':
                if (n == 0) System.out.println("N");
                if (n == 1) System.out.println("W");
                if (n == 2) System.out.println("E");
                break;
            case 'S':
            case 's':
                if (n == 0) System.out.println("S");
                if (n == 1) System.out.println("E");
                if (n == 2) System.out.println("W");
                break;
            case 'W':
            case 'w':
                if (n == 0) System.out.println("W");
                if (n == 1) System.out.println("S");
                if (n == 2) System.out.println("N");
                break;
            case 'E':
            case 'e':
                if (n == 0) System.out.println("E");
                if (n == 1) System.out.println("N");
                if (n == 2) System.out.println("S");
                break;
            default:
                System.out.println("xato");
        }
    }
}
