package com.company;

import java.util.Scanner;

public class Case16 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("Yoshni kiriting");
        int n = in.nextInt();

        int a, b;
        a = n / 10;
        b = n % 10;

        switch (a){
            case 1:
                System.out.print("O'n ");
                break;
            case 2:
                System.out.print("Yigirma ");
                break;
            case 3:
                System.out.print("O'ttiz ");
                break;
            case 4:
                System.out.print("Qirq ");
                break;
            case 5:
                System.out.print("Ellik ");
                break;
            case 6:
                System.out.print("Oltmish ");
                break;
        }
        switch (b){
            case 1:
                System.out.print("bir");
                break;
            case 2:
                System.out.print("ikki");
                break;
            case 3:
                System.out.print("uch");
                break;
            case 4:
                System.out.print("to'rt");
                break;
            case 5:
                System.out.print("besh");
                break;
            case 6:
                System.out.print("olti");
                break;
            case 7:
                System.out.print("yetti");
                break;
            case 8:
                System.out.print("sakkiz");
                break;
            case 9:
                System.out.print("to'qqiz");
                break;
        }
    }
}
