package com.company;

import java.util.Scanner;

public class Case6 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double a;
        System.out.println("uznulikni kirting:");
        a = in.nextInt();

        System.out.println("birligini tanlang");

        System.out.println("1 - detsimetr");
        System.out.println("2 - kilometr");
        System.out.println("3 - metr");
        System.out.println("4 - millimetr");
        System.out.println("5 - santimetr");

        int n;
        System.out.print("n=");
        n = in.nextInt();

        switch (n){
            case 1:
                System.out.println(a + " dm = " + a * 10 + " metr");
                break;
            case 2:
                System.out.println(a + " kiolometr = " + a * 1000 + " metr");
                break;
            case 3:
                System.out.println(a + " metr = " + a + " metr");
                break;
            case 4:
                System.out.println(a + " millimetr = " + a / 1000 + " metr");
            case 5:
                System.out.println(a + " santimetr = " + a / 100 + " metr");

        }



    }
}
