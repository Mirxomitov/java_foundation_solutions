package com.company;

import java.util.Scanner;

public class Case14 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("qiymatni kiriting :  x = ");
        double x; // qiymat
        x = in.nextDouble();

        System.out.println("Tanlang:");
        System.out.println("1-tomoni, 2-ichki chizilgan aylana, 3-tashqi chizilgan aylana, 4-yuza");
        int n; n = in.nextInt(); // 1-4


        switch (n){
            case 1:
                // x => bu Yerda tomon
                System.out.println("r = " + x * Math.sqrt(3) / 6);
                System.out.println("R = " + x * Math.sqrt(3) / 3);
                System.out.println("S = " + x * x * Math.sqrt(3) / 4);
                break;

            case 2:
                // x => bu Yerda ichki radius
                System.out.println("a = " + 6 * x / Math.sqrt(3));
                System.out.println("R = " + 2 * x);
                System.out.println("S = " + 3 * Math.sqrt(3) * x * x );
                break;

            case 3:
                // x => bu Yerda tashqi radius
                System.out.println("a = " + x * Math.sqrt(3));
                System.out.println("r = " + x / 2);
                System.out.println("S = " + x * x * Math.sqrt(3) * 3 / 4 );
                break;
            case 4:
                // x => bu yerda Yuza
                System.out.println("a = " + 2 * Math.sqrt(x / Math.sqrt(3)));
                System.out.println("r = " + Math.sqrt(x / Math.sqrt(27) ));
                System.out.println("R = " + 4 * x / Math.sqrt(27));
                break;
            default:
                System.out.println("xato");
        }
    }
}
