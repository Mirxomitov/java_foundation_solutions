package com.company;

import java.util.Scanner;

public class Case8 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double a;
        System.out.println("og'irlikni kirting:");
        a = in.nextInt();

        System.out.println("birligini tanlang");

        System.out.println("1 - kilogram");
        System.out.println("2 - milligram");
        System.out.println("3 - gram");
        System.out.println("4 - tonna");
        System.out.println("5 - sentner");

        int n;
        System.out.print("n=");
        n = in.nextInt();

        switch (n){
            case 1:
                System.out.println(a + " kilogram = " + a + " kilogram");
                break;
            case 2:
                System.out.println(a + " milligram = " + a / 1000000 + " kilogram");
                break;
            case 3:
                System.out.println(a + " gram = " + a / 1000+ " kilogram");
                break;
            case 4:
                System.out.println(a + " tonna = " + a * 1000 + " kilogram");
                break;
            case 5:
                System.out.println(a + " sentner = " + a * 100 + " kilogram");
                break;
            default:
                System.out.println("xato");
                break;
        }
    }
}
