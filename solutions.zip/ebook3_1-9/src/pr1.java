import java.util.Scanner;

public class pr1 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double x, y;

        System.out.print("X ni radianda kiriting=");
        x = num.nextDouble();

        System.out.println("X gradusda= " + x * 180 / Math.PI);

        System.out.println("sin(x^2) + cos^2(x) = " + (Math.sin(x * x) + Math.pow(Math.cos(x), 2)));
    }
}
