package com.company;

import java.util.Scanner;

public class pr2 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double x, y;

        System.out.print("X ni radiandada kiriting=");
        x = num.nextDouble();

        System.out.println("X gradusda= " + x * 180 / Math.PI);

        System.out.println("sqrt(sin(x) + sqrt(cos(x))) = " + (Math.sqrt(Math.sin(x) + Math.sqrt(Math.cos(x)))));
    }
}
