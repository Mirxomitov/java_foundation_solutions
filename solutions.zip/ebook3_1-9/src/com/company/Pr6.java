package com.company;

import java.util.Scanner;

public class Pr6 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

       double  a, b, x, y;

        System.out.print("a=");
        a = num.nextDouble();
        System.out.print("b=");
        b = num.nextDouble();
        System.out.print("x=");
        x = num.nextDouble();

        y = Math.pow(a, x) / Math.sqrt(a * a + b * b);

        System.out.println("     a^x");
        System.out.println("--------------- = " + y);
        System.out.println("sqrt(a^2 + b^2)");
    }
}
