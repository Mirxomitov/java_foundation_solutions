package com.company;

import java.util.Scanner;

public class Pr3 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double z, a;

        System.out.print("z=");
        z = num.nextDouble();

        a = 1 + z * z / (3 + z * z / 5);

        System.out.println("1 + z^2 / ( 3 + z^2 / 5" + a);
    }
}
