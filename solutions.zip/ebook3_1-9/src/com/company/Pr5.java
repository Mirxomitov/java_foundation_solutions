package com.company;

import java.util.Scanner;

public class Pr5 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double x, y, a;

        System.out.print("x ni radianda kiriting=");
        x = num.nextDouble();
        System.out.print("y ni radianda kiriting=");
        y = num.nextDouble();

        System.out.print("\n");

        a = (Math.sin(x + y) + Math.exp(x)) / (Math.cos(x) + Math.cos(y));
        System.out.println("sin(x+y) + e^x");
        System.out.println("---------------  =  " + a);
        System.out.println("cos(x) + cos(y)");
    }
}
