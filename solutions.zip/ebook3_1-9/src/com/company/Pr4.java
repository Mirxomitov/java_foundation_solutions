package com.company;

import java.util.Scanner;

public class Pr4 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double x, y, a;

        System.out.print("x ni radianda kiriting=");
        x = num.nextDouble();

        y = x * 180 / Math.PI;
        System.out.println("X gradusda=" + y);


        a = (Math.sin(x) + Math.cos(x)) / Math.cos(x);
        System.out.print("( sin(x) + cos(x) ) / cos(x) = " + a);
    }
}
