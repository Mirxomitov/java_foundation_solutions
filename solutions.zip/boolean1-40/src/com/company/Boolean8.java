package com.company;

import java.util.Scanner;

public class Boolean8 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a, b;

        System.out.println("a=");
        a = in.nextInt();
        System.out.println("b=");
        b = in.nextInt();

        boolean d = a % 2 != 0 && b % 2 != 0;
        System.out.println("a va b toq  :  " + d);
    }
}
