package com.company;

import java.util.Scanner;

public class Boolean9 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a, b;

        System.out.print("a=");
        a = in.nextInt();
        System.out.print("b=");
        b = in.nextInt();

        boolean d = a % 2 != 0 || b % 2 != 0;

        System.out.println("hech bo'lmaganda bittasi toq son :  " + d);
    }
}
