package com.company;

import java.util.Scanner;

public class Boolean11 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a, b;

        System.out.print("a=");
        a = in.nextInt();
        System.out.print("b=");
        b = in.nextInt();

        boolean d = (a % 2 == 0 && b % 2 == 0) || (a % 2 != 0 && b % 2 != 0);

        System.out.println("ikkalasi ham toq yoki juft toq son :  " + d);
    }
}
