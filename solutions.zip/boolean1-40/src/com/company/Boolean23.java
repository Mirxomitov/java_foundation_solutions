package com.company;

import java.util.Scanner;

public class Boolean23 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("3 xonali son");
        int a, b, c;

        System.out.print("a=");
        a = in.nextInt();

        boolean d = a % 10 == a / 100  && a / 100 > 0;

        System.out.println("Sonni o'ngdan va chapdan o'qiganingizda bir xil:  " + d);
    }
}
