package com.company;

import java.util.Scanner;

public class Boolean31 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b, c;

        System.out.print("a=");
        a = in.nextDouble();
        System.out.print("b=");
        b = in.nextDouble();
        System.out.print("c=");
        c = in.nextDouble();

        boolean d = ((a == b && b != c) || (a == c && b != c) || (c == b && a != c)) && (a + b > c && a + c > b && b + c >a );
        System.out.println("ABC uchburchak teng yonli  : " + d);
    }
}
