package com.company;

import java.util.Scanner;

public class Boolean34 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int x, y;
        System.out.println("8 x 8 o'lchamdagi shaxmat doskasi uchun koordinatalarni kiriting :\n Doska koordinatalar sistemasining II choragida yotadi");

        System.out.println("=================================================================\n");

        System.out.print("x=");
        x =  in.nextInt();
        System.out.print("y=");
        y = in.nextInt();

        boolean d = (x + y) % 2 != 0 && x <= 8 && x > 0 && y <= 8 && y > 0 ;

        System.out.println("Shaxmat doskasining oq katagi  : " + d);
    }
}
