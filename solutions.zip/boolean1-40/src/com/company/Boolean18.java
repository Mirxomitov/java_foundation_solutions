package com.company;

import java.util.Scanner;

public class Boolean18 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a, b, c;

        System.out.print("a=");
        a = in.nextInt();
        System.out.print("b=");
        b = in.nextInt();
        System.out.print("c=");
        c = in.nextInt();

        boolean d = a == b || b == c;

        System.out.println("kamida ikkitasi bir biriga teng  :  " + d);
    }
}
