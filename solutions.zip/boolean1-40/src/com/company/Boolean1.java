//Muallif: Mirxomitov Tohir
//Sana: 14.11.2022
//Maqsad:Jumlani rostlikka tekshirish
package com.company;

import java.util.Scanner;

public class Boolean1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a;

        System.out.print("a=");
        a = in.nextInt();

        boolean b = a > 0;
        System.out.println(b);

    }
}
