package com.company;

import java.util.Scanner;

public class Boolean24 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a, b, c;

        System.out.println("A=");
        a = in.nextInt();
        System.out.println("B=");
        b = in.nextInt();
        System.out.println("C=");
        c = in.nextInt();

        boolean d = b * b - 4 * a * c >= 0;

        System.out.println("Ax^2+Bx+C=0 tenglama haqiqiy ildizga ega : " + d);
    }
}
