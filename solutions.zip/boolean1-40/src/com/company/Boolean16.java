package com.company;

import java.util.Scanner;

public class Boolean16 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("2 xonali son");
        int a;

        System.out.print("a=");
        a = in.nextInt();

        boolean d = a / 10 > 0 && a / 10 <= 9 && a % 2 == 0;

        System.out.println("ikki xonali juft son :  " + d);
    }
}
