//Muallif: Mirxomitov Tohir
//Sana: 14.11.2022
//Maqsad:Jumlani rostlikka tekshirish
package com.company;

import java.util.Scanner;

public class Boolean5 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a, b;

        System.out.print("a=");
        a = in.nextInt();
        System.out.print("b=");
        b = in.nextInt();

        boolean c = (a >= 2) && (b < -2);
        System.out.println("a >= 2, b < -2 : " + c);
    }
}
