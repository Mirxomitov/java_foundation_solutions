    package com.company;

    import java.util.Scanner;

    public class Boolean20 {
        public static void main(String[] args) {
            Scanner in = new Scanner(System.in);
            System.out.println("3 xonali son");
            int a, b, c;

            System.out.print("a=");
            a = in.nextInt();

            boolean d = a % 10 != a / 10 % 10 && a / 10 % 10 != a / 100 ;

            System.out.println("Barcha raqamlari har xil :  " + d);
        }
    }
