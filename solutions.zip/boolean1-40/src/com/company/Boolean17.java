package com.company;

import java.util.Scanner;

public class Boolean17 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("3 xonali son");
        int a;

        System.out.print("a=");
        a = in.nextInt();

        boolean d = a / 100 > 0 && a / 100 <= 9 && a % 2 != 0;

        System.out.println("Uch xonali toq son :  " + d);
    }
}
