package com.company;

import java.util.Scanner;

public class Boolean35 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int x1, y1, x2, y2;

        System.out.print("x1=");
        x1 =  in.nextInt();
        System.out.print("y1=");
        y1 = in.nextInt();

        System.out.print("x2=");
        x2 =  in.nextInt();
        System.out.print("y2=");
        y2 = in.nextInt();

        boolean d = (x1 + y1) % 2 == (x1 + y1) % 2 && (x1 + y1) % 2 != (x1 + y1) % 2 && x1 <= 8 && x1 > 0 && y1 <= 8 && y1 > 0 && x2 <= 8 && x2 > 0 && y2 <= 8 && y2 > 0;

        System.out.println("Shaxmat doskasining bir xil rangli katagida : " + d);
    }
}
