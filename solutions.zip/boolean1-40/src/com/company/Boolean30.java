package com.company;

import java.util.Scanner;

public class Boolean30 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b, c;

        System.out.print("a=");
        a = in.nextDouble();
        System.out.print("b=");
        b = in.nextDouble();
        System.out.print("c=");
        c = in.nextDouble();

        boolean d = a == b && b == c;
        System.out.println("ABC uchburchak teng tomonli  : " + d);
    }
}
