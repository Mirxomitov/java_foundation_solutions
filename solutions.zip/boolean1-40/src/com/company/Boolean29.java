package com.company;

import java.util.Scanner;

public class Boolean29 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int x, y, x1, y1, x2, y2;

        System.out.print("x=");
        x = in.nextInt();
        System.out.print("y=");
        y = in.nextInt();
        System.out.print("x1=");
        x1 = in.nextInt();
        System.out.print("y1=");
        y1 = in.nextInt();
        System.out.print("x2=");
        x2 = in.nextInt();
        System.out.print("y2=");
        y2 = in.nextInt();

        boolean d = (x > x1 && y < y1) && (x < x2 && y > y2);

        System.out.print("(x,y) nuqta  chap yuqori burchagi (x1,y1), o'ng pastki burchagi (x2,y2) bo'lgan va ");

        System.out.printf("yon tomoni koordinata o'qlariga parallel bo'lgan to'rtburchak ichida yotadi : %s%n", d);
    }
}