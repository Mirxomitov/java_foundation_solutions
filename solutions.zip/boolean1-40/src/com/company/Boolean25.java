package com.company;

import java.util.Scanner;

public class Boolean25 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double x, y;

        System.out.print("x=");
        x = in.nextInt();
        System.out.print("y=");
        y = in.nextInt();

        boolean d = x < 0 && y > 0;

        System.out.println("koordinatalari (x;y) bo'lgan nuqta 2-chorakda  :  " + d);
    }
}
