//Muallif:Mirxomitov Toihr
// Sana:12.11.2022
//Maqsad:Aylana diametri va radiusini aniqlash
package com.company;

import java.util.Scanner;

public class begin15 {
    public static void main(String[] args) {

        Scanner num = new Scanner(System.in);

        double s, r;

        System.out.print("Aylana yuzasi S=");
        s = num.nextDouble();

        r = Math.sqrt(s / Math.PI);

        System.out.println("d=" + 2 * r);
        System.out.println("r=" + r);

    }
}
