//Muallif:Mirxomitov Tohir
// Sana:13.11.2022
// Funksiya qiymatini x0 da aniqlash
package com.company;


import java.util.Scanner;

public class begin26 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double x, y;

        System.out.println("4(x - 3)^6 - 7(x - 3)^3 + 2 funksiya berilgan:");
        System.out.print("x=");
        x = num.nextDouble();

        y = 4 * Math.pow(x - 3, 6) - 7 * Math.pow(x - 3, 3)  + 2;

        System.out.println("x=" + x + "  qiymatda   4(x - 3)^6 - 7(x - 3)^3 + 2  funksiyaning qiymati   " + y + "  ga teng");


    }
}
