//Muallif:Mirxomitov Tohir
// Sana:13.11.2022
//Maqsad:1 kg shokolad va konfet narxini va narx tafovutini aniqlash
package com.company;

import java.util.Scanner;

public class begin34 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a, b, x, y;

        System.out.print("Necha kg shokolad sotib oldingiz: ");
        x = num.nextDouble();
        System.out.print("Necha pul to'ladingiz:");
        a = num.nextDouble();

        System.out.print("Necha kg konfet sotib oldingiz: ");
        y = num.nextDouble();
        System.out.print("Necha pul to'ladingiz:");
        b = num.nextDouble();

        System.out.println("1 kg shokolad narxi :" + a / x);
        System.out.println("1 kg konfet narxi :" + b / y);

        System.out.print("1 kg shokolad va 1kg konfetning narx tafovuti: " + Math.abs(a / x - b / y));
    }
}