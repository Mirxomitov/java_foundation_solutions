//Muallif:Mirxomitov Tohir
//Sana:13.11.2022
//Maqsad:A1, B1, C1 va A2, B2, C2 koeffisientlardan iborat bo'lgan chiziqli tenglamalar sistemasida x va y ni topish
package com.company;

import java.util.Scanner;

public class begin40 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a1, b1, c1, a2, b2, c2, D;

        System.out.println("A1*X + B1*Y = C1");
        System.out.println("A2*X + B2*Y = C2\n");
        System.out.println("tenglamalar sistemasi uchun ma'lumotlarni kiriting: \n");


        System.out.print("A1 = ");
        a1 = num.nextDouble();
        System.out.print("B1 = ");
        b1 = num.nextDouble();
        System.out.print("C1 = \n");
        c1 = num.nextDouble();

        System.out.print("A2 = ");
        a2 = num.nextDouble();
        System.out.print("B2 = ");
        b2 = num.nextDouble();
        System.out.print("C2 = ");
        c2 = num.nextDouble();

        D = a1 * b2 - b1 * a2;

        System.out.println("x=" + (c1 * b2 - c2 * b1) / D);
        System.out.println("y=" + (a1 * c2 - a2 * c1) / D);
    }
}
