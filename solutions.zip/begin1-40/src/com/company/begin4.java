// Muallif: Mirxomitov Tohir
// Sana: 12.11.2022
//Maqsad: Aylana diametri va uzunligini topish
package com.company;

import java.util.Scanner;

public class begin4 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double d;
        final double pi = 3.14;
        System.out.print("Aylana diametri d=");
        d = num.nextDouble();

        System.out.println("Uzunligi L=" + pi * d);
    }
}
