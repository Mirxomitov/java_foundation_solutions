//Muallif: Mirxomitov Tohir
//Sana:12.11.2022
//Maqsad:To'g'ri burchakli uchburchak uchun c, S, P ni topish
package com.company;

import java.util.Scanner;

public class begin12 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a, b;

        System.out.print("a=");
        a = num.nextDouble();
        System.out.print("b=");
        b = num.nextDouble();

        System.out.println("c=" + Math.sqrt(a * a + b * b));
        System.out.println("S=" + (a * b) / 2);
        System.out.println("P=" + (a + b + Math.sqrt(a * a + b * b)));

    }
}
