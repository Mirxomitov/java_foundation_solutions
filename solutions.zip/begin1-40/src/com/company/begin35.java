//Muallif:Mirxomitov Tohir
// Sana:13.11.2022
//Maqsad:Qayiqning oqim bo'ylab va unga qarshi harakatlangan yo'li va ularning yig'indisini aniqlash
package com.company;

import java.util.Scanner;

public class begin35 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double v, u, t1, t2;

        System.out.print("V qayiq=");
        v = num.nextDouble();
        System.out.print("V oqim=");
        u = num.nextDouble();

        System.out.print("Oqim bo'yicha harakatlanishga ketgan vaqt = ");
        t1 = num.nextDouble();
        System.out.print("Oqimga qarshi harakatlanishga ketgan vaqt = ");
        t2 = num.nextDouble();

        System.out.println("Daryo oqimi bo'yicha bosib o'tgan yo'li S1=" + v * t1);
        System.out.println("Daryo oqimiga qarshi bosib o'tgan yo'li S2=" + u * t2);
        System.out.println("S1 + S2=" + (v * t1 + u * t2));
    }
}
