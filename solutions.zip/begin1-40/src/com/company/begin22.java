//Muallif:Mirxomitov Tohir
// Sana:13.11.2022
//Maqsad:a va b sonlarining qitmatini o'zaro almashtirish
package com.company;

import java.util.Scanner;

public class begin22 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        int a, b;

        System.out.print("a0 = ");
        a = num.nextByte();
        System.out.print("b0 = ");
        b = num.nextByte();

        a = a + b;
        b = a - b;
        a = a - b;

        System.out.println("a1 = " + a);
        System.out.println("b1 = " + b);

    }
}