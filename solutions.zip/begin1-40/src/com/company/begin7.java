//Muallif: Mirxomitov Tohir
//Sana: 12.11.2022
//Maqsad: Aylana uzunligi va yuzini topish
package com.company;

import java.util.Scanner;

public class begin7 {
    public static void main(String[] args) {

        Scanner num = new Scanner(System.in);

        double R;

        System.out.print("R=");
        R = num.nextDouble();

        System.out.println("Aylana uzunligi L=" + 2 * R);
        System.out.println("Yuzi S=" + Math.PI * R * R);
    }
}
