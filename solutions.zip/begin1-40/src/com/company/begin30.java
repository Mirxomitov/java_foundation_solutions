//Muallif:Mirxomitov Tohir
// Sana:13.11.2022
//Maqsad: Radiandan gradusga o'tkazish
package com.company;

import java.util.Scanner;

public class begin30 {

    public static void main(String[] args) {

        Scanner grad = new Scanner(System.in);

        Double a;

        System.out.print("alpha gradusda= ");
        a = grad.nextDouble();

        System.out.println("alpha radianda= " + a * 180 / Math.PI);

    }

}
