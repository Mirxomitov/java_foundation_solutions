//Muallif:Mirxomitov Tohir
// Sana:13.11.2022
//Maqsad:Konfet narxini aniqlash
package com.company;

import java.util.Scanner;

public class begin33 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a, x, y;

        System.out.print("Necha kg konfet sotib oldingiz: ");
        x = num.nextDouble();
        System.out.print("Necha pul to'ladingiz:");
        a = num.nextDouble();

        System.out.println("1 kg konfet narxi :" + a / x);

        System.out.print("Yana necha kg harid qilmoqchisiz: ");
        y = num.nextDouble();
        System.out.println(y + "  kg konfet narxi: " + y * a / x + "so'm " );

    }
}
