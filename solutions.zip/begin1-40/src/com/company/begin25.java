//Muallif:Mirxomitov Tohir
// Sana:13.11.2022
// Funksiya qiymatini x0 da aniqlash
package com.company;

import java.util.Scanner;

public class begin25 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double x, y;

        System.out.println("3x^6 - 6x^2 - 7 funksiya berilgan:");
        System.out.print("x=");
        x = num.nextDouble();

        y = 3 * Math.pow(x, 6) - 6 * x * x - 7;

        System.out.println("x=" + x + "  qiymatda   3x^6 - 6x^2 - 7   funksiyaning qiymati   " + y + "  ga teng");


    }
}
