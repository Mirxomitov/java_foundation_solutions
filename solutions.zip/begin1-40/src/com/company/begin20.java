//Muallif:Mirxomitov Tohir
// Sana:12.11.2022
// Maqsad: Tekislikda berilgan ikki nuqta orasidagi masofani aniqlash
package com.company;

import java.util.Scanner;

public class begin20 {
    public static void main(String[] args) {

        Scanner koord = new Scanner(System.in);

        double x1, y1, x2, y2;
        System.out.println("A(x1,y1) va B(x2,y2)");

        System.out.print("x1=");
        x1 = koord.nextDouble();
        System.out.print("y1=");
        y1 = koord.nextDouble();

        System.out.print("x2=");
        x2 = koord.nextDouble();
        System.out.print("y2=");
        y2 = koord.nextDouble();

        System.out.println("A va B nuqtalar orasidagi masofa=" + Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2)));
    }
}
