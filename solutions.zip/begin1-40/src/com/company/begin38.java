//Muallif:Mirxomitov Tohir
//Sana:13.11.2022
//Maqsad:Ax+B=0 tenglamada A va B ga qiymat berilganda x ni topish

package com.company;

import java.util.Scanner;

public class begin38 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a, b;

        System.out.println("Ax + B = 0 tenglama uchun ma'lumotlarni kiriting: ");
        System.out.print("A = ");
        a = num.nextDouble();
        System.out.print("B = ");
        b = num.nextDouble();

        System.out.print("\n");

        System.out.println(a + " * x + ( " + b + ") = 0  ");

        System.out.println("x = " +(- a / b));
    }
}
