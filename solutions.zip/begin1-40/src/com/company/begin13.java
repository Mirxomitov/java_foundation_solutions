//Muallif: Mirxomitov Tohir
//Sana: 12.11.2022
//Maqsad: Umumiy markazga ega bo'lgan aylanalar yuzlari va ularning ayirmasini aniqlash
package com.company;

import java.util.Scanner;

public class begin13 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double r1, r2;

        System.out.print("R1=");
        r1 = num.nextDouble();
        System.out.print("R2=");
        r2 = num.nextDouble();

        System.out.println("1-aylana yuzi=" + Math.PI * r1 *r1);
        System.out.println("2-aylana yuzi=" + Math.PI * r2 *r2);

        System.out.println("Aylanalar yuzalari farqi=" + Math.abs(Math.PI * r1 *r1 - Math.PI * r2 *r2));
    }
}
