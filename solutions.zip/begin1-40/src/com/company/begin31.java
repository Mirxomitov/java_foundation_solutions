//Muallif:Mirxomitov Tohir
// Sana:13.11.2022
//Maqsad: Farengeytdan gradus Selsiyga o'tkazish

package com.company;

import java.util.Scanner;

public class begin31 {
    public static void main(String[] args) {

        Scanner tmp = new Scanner(System.in);

        Double a;

        System.out.print("t(F)= ");
        a = tmp.nextDouble();

        System.out.println("t(`C)=" + (a - 32) * 5 / 9);
    }

}
