//Muallif: Mirxomitov Tohir
//Sana:12.11.2022
//Maqsad:Parallelepipedning hajmi va to'la sirtini topish
package com.company;

import java.util.Scanner;

public class begin6 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a, b, c;

        System.out.println("SHART: a, b, c > 0");

        System.out.print("a="); // cout <<
        a = num.nextDouble();   // cin >>

        System.out.print("b=");
        b = num.nextDouble();

        System.out.print("c=");
        c = num.nextDouble();

        System.out.println("Parallelepipiedning hajmi V= " + a * b *c);

        System.out.println("Parallelepipiedning to'la sirti S=" + 2 * (a * b + a * c + b * c));
    }
}
