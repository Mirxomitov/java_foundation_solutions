//Muallif:Mirxomitov Tohir
// Sana:12.11.2022
// Maqsad:Koordinatalar o'qida A, B, C nuqtalardan yasalgan ABC uchburchak yuzasi va perimetrini aniqlash
package com.company;

import java.util.Scanner;

public class begin21 {
        public static void main(String[] args) {

            Scanner koord = new Scanner(System.in);

            double a, b, c, p, x1, y1, x2, y2, x3, y3;
            System.out.println("A(x1, y1), B(x2, y2), C(x3, y3)");

            System.out.print("x1=");
            x1 = koord.nextDouble();
            System.out.print("y1=");
            y1 = koord.nextDouble();

            System.out.print("x2=");
            x2 = koord.nextDouble();
            System.out.print("y2=");
            y2 = koord.nextDouble();

            System.out.print("x3=");
            x3 = koord.nextDouble();
            System.out.print("y3=");
            y3 = koord.nextDouble();

            a = Math.sqrt(Math.pow(x3 - x2, 2) + Math.pow(y3 - y2, 2));
            b = Math.sqrt(Math.pow(x1 - x3, 2) + Math.pow(y1 - y3, 2));
            c = Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));

            p = (a + b + c) / 2;

            System.out.println("ABC uchburchak yuzasi    S=" + Math.sqrt(p * (p - a) * (p - b) * (p - c)));
            System.out.println("ABC uchburchak perimetri P=" + p * 2 );
        }
    }


