//Muallif:Mirxomitov Tohir
//Sana:13.11.2022
//Maqsad: t vaqtdan keyin avtomobillar orasidagi masofani aniqlash
package com.company;

import java.util.Scanner;

public class begin37 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double v1, v2, s, t;

        System.out.print("V1 (km / h) = ");
        v1 = num.nextDouble();
        System.out.print("V2 (km / h) = ");
        v2 = num.nextDouble();
        System.out.print("Avtomobillar orasidagi masofa S1 (km) = ");
        s = num.nextDouble();
        System.out.print("t (h) = ");
        t = num.nextDouble();

        System.out.print("t (h) vaqtdan keyin ular orasidagi masofa S2 (km) = " + Math.abs(s - (v1 + v2) * t));

    }
}
