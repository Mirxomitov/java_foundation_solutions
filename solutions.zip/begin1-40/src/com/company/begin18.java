//Muallif: Mirxomitov Tohir
// Sana:12.11.2022
// Maqsad: AC va BC kesmalar uzunligining ko'paytmasini aniqlash
package com.company;

import java.util.Scanner;

public class begin18 {
    public static void main(String[] args) {
        Scanner koord = new Scanner(System.in);

        double a , b, c;

        System.out.print("A nuqtaning OX o'qidagi koordinatasi:    ");
        a = koord.nextDouble();
        System.out.print("B nuqtaning OX o'qidagi koordinatasi:    ");
        b = koord.nextDouble();
        System.out.print("C nuqtaning OX o'qidagi koordinatasi:    ");
        c = koord.nextDouble();

        System.out.println("AC * BC = " + Math.abs(c - a) * Math.abs(c - b));
    }
}
