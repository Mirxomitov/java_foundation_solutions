//Muallif:Mirxomitov Tohir
//Sana:12.11.2022
//Maqsad: Kvadrat perimetrini aniqlash
package com.company;

import java.util.Scanner;

public class begin1 {

    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a, P;

        System.out.print("Kvadrat tomoni a=");
        a = num.nextDouble();

        P = 4 * a;

        System.out.println("Perimetri P=" + P);
    }
}