//Muallif:Mirxomitov Tohir
// Sana:13.11.2022
// Maqsad: Gradusdan radianga o'tkazish
package com.company;

import java.util.Scanner;

public class begin29 {

    public static void main(String[] args) {

        Scanner grad = new Scanner(System.in);

        Double a;

        System.out.print("alpha gradusda= ");
        a = grad.nextDouble();

        System.out.println("alpha radianda= " + a * Math.PI / 180);

    }

}
