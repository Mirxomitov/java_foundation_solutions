//Muallif:Mirxomitov Tohir
// Sana:13.11.2022
// a, b va c ning qiymatlarini a->b, b->c, c->a ga almashtirish
package com.company;

import java.util.Scanner;

public class begin23 {
    public static void main(String[] args) {
        Scanner lt = new Scanner(System.in);
        double a, b, c;

        System.out.print("a0=");
        a = lt.nextDouble();
        System.out.print("b0=");
        b = lt.nextDouble();
        System.out.print("c0=");
        c = lt.nextDouble();

        System.out.println("\n");

        a = a + b + c;
        b = a - b - c; // b = a
        c = a - b - c; // c = b
        a = a - b - c; // a = c

        System.out.println("a1=" + a);
        System.out.println("b1=" + b);
        System.out.println("c1=" + c);

    }

}
