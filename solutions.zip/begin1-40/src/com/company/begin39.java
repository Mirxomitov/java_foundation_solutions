//Muallif:Mirxomitov Tohir
//Sana:13.11.2022
//Maqsad:Ax^2+Bx+C=0 tenglamada A, B va C ga qiymat berilganda x ni topish

package com.company;

import java.util.Scanner;

public class begin39 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a, b, c, D;

        System.out.println("Ax^2 + Bx + C = 0 tenglama uchun ma'lumotlarni kiriting: ");
        System.out.print("A = ");
        a = num.nextDouble();
        System.out.print("B = ");
        b = num.nextDouble();
        System.out.print("C = ");
        c = num.nextDouble();

        System.out.print("\n");

        D = b * b - 4 * a * c;

        System.out.println(a + " * x^2 + " + b + " * x + " + c + " = 0 ");
        System.out.println("x1 = " + ((- b + Math.sqrt(D)) / (2 * a) ));
        System.out.println("x2 = " + ((- b - Math.sqrt(D)) / (2 * a) ));
    }
}
