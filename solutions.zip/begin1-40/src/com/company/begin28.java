//Muallif:Mirxomitov Tohir
// Sana:13.11.2022
// a soning darajalarini aniqlash
package com.company;

import java.util.Scanner;

public class begin28 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a;

        System.out.println("A="); a = num.nextDouble();

        System.out.println("A^2= " + a * a);
        System.out.println("A^3=" + Math.pow(a, 3));
        System.out.println("A^5=" + Math.pow(a, 5));
        System.out.println("A^10=" + Math.pow(a, 10));
        System.out.println("A^15=" + Math.pow(a, 15));

    }
}
