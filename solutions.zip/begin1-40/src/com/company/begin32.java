//Muallif:Mirxomitov Tohir
// Sana:13.11.2022
//Maqsad:Gradus Selsiydan Farengeytga o'tkazish

package com.company;

import java.util.Scanner;

public class begin32 {
    public static void main(String[] args) {

        Scanner tmp = new Scanner(System.in);

        Double a;

        System.out.print("t(`C)= ");
        a = tmp.nextDouble();

        System.out.println("t(F)=" + (a * 9 / 5 + 32));
    }

}
