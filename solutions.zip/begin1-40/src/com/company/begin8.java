//Muallif:Mirxomitov Tohir
//Sana: 12.11.2022
//Maqsad: Ikki son o'rta arifmetigini topish
package com.company;

import java.util.Scanner;

public class begin8 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a, b;

        System.out.print("a=");
        a = num.nextDouble();
        System.out.print("b=");
        b = num.nextDouble();

        System.out.println("O'rta arifmetigi = " + (a / 2 + b / 2));
    }
}
