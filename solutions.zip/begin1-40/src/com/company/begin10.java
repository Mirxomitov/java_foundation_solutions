// Muallif: Mirxomitov Tohir
// Sana: 12.11.2022
// Maqsad: Ikki sonning yig'indisi, ko'paytmasi va har birining kvadratini aniqlash
package com.company;

import java.util.Scanner;

public class begin10 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a, b;

        System.out.print("a=");
        a = num.nextDouble();
        System.out.print("b=");
        b = num.nextDouble();

        System.out.println("a + b=" + (a + b));
        System.out.println("a * b=" + (a * b));
        System.out.println("a kvadrat=" + (a * a));
        System.out.println("b kvadrat=" + (b * b));
    }
}
