// Muallif: Mirxomitov Tohir
// Sana: 12.11.2022
//Maqsad: Kub hajmi va to'la sirtini aniqlash
package com.company;

import java.util.Scanner;

public class begin5 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a;

        System.out.print("a= ");
        a = num.nextDouble();

        System.out.println("Kub hajmi V=" + Math.pow(a, 3));
        System.out.println("To'la sirti S=" + 6 * Math.pow(a, 2));
    }
}
