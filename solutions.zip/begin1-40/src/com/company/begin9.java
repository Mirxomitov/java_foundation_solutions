//Muallif:Mirxomitov Tohir
//Sana: 12.11.2022
//Maqsad: Ikki son o'rta geometrigini topish
package com.company;

import java.util.Scanner;

public class begin9 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a, b;

        System.out.print("a=");
        a = num.nextDouble();
        System.out.print("b=");
        b = num.nextDouble();

        System.out.println("O'rta geometrigi = " + Math.sqrt(a * b));
    }
}
