//Muallif:Mirxomitov Tohir
//Sana:12.11.2022
//Maqsad: Kvadrat yuzasini aniqlash
package com.company;

import java.util.Scanner;

public class begin2 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a, S;

        System.out.print("Kvadrat tomoni a=");
        a = num.nextDouble();

        S = a * a;

        System.out.println("Yuzasi S=" + S);
    }
}
