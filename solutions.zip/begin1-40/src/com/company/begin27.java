//Muallif:Mirxomitov Tohir
// Sana:13.11.2022
// a soning darajalarini aniqlash
package com.company;

import java.util.Scanner;

public class begin27 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a;

        System.out.println("A="); a = num.nextDouble();

        System.out.println("A^2= " + a * a);
        System.out.println("A^4=" + Math.pow(a, 4));
        System.out.println("A^8=" + Math.pow(a, 8));
    }
}
