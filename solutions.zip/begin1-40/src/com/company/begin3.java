// Muallif: Mirxomitov Tohir
// Sana: 12.11.2022
//Maqsad: To'g'ri to'rtburchakning perimetrini va yuzasini topish
package com.company;

import java.util.Scanner;

public class begin3 {
    public static void main(String[] args) {

        Scanner num = new Scanner(System.in);

        double a, b;

        System.out.print("a=");
        a = num.nextDouble();

        System.out.print("b=");
        b = num.nextDouble();

        System.out.println("Perimetri P= " + 2 * (a + b));
        System.out.println("Yuzi S=" + a * b);
    }
}
