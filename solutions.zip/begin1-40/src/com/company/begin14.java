//Muallif:Mirxomitov Tohir
// Sana:12.11.2022
// Maqsad:  Aylana radiusi va yuzsini aniqlash
package com.company;

import java.util.Scanner;

public class begin14 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double L;

        System.out.print("Aylana uzunligi L=");
        L = num.nextDouble();

        System.out.println("R=" + L / 2);
        System.out.println("S=" + Math.PI * (L / 2) * (L / 2));
    }
}
