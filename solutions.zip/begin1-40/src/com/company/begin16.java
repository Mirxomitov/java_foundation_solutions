//Muallif: Mirxomitov Tohir
//Sana: 12.11.2022
// Maqsad: Sonlar o'qidagi ikki nuqta orasidagi masofani aniqlash
package com.company;

import java.util.Scanner;

public class begin16 {
    public static void main(String[] args) {

        Scanner num = new Scanner(System.in);

        double x1, x2;

        System.out.print("x1=");
        x1 = num.nextDouble();
        System.out.print("x2=");
        x2 = num.nextDouble();

        System.out.println("Orasidagi masofa=" + Math.abs(x1 - x2));
    }
}
