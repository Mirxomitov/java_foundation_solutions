//Muallif:Mirxomitov Tohir
// Sana:12.11.2022
// Maqsad: Qarama qarshi koordinatalari berilgan to'g'ri to'rtburchakning perimetri va yuzasini topish
package com.company;

import java.util.Scanner;

public class begin19 {
    public static void main(String[] args) {

        Scanner koord = new Scanner(System.in);

        double x1, y1, x2, y2;

        System.out.print("x1=");
        x1 = koord.nextDouble();
        System.out.print("y1=");
        y1 = koord.nextDouble();

        System.out.print("x2=");
        x2 = koord.nextDouble();
        System.out.print("y2=");
        y2 = koord.nextDouble();

        System.out.println("To'g'ri to'rtburchak perimetri P=" + 2 * (Math.abs(x1 - x2) + Math.abs(y1 - y2)) );
        System.out.println("To'g'ri to'rtburchak yuzasi    S=" + Math.abs(x1 - x2) * Math.abs(y1 - y2) );
    }
}
