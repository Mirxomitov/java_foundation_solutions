package com.company;

import java.util.Scanner;

public class pr7 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);
        double a, b;

        System.out.print("a=");
        a = num.nextInt();
        System.out.print("b=");
        b = num.nextInt();

        System.out.println(a + " ni " + b + " ga bo'lgandagi butun qism =" + (int) a / (int) b);
    }
}
