package com.company;

import java.util.Scanner;

public class pr9 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a, b;

        System.out.print("a0=");
        a = num.nextDouble();
        System.out.print("b0=");
        b = num.nextDouble();

        a = a + b;
        b = a - b;
        a = a - b;

        System.out.println("a1=" + a);
        System.out.println("b1=" + b);


    }
}
