//Muallif:Mirxomitov Tohir
//Sana:13.11.2022
//Maqsad:99 - 1000 oraliqdagi sonni 100 lar xonasini aniqlash
package com.company;

import java.util.Scanner;

public class pr1 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);
        short n;

        System.out.print("n=");
        n = num.nextShort();

        System.out.println(n + " sonining 100 lar xonasi : " + n / 100);
        
    }
}
