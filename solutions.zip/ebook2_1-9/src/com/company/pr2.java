//Muallif:Mirxomitov Tohir
//Sana:13.11.2022
//Maqsad:9 - 100 oraliqdagi sonlar uchun oxirgi raqami, birinchi raqami va raqamlari yig'indisini aniqlash
package com.company;

import java.util.Scanner;

public class pr2 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        byte n;

        System.out.print("n=");
        n = num.nextByte();

        System.out.println("1. " + n + " sonining oxirgi raqami: " + n % 10);
        System.out.println("2. " + n + " sonining birinchi raqami: " + n / 10);
        System.out.println("3. " + n + " sonining raqamlari yig'indisi: " + n / 10 + " + " + n % 10 + " = " + (n % 10 + n / 10) );
    }
}
