package com.company;

import java.util.Scanner;

public class pr6 {
    public static void main(String[] args) {
        Scanner koord = new Scanner(System.in);

        double x1, x2, y1, y2;

        System.out.print("x1=");
        x1 = koord.nextDouble();
        System.out.print("y1=");
        y1 = koord.nextDouble();

        System.out.print("x2=");
        x2 = koord.nextDouble();
        System.out.print("y2=");
        y2 = koord.nextDouble();

        System.out.print("A(x1;y1) va B(x2,y2) nuqtalar orasidagi masofa = " );
        System.out.println( Math.sqrt(Math.pow(x1 - x1, 2) + Math.pow(y1 - y2, 2)));
    }
}
