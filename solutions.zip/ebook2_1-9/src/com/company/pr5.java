package com.company;

import java.util.Scanner;

public class pr5 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a, n, d;

        System.out.print("arifmetik progressiyaning 1-hadi =");
        a = num.nextDouble();
        System.out.print("d=");
        d = num.nextDouble();
        System.out.print("hadlari soni n=");
        n = num.nextDouble();

        System.out.println("Hadlari yig'indisi S=" + (2 * a + d * (n - 1)) * n / 2);

    }
}
