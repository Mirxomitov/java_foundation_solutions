package com.company;

import java.util.Scanner;

public class pr4 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);

        double a, b, c, r;

        System.out.println("c=");
        c = num.nextDouble();
        System.out.println("a=");
        a = num.nextDouble();

        b = Math.sqrt(c * c - a * a);
        r = (a + b + c) / (a * b);

        System.out.println("b=" + b);
        System.out.println("r=" + r);
    }
}
