package com.company;

import java.util.Scanner;

public class pr3 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);
        double a, b, c, p, s;

        System.out.print("a=");
        a = num.nextDouble();
        System.out.print("b=");
        b = num.nextDouble();
        System.out.print("c=");
        c = num.nextDouble();

        p = (a + b + c) / 2;
        s = Math.sqrt(p * (p - a) * (p - b) * (p - c));

        System.out.printf("ABC uchburchak yuzasi    S= %.2f%n", s );
    }
}
