package com.company;

import java.util.Scanner;

public class pr8 {
    public static void main(String[] args) {
        Scanner num = new Scanner(System.in);
        double a, b;

        System.out.print("a=");
        a = num.nextInt();
        System.out.print("b=");
        b = num.nextInt();

        System.out.printf(a + " / " + b + " = %.4f%n", a / b);
        System.out.print("Javob verguldan keyingi 4 xonasigina ko'ringan holda berildi");
    }
}
