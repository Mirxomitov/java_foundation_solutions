import java.util.Scanner;

public class If10 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double a, b;
        a = in.nextDouble();
        b = in.nextDouble();

        if (a != b) {
            System.out.println("a != b => a + b = " + (a + b));
        }
        else {
            System.out.println("a == b => " + 0);
        }
    }

}