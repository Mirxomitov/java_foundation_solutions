import java.util.Scanner;

public class If13_2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b, c;

        a = in.nextDouble();
        b = in.nextDouble();
        c = in.nextDouble();

        if(b > a && a > c || c > a && a > b) System.out.println(a);
        if(a > b && b > c || c > b && b > a) System.out.println(b);
        if(a > c && c > b || b > c && c > a) System.out.println(c);
        else System.out.println("bu yerda 2 yoki undan ortiq son bir biriga teng\n o'rtadagi son mavjud emas");
    }
}
