public class If8 {
    public static void main(String[] args) {
        int num1= -9, num2 = -6;

        if (num1 > num2){
            System.out.println(num1);
            System.out.println(num2);
}
        else {
            System.out.println(num2);
            System.out.println(num1);
        }
    }
}
