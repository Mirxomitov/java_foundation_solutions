import java.util.Scanner;

public class If3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a;
        System.out.print("a=");
        a = in.nextDouble();
        System.out.println("=============");
        if(a > 0){
            System.out.println("yangi a=" + (a + 1));
        }
        else if(a == 0) {
            a = 0;
            System.out.println("a=" + a);
        }
        else {
            System.out.println("yangi a=" + (a - 2));
        }
    }
}
