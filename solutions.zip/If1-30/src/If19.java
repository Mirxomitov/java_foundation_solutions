import java.util.Scanner;

public class If19 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a, b, c, d;

        a = in.nextInt();
        b = in.nextInt();
        c = in.nextInt();
        d = in.nextInt();

        int TartibRaqami;

        if (a == b && b == c) {
            System.out.println("Tartib Raqami =" + 4);
        }
        else if (a == b && b == d ) {
            System.out.println("Tartib Raqami =" + 3);
        }
        else if (a == c && b == d){
            System.out.println("Tartib Raqami =" + 2);
        }
        else if(b == c && c == d){
            System.out.println("Tartib Raqami =" + 1);
        }
        else {
            System.out.println("bir xil sonlar 3 ta emas");
        }



    }
}
