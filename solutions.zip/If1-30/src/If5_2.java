public class If5_2 {
    public static void main(String[] args) {
        int num1 = 2, num2 = -5, num3 = 1;

        int musbatSonlar=0;

        if(num1>0) musbatSonlar++;
        if(num2>0) musbatSonlar++;
        if(num3>0) musbatSonlar++;

        System.out.println("Musbat sonlar: " + musbatSonlar);
        System.out.println("Manfiy sonlar: " + (3-musbatSonlar));
    }
}
