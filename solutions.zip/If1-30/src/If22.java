import java.util.Scanner;

public class If22 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double x1, x2;

        System.out.print("x1=");
        x1 = in.nextDouble();
        System.out.print("x2=");
        x2 = in.nextDouble();

        if(x1  > 0 && x2 > 0){
            System.out.println("I chorak");
        }
        else if(x1 < 0 && x2 > 0){
            System.out.println("II chorak");
        }
        else if(x1 < 0 && x2 < 0){
            System.out.println("III chorak");
        }
        else if(x1 > 0 && x2 < 0){
            System.out.println(0);
        }
        else if(x1 == 0 || x2 == 0){
            System.out.println("koordinata boshida yoki OX va OY o'qlaridan birida yotadi;");
        }
    }
}
