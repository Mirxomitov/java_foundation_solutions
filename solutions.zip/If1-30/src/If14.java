import java.util.Scanner;

public class If14 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b, c;
        a = in.nextDouble();
        b = in.nextDouble();
        c = in.nextDouble();

        if (a == b || b == c || a == c){
            System.out.println("2 yoki undan ortiq son bir-biriga teng");
        }

        else if (a > b && a > c) {
            System.out.println(a); System.out.println(Math.min(c,b));
        }
        else if (b > a && b > c) {
            System.out.println(b); System.out.println(Math.min(a,c));
        }
        else if(c > a && c > b){
            System.out.println(c); System.out.println(Math.min(b,c));
        }
    }
}
