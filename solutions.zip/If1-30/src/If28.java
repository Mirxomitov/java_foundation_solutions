import java.util.Scanner;

public class If28 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a;

        a = in.nextInt();

        if ((a % 100 == 0 || a % 200 == 0 || a % 300 == 0) && a % 400 != 0) {
            System.out.println("Kabisa yili emas");
        } else if (a % 4 == 0 || a % 400 == 0) {
            System.out.println("Kabisa yili");
        } else System.out.println("Kabisa yili emas");
    }
}
