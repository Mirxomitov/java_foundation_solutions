import java.util.Scanner;

public class If17 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b, c;

        a = in.nextDouble();
        b = in.nextDouble();
        c = in.nextDouble();

        if ( c > a && c > b) {
            System.out.println(2 * a);
            System.out.println(2 * b);
            System.out.println(2 * c);
        }
        else if (a > b && b > c) {
            System.out.println(2 * c);
            System.out.println(2 * b);
            System.out.println(2 * a);
        }
        else {
            System.out.println(a - 2 * a);
            System.out.println(b - 2 * b);
            System.out.println(c - 2 * c);
        }
    }
}