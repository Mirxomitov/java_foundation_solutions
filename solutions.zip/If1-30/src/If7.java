public class If7 {
    public static void main(String[] args) {
        int num1= 4, num2 = 5;


        if(num1 > num2) {
            System.out.println("Tartib Raqami=1" );
        }
        else{
            System.out.println("Tartib Raqami=2" );
        }
    }
}
