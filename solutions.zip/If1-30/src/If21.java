import java.util.Scanner;

public class If21 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double x1, x2;

        System.out.print("x1=");
        x1 = in.nextDouble();
        System.out.print("x2=");
        x2 = in.nextDouble();

        if(x1 == 0 && x2 == 0){
            System.out.println(0);
        }
        else if(x2 == 0){
            System.out.println(1);
        }
        else if(x1 == 0){
            System.out.println(2);
        }
        else {
            System.out.println(3);
        }
    }
}
