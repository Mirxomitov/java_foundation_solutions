import java.util.Scanner;

public class If11 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double a, b;
        a = in.nextDouble();
        b = in.nextDouble();

        if (a != b) {
            if(a > b){
                System.out.println(a);
            }
            else {
                System.out.println(b);
            }
        }
        else {
            System.out.println("a == b => " + 0);
        }
    }

}