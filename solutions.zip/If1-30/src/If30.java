import java.util.Scanner;

public class If30 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a;
        a = in.nextInt();

        if (a % 2 == 0 && a > 0) {
            if (a / 9 < 1) {
                System.out.println("1 xonali juft son");
            } else if (a / 99 < 1) {
                System.out.println("2 xonali juft son");
            } else if (a / 999 < 1) {
                System.out.println("3 xonali juft son");
            }
        }
        else if (a % 2 != 0 && a > 0) {
            if (a / 9 < 1) {
                System.out.println("1 xonali toq son");
            } else if (a / 99 < 1) {
                System.out.println("2 xonali toq son");
            } else if (a / 999 < 1) {
                System.out.println("3 xonali toq son");
            }
        }

        else {
            System.out.println("Nolga teng yoki 1-999 oraliqda emas");
        }
    }
}
