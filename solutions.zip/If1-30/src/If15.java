import java.util.Scanner;

public class If15 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b, c;

        a = in.nextDouble();
        b = in.nextDouble();
        c = in.nextDouble();

        double s1, s2, s3;

        s1 = a + b ;
        s2 = a + c;
        s3 = b + c;

        if(s1 > s2 && s1 > s3) System.out.println(s1);
        if(s2 > s1 && s2 > s3) System.out.println(s2);
        if(s3 > s1 && s3 > s2) System.out.println(s3);
        else System.out.println("2 yoki undan ko'p sonlar bir-biriga teng");
    }
}
