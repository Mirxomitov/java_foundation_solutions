public class If5 {
    public static void main(String[] args) {


        double a = 2, b = -5, c = 1;

        boolean isTrue = a > 0 && b > 0 && c > 0;

        if(isTrue){
            System.out.println("3 ta musbat 0 ta manfiy");
        }
        else if((a > 0 && b > 0 && c < 0)|| (a > 0 && b < 0 && c > 0) || (a < 0 && b > 0 && c > 0)){
            System.out.println("2 ta musbat 1 ta manfiy");
        }
        else if((a > 0 && b < 0 && c < 0)|| (a < 0 && b > 0 && c < 0) || (a < 0 && b < 0 && c > 0)){
            System.out.println("1 ta musbat 2 ta manfiy");
        }
        else {
            System.out.println("0 ta musbat 3 ta manfiy");
        }
    }
}
