import java.util.Scanner;

public class If9 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
     double a, b;
     a = in.nextDouble();
     b = in.nextDouble();

     if (a < b){
         System.out.println("a=" + a);
         System.out.println("b=" + b);
     }
        else {
            a = a + b;
            b = a - b;
            a = a - b;

         System.out.println("a=" + a);
         System.out.println("b=" + b);
     }


    }
}
