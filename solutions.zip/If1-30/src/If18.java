import java.util.Scanner;

public class If18 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int a, b, c;

        a = in.nextInt();
        b = in.nextInt();
        c = in.nextInt();

        int TartibRaqami;

        if (a == b) {
            System.out.println("Tartib Raqami =" + 3);
        }
       else if (a == c) {
            System.out.println("Tartib Raqami =" + 2);
        }
        else if (b == c){
            System.out.println("Tartib Raqami =" + 1);
        }
        else {
            System.out.println("bir xil sonlar 3 ta yoki ular mavjud emas");
        }



    }
}
