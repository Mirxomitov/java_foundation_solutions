import java.util.Scanner;

public class If2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a;
        System.out.print("a=");
        a = in.nextDouble();
        System.out.println("=============");
        if(a > 0){
            System.out.println("yangi a=" + (a + 1));
        }
        else {
            System.out.println("yangi a=" + (a - 2));
        }
    }
}
