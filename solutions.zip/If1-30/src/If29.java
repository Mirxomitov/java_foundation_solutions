import java.util.Scanner;

public class If29 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a;
        a = in.nextInt();

        if (a > 0) {
            if (a % 2 == 0) {
                System.out.println("Musbat juft son");
            } else {
                System.out.println("Musbat toq son");
            }
        } else if (a < 0) {
            if (a % 2 == 0) {
                System.out.println("Manfiy juft son");
            } else {
                System.out.println("Manfiy toq son");
            }
        } else {
            System.out.println("Nolga teng");
        }
    }
}
