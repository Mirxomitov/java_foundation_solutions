import java.util.Scanner;

public class If20 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b, c;
        System.out.print("a=");
        a = in.nextDouble();
        System.out.print("b=");
        b = in.nextDouble();
        System.out.print("c=");
        c = in.nextDouble();

        if (Math.abs(a - b) == Math.abs(a - c)){
            System.out.println("orasidagi masofa teng");
        }
        else if(Math.abs(a - b) > Math.abs(a - c)){
            System.out.println("Eng yaqin nuqta c=" + c);
            System.out.println("Ular orasidagi masofa = " + Math.abs(a - c));
        }
       else if(Math.abs(a - b) < Math.abs(a - c)){
            System.out.println("Eng yaqin nuqta b=" + b);
            System.out.println("Ular orasidagi masofa = " + Math.abs(a - b));
        }
    }
}
