import java.util.Scanner;

public class If27 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double x;
        System.out.println("x=");
        x = in.nextDouble();

        if(Math.floor(x) % 2 == 0) System.out.println(1);
        else if (Math.floor(x) % 2 != 0) System.out.println(-1);

        else if(x < 0) {
            System.out.println(0);
        }
    }
}
