import java.util.Scanner;

public class If23 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double x1, y1, x2, y2, x3, y3, x4, y4;

        System.out.print("x1 = ");
        x1 = in.nextDouble();
        System.out.print("y1  = ");
        y1 = in.nextDouble();

        System.out.print("x2 = ");
        x2 = in.nextDouble();
        System.out.print("y2  = ");
        y2 = in.nextDouble();

        System.out.print("x3 = ");
        x3 = in.nextDouble();
        System.out.print("y3  = ");
        y3 = in.nextDouble();

       if (x1 == x2 ) System.out.println("x4 = " + x3);
       else if(x1 ==x3) System.out.println("x4 =" + x2);
       else if(x2 == x3)System.out.println("x4 = " + x1);

       if (y1 == y2) System.out.println("y4 = " + y3);
       else if (y1 == y3) System.out.println("y4 = " + y2);
       else if(y2 == y3) System.out.println("y4 =" + y1);
    }
}
