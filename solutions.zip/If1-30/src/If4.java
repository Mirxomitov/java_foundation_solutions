import java.util.Scanner;

public class If4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double b, a, c;

        System.out.print("a=");
        a = in.nextDouble();
        System.out.print("b=");
        b = in.nextDouble();
        System.out.print("c=");
        c = in.nextDouble();

        boolean isTrue = a > 0 && b > 0 && c > 0;

        if(isTrue){
            System.out.println(3);
        }
        else if((a > 0 && b > 0 && c < 0)|| (a > 0 && b < 0 && c > 0) || (a < 0 && b > 0 && c > 0)){
            System.out.println(2);
        }
        else if((a > 0 && b < 0 && c < 0)|| (a < 0 && b > 0 && c < 0) || (a < 0 && b < 0 && c > 0)){
            System.out.println(1);
        }
        else {
            System.out.println(0);
        }
    }
}
