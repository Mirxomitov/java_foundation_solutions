import java.util.Scanner;

public class If12 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b, c;
        a = in.nextDouble();
        b = in.nextDouble();
        c = in.nextDouble();

        if ((a <= b && a <= c) ) {
            System.out.println(a);
        }
        else if (b <= a && b <= c){
            System.out.println(b);
        }
        else if (c <= a && c <= b ){
            System.out.println(c);
        }
       else {
            System.out.println(0);
        }
    }
}
