import java.util.Scanner;

public class If13 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b, c;

        a = in.nextDouble();
        b = in.nextDouble();
        c = in.nextDouble();

        if(a >= b && b >= c || c >= b && b >= a) {
            if (a == c){
                System.out.println(c);
            }
            else {
                System.out.println(b);
            }
        }
        else if(b >= a && a >= c || c >= a && a >= b  ){
            if (b == c){
                System.out.println(c);
            }
            else {
                System.out.println(a);
            }
        }
        else if(b >= c && c >= a || a >= c && c >= b){
            if (b == a){
                System.out.println(a);
            }
            else {
                System.out.println(c);
            }
        }
        else {
            System.out.println(0);
        }
    }
}
