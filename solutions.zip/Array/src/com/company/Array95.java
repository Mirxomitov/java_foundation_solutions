package com.company;

import java.util.Arrays;

public class Array95 {
    public static void main(String[] args) {

        int[] arr = {3, 2,3,2,2}; // 13
        System.out.println(Arrays.toString(arr));

        int counter = 1;
        for (int i = 0; i < arr.length - 1; i++) {
            if (arr[i] != arr[i + 1]) {
                arr[counter] = arr[i + 1];
                counter++;
            }
        }
        int[] arr0 = new int[arr.length - counter];

        for (int i = 0; i < arr0.length; i++) {
            arr0[i] = arr[i];
        }
        System.out.println(Arrays.toString(arr0));

    }
}
