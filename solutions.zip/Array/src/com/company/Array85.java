package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array85 {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        int[] arr = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};


        System.out.print("k [" + 1 + " - " + (arr.length - 1) + "] oraliqda" + "\nk = ");
        int k = in.nextInt();
        while (k <= 0 || k > arr.length) {
            System.out.print("k xato kiritildi \nk = ");
            k = in.nextInt();
        }

        int[] arrk = new int[k];

        System.out.println(Arrays.toString(arr) + " -> arr  ");

        /* 1 */
        for (int i = 0; i < k; i++) {
            arrk[k - i - 1] = arr[arr.length - i - 1];
        }

        /* 2 */
        for (int i = 0; i < k; i++) {
            for (int j = arr.length - 2; j > 0; j--) {
                arr[j + 1] = arr[j];
                arr[j] = 0;
            }
        }

        /* 3 */
        for (int i = k; i > 0; i--) {
            arr[k - i] = arrk[k - i];
        }

        System.out.println(Arrays.toString(arr));
    }
}

class Array85_2 {
    public static void main(String[] args) {

    }
}