package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array6 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();
        int A = in.nextInt(), B = in.nextInt();

        int[] sum = new int[n];

        sum[0] = A;
        sum[1] = B;

        for (int i = 2; i < n; i++) {

            for (int j = 1; j <= i; j++) {
                sum[i] += sum[i - j];
            }

        }

        System.out.println(Arrays.toString(sum));
    }
}

    class Array6_2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        int A = in.nextInt(), B = in.nextInt();
        int s = A + B;

        int[] sum = new int[n];

        sum[0] = A;
        sum[1] = B;

        for (int i = 2; i < n; i++) {
            sum[i] = s;
            s +=sum[i];
        }
        System.out.println(Arrays.toString(sum));
    }
}

