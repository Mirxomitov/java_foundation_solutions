package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array14 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();
        int[] juft_toq = new int[n];


        for (int i = 0; i < n; i++) {
            juft_toq[i] = (int) (Math.random() * 100);
        }

        System.out.println(Arrays.toString(juft_toq));


        System.out.print("Juft indeksdagilari : ");
        for (int i = 0; i < n; i += 2) {
            System.out.print(juft_toq[i] + " ");
        }
        System.out.print("\nToq indeksdagilari : ");
        for (int i = 1; i < n; i += 2) {
            System.out.print(juft_toq[i] + " ");
        }
    }
}
