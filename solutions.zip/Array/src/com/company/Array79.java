package com.company;

import java.util.Arrays;

public class Array79 {
    public static void main(String[] args) {
        int n = 15;
        int[] arr = new int[n];

        for (int i = 0; i < n; i++) {
            arr[i] = (int) (Math.random() * 10);
        }
        System.out.println(Arrays.toString(arr));

        for (int i = arr.length - 2; i >= 0; i--) {
            arr[i + 1] = arr[i];
        }

        arr[0] = 0;
        System.out.println(Arrays.toString(arr));
    }
}