package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array5 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();

        int[] Fibonachi = new int[n];
        Fibonachi[0] = 1;
        Fibonachi[1] = 1;
        for (int i = 2; i < n; i++) {

            Fibonachi[i] = Fibonachi[i - 1] + Fibonachi[i - 2];
        }
        System.out.println(Arrays.toString(Fibonachi));
    }
}

class Int {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        int F1;
        int F2 = 1;
        int F3 = 1;

        for (int i = 0; i < n; i++) {
            F1 = F2;
            F2 = F3;
            F3 = F1 + F2;
            System.out.println(F1);
        }
    }
}
