package com.company;

import java.util.Arrays;

public class Array57 {
    public static void main(String[] args) {

        int[] a = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
        int[] b = new int[a.length];

        int count = 0;

        for (int i = 1, j = 0; i < a.length; i += 2, j++) {
            count++;
            b[j] = a[i];
        }
        for (int i = 0, j = count; i < a.length; i += 2, j++) {
            b[j] = a[i];
        }

        System.out.println(Arrays.toString(b));
    }
}