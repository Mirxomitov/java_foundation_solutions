package com.company;

import java.util.Arrays;

public class Array68 {
    public static void main(String[] args) {

        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        int index_min = 0;
        int index_max = 0;

        int[] arr = {2, 5, 6, 7, 2, 4, 6, 9, 2, 1, 4, 8, 9, 10};

        for (int i = 0; i < arr.length; i++) {
            if (min > arr[i]) {
                min = arr[i];
                index_min = i;
            }
            if (max < arr[i]) {
                max = arr[i];
                index_max = i;
            }
        }
        System.out.println(arr[index_max]);
        System.out.println(arr[index_min]);
        int temp = arr[index_max];

        arr[index_max] = arr[index_min];
        arr[index_min] = temp;

        System.out.println(Arrays.toString(arr));
    }
}


class ChatGPT_Array68 {
    public static void main(String[] args) {
        double[] arr = {2.3, 7.1, -3.5, 5.5, 8.8};

        int min_idx = 0;
        int max_idx = 0;

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] < arr[min_idx]) {
                min_idx = i;

            } else if (arr[i] > arr[max_idx]) {
                max_idx = i;
            }
        }

        double temp = arr[min_idx];
        arr[min_idx] = arr[max_idx];
        arr[max_idx] = temp;


        System.out.println("After swapping the values: ");
        System.out.println(Arrays.toString(arr));
    }
}
