package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array34 {
    public static void main(String[] args) {

        int max = Integer.MIN_VALUE;

        int n = 8;

        int[] arr = {81, 17, 84, 32, 35, 77, 15, 85};

        System.out.println(Arrays.toString(arr));

        for (int i = 1; i < n - 1; i++) {
            if (arr[i - 1] > arr[i] && arr[i] < arr[i + 1] && max < arr[i]) {
                max = arr[i];
            }
        }
        System.out.println(max);
    }
}

class Humoyun34 {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();
        int[] arr = new int[n];
        int max = Integer.MIN_VALUE;

        for (int i = 0; i < n; i++) {
            arr[i] = (int) (Math.random() * 100);
        }
        System.out.println(Arrays.toString(arr));

        for (int i = 1; i < n - 1; i++) {
            if (arr[i] < arr[i + 1] && arr[i] < arr[i - 1]) {
                if (arr[i] > max) {
                    max = arr[i];
                    System.out.println(arr[i]);
                }

            }
        }
    }
}