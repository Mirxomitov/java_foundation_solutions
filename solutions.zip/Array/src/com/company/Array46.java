package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array46 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int min1 = Integer.MAX_VALUE;
        int min2 = Integer.MAX_VALUE;

        System.out.print("Massiv elementlari soni = ");
        int n = in.nextInt();
        int[] arr = new int[n];

       if(n <= 10) System.out.println("\nIndexes : ");
        for (int i = 0; i < n; i++) {
            arr[i] = (int) (Math.random() * 10);
            if(n <= 10){
                if (i == 0) System.out.print("[" + i + ", ");
                else if (i == n - 1) System.out.print(i + "]");
                else System.out.print(i + ", ");
            }
        }
        System.out.println("\n" + "Array :");
        System.out.println(Arrays.toString(arr));


        System.out.print("\nR = ");
        int R = in.nextInt();

        int el1_1 = 0, el1_2 = 0, el2_1 = 0, el2_2 = 0, outer1_1 = 0, outer1_2 = 0, outer2_1 = 0, outer2_2 = 0;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (R >= (arr[i] + arr[j]) && i != j && R - (arr[i] + arr[j]) < min1) {
                    min1 = R - arr[i] - arr[j];
                    outer1_1 = i;
                    outer1_2 = j;

                    el1_1 = arr[i];
                    el1_2 = arr[j];
                }
                final int i1 = (arr[i] + arr[j]) - R;
                if (R < (arr[i] + arr[j]) && i != j && i1 < min2) {
                    min2 = i1;
                    outer2_1 = i;
                    outer2_2 = j;

                    el2_1 = arr[i];
                    el2_2 = arr[j];
                }
            }
        }
        if (min1 > min2) {
            System.out.println();
            System.out.println("Indexes are : " + outer2_1 + " and " + outer2_2 + "\nValues are : " + el2_1 + " and " + el2_2);
            System.out.println("\nMax => " + el2_1 + " + " + el2_2 + " = " + (el2_1 + el2_2));
        } else {
            System.out.println();
            System.out.println("Indexes are : " + outer1_1 + " and " + outer1_2 + "\nValues are : " + el1_1 + " and " + el1_2);
            System.out.println("\nMax => " + el1_1 + " + " + el1_2 + " = " + (el1_1 + el1_2));
        }
    }
}
