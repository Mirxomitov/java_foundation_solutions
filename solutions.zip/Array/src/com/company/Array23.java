package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array23 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();
        int[] sum = new int[n];

        for (int i = 0; i < n; i++) {
            sum[i] = (int)(Math.random() * 10);
        }

        System.out.println(Arrays.toString(sum));

        System.out.println("K ni kiriting");
        int K = in.nextInt();
        System.out.println("L ni kiriting");
        int L = in.nextInt();

        int summa = 0;
        int all = 0;

        for (int i = 0; i < n; i++) {
            all += sum[i];
        }
        for (int i = 0; i < n; i++) {
            if (i >= K && i <= L){
                summa += sum[i];
            }
        }
        System.out.println((double) (all - summa) / (n - (L - K + 1)));
    }
}
