package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array51 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        int[] A = new int[n];
        int[] B = new int[n];

        for (int i = 0; i < A.length; i++) {
            A[i] = (int) (Math.random() * 10);
            B[i] = (int) (Math.random() * 10);
        }

        System.out.println("A[] = " + Arrays.toString(A));
        System.out.println("B[] = " + Arrays.toString(B));

        int[] temp = new int[n];

        for (int i = 0; i < A.length; i++) {
            temp[i] = A[i];
            A[i] = B[i];
            B[i] = temp[i];
        }
        System.out.println();
        System.out.println("A[] = " + Arrays.toString(A));
        System.out.println("B[] = " + Arrays.toString(B));
    }
}
