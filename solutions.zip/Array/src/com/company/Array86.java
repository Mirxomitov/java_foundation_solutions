package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array86 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int[] arr = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
        System.out.println(Arrays.toString(arr));

        System.out.print("\nk ni [1 - 4] oraliqda kiriting\nk = ");
        int k = in.nextInt();

        while (k < 1 || k > 4) {
            System.out.print("k xato kiritildi: \nk = ");
            k = in.nextInt();
        }
        int[] arr_k = new int[k];

        for (int i = 0; i < k; i++) {
            arr_k[i] = arr[i];
        }
        System.out.println(Arrays.toString(arr_k));

        for (int i = 0; i < k; i++) {
            for (int j = 0; j < arr.length - 1; j++) {
                arr[j] = arr[j + 1];
                // 0 1 2 3 4 5 6 7 8 9
                // 3 4 5 6 7 8 9 0 1 2
            }
        }

        for (int i = 0; i < k; i++) {
            arr[arr.length - i - 1] = arr_k[k - i - 1];
        }
        System.out.println(Arrays.toString(arr));
    }
}
