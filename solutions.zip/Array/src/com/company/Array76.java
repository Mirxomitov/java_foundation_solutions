package com.company;

import java.util.Arrays;

public class Array76 {
    public static void main(String[] args) {
        int n = 10;

        int[] arr = {0, 1, 2, 3, 2, 1, 4, 3, 5, 2};
        int[] array = new int[10];

        for (int i = 0; i < arr.length; i++) {
            array[i] = arr[i];
        }

        for (int i = 0; i < arr.length - 2; i++) {
            if (arr[i] < arr[i + 1] && arr[i + 1] > arr[i + 2]) {
                array[i + 1] = 0;
            }
        }
        System.out.println(Arrays.toString(array));
    }
}
