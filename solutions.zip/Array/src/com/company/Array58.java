package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array58 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        int[] A = new int[n];
        int[] B = new int[n];

        for (int i = 0; i < n; i++) {
            A[i] = (int)(Math.random() * 10);
            B[i] = 0;
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j <= i; j++) {
                B[i] += A[j];
            }
        }
        System.out.println(Arrays.toString(A));
        System.out.println(Arrays.toString(B));
    }
}
