package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array54 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        int[] A = new int[n];

        int Counter = 0;

        for (int i = 0; i < n; i++) {
            A[i] = (int) (Math.random() * 10);
            if (A[i] % 2 == 0) Counter++;
        }
        System.out.println("A[] =>" + Arrays.toString(A));

        int[] B = new int[Counter];

        for (int i = 0, j = 0; i < n; i++) {
            if (A[i] % 2 == 0) {
                B[j] = A[i];
                j++;
            }
        }
        System.out.println("B[] =>" + Arrays.toString(B));
    }
}