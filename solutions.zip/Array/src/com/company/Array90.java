package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array90 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.print("n = ");
        int n = in.nextInt();
        int[] arr = new int[n];
        int[] arr0 = new int[n - 1];

        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int)(Math.random() * 10);
        }
        System.out.println(Arrays.toString(arr));

        System.out.print("k = ");
        int k = in.nextInt();

        for (int i = 0; i < k; i++) {
            arr0[i] = arr[i];
        }
        for (int i = k; i < arr0.length ; i++) {
            arr0[i] = arr[i + 1];
        }
        System.out.println(Arrays.toString(arr0));

    }
}
