package com.company;

public class Array25 {
    public static void main(String[] args) {

        double[] arr = {2, 8, 32};

        double q;
        q = arr[1] / arr[0];

        boolean isTrue = false;

        for (int i = 0; i < arr.length; i++) {
            if (arr.length - 1 > i) {
                isTrue = arr[i + 1] / arr[i] == q;
            }
        }
        if (isTrue) System.out.println(q);
        else System.out.println(0);
    }
}
