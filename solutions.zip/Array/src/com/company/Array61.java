package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array61 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);


        int n = in.nextInt();

        double[] A = {1, 2, 3, 4, 5};
        double[] B = new double[n];

        for (int i = 0; i < n; i++) {
//            A[i] = (int)(Math.random() * 10);
            B[i] = 0;
        }

        for (int i = 0; i < n; i++) {
            for (int j = i; j < n; j++) {
                B[i] += A[j];
            }
            B[i] = B[i] / (n - i);
        }
        System.out.println(Arrays.toString(A));
        System.out.println(Arrays.toString(B));

    }
}
