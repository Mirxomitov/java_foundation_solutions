package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array66 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        double[] arr = new double[n];
        for (int i = 0; i < n; i++) {
            arr[i] = (int) (Math.random() * 10);
        }
        System.out.println(Arrays.toString(arr));

        double temp = 0;

        for (int i = 0; i < n; i++) {
            if (arr[i] % 2 == 0) {
                temp = arr[i];
                break;
            }
        }

        double[] array = new double[n];
        for (int i = 0; i < n; i++) {
            if(arr[i] % 2 == 0) array[i] = arr[i] / temp;
        }
        System.out.println(Arrays.toString(array));
    }
}