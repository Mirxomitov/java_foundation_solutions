package com.company;

import java.util.*;

public class Array99 {
    public static void main(String[] args) {
        int[] arr = {5, 7, 5, 6, 7, 6, 5, 5};
        int size = arr.length;

        // Hashmap to store the frequency of the
        // elements of the array
        HashMap<Integer, Integer> mp = new HashMap<Integer, Integer>();

        // Insert the elements and their
        // occurrences in the HashMap
        for (int i = 0; i < size; i++) {

            int key = arr[i];
            if (mp.containsKey(key)) {

                // Increment the frequency
                int freq = mp.get(key);
                mp.put(key, freq + 1);
            } else {

                // Insert the element for
                // the first time
                mp.put(key, 1);
            }
        }

        // Traverse original array and check
        // if frequency of current element
        // is more than twice.
        // If yes, then ignore the element.
        // Else add it to the output array.

        // index for output array
        int index = 0;
        for (int i = 0; i < size; i++) {

            // Find frequency of current element
            int freq = mp.get(arr[i]);

            // If frequency is more than twice,
            // ignore the element
            if (freq > 2) {
                continue;
            }

            // Else add the element to the
            // output array
            arr[index++] = arr[i];
        }

        // Print output array
        System.out.println("The changed array is:");
        for (int i = 0; i < index; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}