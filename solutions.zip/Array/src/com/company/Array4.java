package com.company;

import java.util.Arrays;

public class Array4 {
    public static void main(String[] args) {

        int A = 2, D = 3;

        int[] Progress = new int[10];

        Progress[0] = A;

        for (int i = 1; i < 10; i++) {
            Progress[i] = Progress[i - 1] * D;
        }
        System.out.println(Arrays.toString(Progress));
    }
}