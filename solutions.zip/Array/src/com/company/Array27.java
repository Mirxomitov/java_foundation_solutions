package com.company;

public class Array27 {
    public static void main(String[] args) {

        int[] arr = {-1,-1, 6, -7, 8, 9};

        boolean plus = false;
        int result = 0;

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] > 0){
                result = i;
                break;
            }
        }
        System.out.println(result);
    }
}
