package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array47 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        int[] arr = new int[n];

        for (int i = 0; i < n; i++) {
            arr[i] = (int) (Math.random() * 10);
        }
        System.out.println(Arrays.toString(arr));


        for (int i = 0; i < n; i++) {
            int Counter = 0;
            for (int j = 0; j < n; j++) {
                if (arr[i] == arr[j] && i > j){
                    Counter++;
                }
            }
            if (Counter == 0) System.out.print(arr[i] + " ");
        }
    }
}
