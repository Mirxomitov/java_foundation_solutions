package com.company;

import java.util.Arrays;

public class Array44 {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 0};

        System.out.println(Arrays.toString(arr));

        int breaker = 0;

        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr.length; j++) {
                if (i != j && arr[i] == arr[j]) {
                    System.out.println(i + " and " + j);
                    breaker = 1;
                }
                if (breaker == 1) {
                    break;
                }
            }
        }
    }
}
