package com.company;

import java.util.concurrent.atomic.AtomicIntegerArray;

public class Array26 {
    public static void main(String[] args) {
        AtomicIntegerArray arr;
        arr = new AtomicIntegerArray(new int[]{2, 4, 6, 8, 10, 12});

        int result = 0;

        int i = 1;
        while (i < arr.length()) {
            i++;
        }

        System.out.println(result);
    }
}