package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array16 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        int[] first_last = new int[n];

        for (int i = 0; i < n; i++) {
            first_last[i] = (int)(Math.random() * 100);
        }
        System.out.println(Arrays.toString(first_last));
        for (int i = 0; i < n / 2; i++) {
            System.out.println(first_last[i]);
            System.out.println(first_last[n - i - 1]);
        }
        if(n % 2 != 0) {
            System.out.println(first_last[(int)(Math.floor(n * 1.0 / 2))]);
        }
    }
}