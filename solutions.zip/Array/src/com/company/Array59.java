package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array59 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        double[] A= {-6.90, -1.72, -3.5, 2.58, -7.84};
        double[] B= new double[n];

        for (int i = 0; i < n; i++) {
//            A[i] = (int)(Math.random() * 10);
            B[i] = 0;
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j <= i; j++) {
                B[i] += A[j];
            }
            B[i] = B[i] / (i + 1);
        }
        System.out.println(Arrays.toString(A));
        System.out.println(Arrays.toString(B));
    }
}
