package com.company;

public class Array10 {
    public static void main(String[] args) {

        int[] sonlar = {1, 9, 6, 3, 7, 4, 5, 0, 2, 8};

        System.out.print("JUFT SONLAR : ");
        for (int k : sonlar) {
            if (k % 2 == 0) {
                System.out.print(" " + k);
            }
        }

        System.out.print("\nTOQ SONLAR : ");
        for (int j : sonlar) {
            if (j % 2 != 0) {
                System.out.print(" " + j);
            }
        }
    }
}
