package com.company;

import java.util.Arrays;

public class Array50 {
    public static void main(String[] args) {

        int[] arr = {1, 9, 4, 3, 8, 6, 7, 2, 5};
        System.out.println(Arrays.toString(arr));

        int Counter = 0;

        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length; j++) {
                if (i < j && arr[i] > arr[j]) {
                    Counter++;
                }
            }
        }
        System.out.println(Counter);
    }
}
