// error

package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array37 {
    public static void main(String[] args) {

        int[] arr = {1,3,0,-3,6,9,3,2,1,0,-1,3,5,7}; // 3
        System.out.println(Arrays.toString(arr));

        int Counter = 1;

        for (int i = 0; i < arr.length - 2; i++) {
            if (arr[i] < arr[i + 1] && arr[i + 1] > arr[i + 2]){
                Counter++;
            }
        }
        System.out.println(Counter);
    }
}
