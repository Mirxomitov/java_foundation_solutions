package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array42 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int min1 = Integer.MAX_VALUE;
        int min2 = Integer.MAX_VALUE;

        System.out.print("R = ");
        int R = in.nextInt();

        System.out.print("Array elementlari soni : ");
        int n = in.nextInt();

        int[] arr = new int[n];

        for (int i = 0; i < n; i++) {
            arr[i] = (int) (Math.random() * 10);
        }
        System.out.println(Arrays.toString(arr));

        int out = 0;
        for (int i = 0; i < n - 1; i++) {
            int sum = arr[i] + arr[i + 1];

            if (min1 > sum - R && sum >= R){
                min1  = sum - R;
                out = i;
            }
            if (min2 > R - sum && R > sum){
                min2 = R - sum;
                out = i;
            }
        }
        System.out.println(out + " and " + (out + 1));
    }
}