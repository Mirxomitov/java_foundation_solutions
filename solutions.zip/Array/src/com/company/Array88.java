package com.company;

import java.util.Arrays;

public class Array88{
    public static void main(String[] args) {
        int[] arr = {0,2,4,6,8,10,12,13,5};

        int out = 0;

        for (int i = 0; i < arr.length; i++) {
            if (arr[arr.length - 1] < arr[i]){
                out = i;
                break;
            }
        }
        int temp = arr[arr.length - 1];
        for (int i = arr.length - 1; i > out; i--) {
            arr[i] = arr[i - 1];
        }
        arr[out] = temp;
        System.out.println(Arrays.toString(arr));
    }
}