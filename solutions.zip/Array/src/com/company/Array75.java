package com.company;

import java.util.Arrays;

public class Array75 {
    public static void main(String[] args) {

        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;

        int n = 10;

        int[] arr = {0,1,2,-1,3,4,5,8,4,4,6};

        int index_min = 0;
        int index_max = 0;
        for (int i = 0; i < arr.length; i++) {
            if (min > arr[i]) {
                min = arr[i];
                index_min = i;
            }
            if (max < arr[i]) {
                max = arr[i];
                index_max = i;
            }
        }

        for (int i = 0; i <= Math.abs(index_max - index_min) / 2; i++) {
            if (index_max > index_min){
                int temp = arr[index_min + i];
                arr[index_min + i] = arr[index_max - i];
                arr[index_max - i] = temp;
            }
            else {
                int temp = arr[index_min - i];
                arr[index_min - i] = arr[index_max + i];
                arr[index_max + i] = temp;
            }
        }
        System.out.println(Arrays.toString(arr));
    }
}
