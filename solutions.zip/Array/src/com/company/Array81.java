package com.company;

import java.util.Arrays;

public class Array81 {
    public static void main(String[] args) {

        int[] arr = {1, 3, 4, 5, 8, 5, 2, 1, 4, 2, 1, 1, 6, 2, 9, 9, 9};

        System.out.println(Arrays.toString(arr));

        int k = 7;

        for (int i = 0; i < k; i++) {
            for (int j = arr.length - 2; j >= 0; j--) {

                arr[j + 1] = arr[j];
                arr[j] = 0;
            }
        }

        System.out.println(Arrays.toString(arr));
    }
}