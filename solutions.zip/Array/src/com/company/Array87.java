package com.company;

import java.util.Arrays;

public class Array87 {
    public static void main(String[] args) {
        int[] arr = {3, 2, 4, 9, 6, 7, 8, 0, 5}; // 9
        System.out.println(Arrays.toString(arr));


        for (int i = 1; i < arr.length - 1; i++) {
            int breaker = 0;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[i] >= arr[j]) {
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;

                    breaker++;
                }
            }
            if (breaker == 1) i--;
        }
        System.out.println(Arrays.toString(arr));

        int out = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[0] < arr[i]) {
                out = i;
                break;
            }
        }

        int temp = arr[0];
        for (int i = 0; i < out - 1; i++) {
            arr[i] = arr[i + 1];
        }
        arr[out - 1] = temp;
        System.out.println(Arrays.toString(arr));
    }
}
