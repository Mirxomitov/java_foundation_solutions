package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array41 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int max = Integer.MIN_VALUE;

        int n = in.nextInt();

        int[] arr = new int[n];

        for (int i = 0; i < n; i++) {
            arr[i] = (int) (Math.random() * 2);
        }
        System.out.println(Arrays.toString(arr));
        int out = 0;

        for (int i = 0; i < n - 1; i++) {
            int max1 = arr[i] + arr[i + 1];
            if (max <= max1) {
                max = max1;
                out = i;
            }
        }
        System.out.println(max);
        System.out.println(out + " and " + (out + 1));
    }
}
// oxirgi maximal juftlikni chiqaradi
