package com.company;

public class Array45 {
    public static void main(String[] args) {
        int min = Integer.MAX_VALUE;

        int[] arr = {1, 7, 10, 6, 10, 16};

        int outer1 = 0;
        int outer2 = 0;

        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr.length; j++) {
                if (i != j) {
                    if (Math.abs(arr[i] - arr[j]) < min) {
                        min = Math.abs(arr[i] - arr[j]);
                        outer1 = i;
                        outer2 = j;
                    }
                }
            }
        }
        System.out.println(outer1);
        System.out.println(outer2);
    }
}

