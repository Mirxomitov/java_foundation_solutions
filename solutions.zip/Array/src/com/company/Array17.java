package com.company;

import java.util.Arrays;

public class Array17 {
    public static void main(String[] args) {

        int[] arr = new int[9];

        int left = 0;
        int right = arr.length-1;

        for (int i = 0; i < 9; i++) {
            arr[i] = (int) (Math.random() * 100);
        }
        System.out.println(Arrays.toString(arr));
        while(left < right) {
            System.out.print(arr[left++] + " ");
            System.out.print(arr[left++] + " ");

            if(right > left){
                System.out.print(arr[right--] + " ");
                System.out.print(arr[right--] + " ");
            }

            if(right == left) System.out.println(arr[left]);
        }

    }
}