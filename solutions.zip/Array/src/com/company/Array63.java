package com.company;

import java.util.Arrays;

public class Array63 {
    public static void main(String[] args) {
        int[] a = {1, 3, 5, 7};
        int[] b = {2, 5, 7, 8};

        int c[] = new int[a.length + b.length];

        int ai = 0, bi = 0, ci = 0;

        while (ai < a.length || bi < b.length) {
            if (ai == a.length) {
                c[ci++] = b[bi];
                bi++;
            } else if (bi == b.length) {
                c[ci++] = a[ai];
                ai++;
            } else {
                if (a[ai] == b[bi]) {
                    c[ci++] = b[bi];
                    bi++;
                } else if (a[ai] < b[bi]) {
                    c[ci++] = a[ai];
                    ai++;
                } else {
                    c[ci++] = b[bi];
                    bi++;
                }
            }
        }

        System.out.println(Arrays.toString(c));
    }
}
