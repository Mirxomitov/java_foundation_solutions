package com.company;

import java.util.Arrays;

class Array1 {
    public static void main(String[] args) {
        int[] odds = new int[10];

        for (int i = 2, son = 1; i < 10; i++, son += 2) {
            odds[i] = son; // 0 ... 9
        }
        System.out.println(Arrays.toString(odds));
    }
}
