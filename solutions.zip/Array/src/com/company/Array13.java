package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array13 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        int[] num = new int[n];

        for (int i = 0; i < n; i++) {
            num[i] = (int) (Math.random() * 100);
        }
        System.out.println(Arrays.toString(num));


        for (int i = n - 2; i >= 1; i -= 2) {
            System.out.println(num[i]);
        }
    }
}
