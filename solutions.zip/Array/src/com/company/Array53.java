package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array53 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        double[] A = new double[n];
        double[] B = new double[n];
        double[] C = new double[n];

        for (int i = 0, k1; i < n; i++) {
            k1 = (int)(Math.random() * 10);
            if (k1 % 2 == 0) A[i] = Math.random() * -10;
            else  A[i] = Math.random() * 10;

            k1 = (int)(Math.random() * 10);
            if (k1 % 2 == 0) B[i] = Math.random() * -10;
            else  B[i] = Math.random() * 10;

            C[i] = Math.max(A[i], B[i]);
        }

        System.out.println(Arrays.toString(A));
        System.out.println(Arrays.toString(B));
        System.out.println(Arrays.toString(C));
    }
}
