package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array65 {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        System.out.println("n ni kiriting");
        int n = in.nextInt();
        System.out.println("k ni kiriting");
        int k = in.nextInt();
        int[] a = new int[n];

        for (int i = 0; i < n; i++) {
            a[i] = (int)(Math.random() * 10);
        }
        System.out.println(Arrays.toString(a));

        int temp = a[k];

        for (int i = 0; i < n; i++) {
            a[i] += temp;
        }
        System.out.println(Arrays.toString(a));
    }
}
