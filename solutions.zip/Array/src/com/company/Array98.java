//package com.company;
//
//import java.util.Arrays;
//import java.util.Scanner;
//
//public class Array98 {
//    public static void main(String[] args) {
//        Scanner in = new Scanner(System.in);
//
//        int[] arr = {1,1,1,2,2,2,3,3,3}; // 5 5 5 5
//        int[] array = new int[arr.length];
//
//        for (int i = 0; i < arr.length; ) {
//            int count = 0, temp = 0, h = 0;
//            for (int j = arr.length - 1; j > 0; j--) {
//                if (i != j && arr[i] == arr[j]) {
//                    temp = j;
//                    count++;
//                }
//            }
////            if (count == 0) DeleteElement0(arr, i);
//            if (count < 2) {
//                DeleteElement(arr, i, temp);
//            }
//
//            else {
//                for (int j = 0; j < count + 2; j++) {
//                    array[j] = arr[i];
//                }
//                i++;
//            }
//        }
//        System.out.println(Arrays.toString(array));
//        System.out.println(Arrays.toString(arr));
//    }
//
//    public static void DeleteElement(int[] array, int index1, int index2) {
//        for (int i = index2; i < array.length - 1; i++) {
//            array[i] = array[i + 1];
//        }
//        array[array.length - 1] = 0;
//        for (int i = index1; i < array.length - 1; i++) {
//            array[i] = array[i + 1];
//        }
//        array[array.length - 1] = 0;
//    }
//
//    public static void DeleteElement0(int[] array, int index1) {
//        for (int i = index1; i < array.length - 1; i++) {
//            array[i] = array[i + 1];
//        }
//        array[array.length - 1] = 0;
//    }
//}

package com.company;

import java.util.Arrays;
import java.lang.String;

public class Array98 {
    public static void main(String[] args) {

        int[] arr = {8, 2, 3, 3, 1, 3, 2,8, 8, 1}; // 1 1 1 3 3 3
        System.out.println(Arrays.toString(arr) + " : Given Array ");

        for (int i = 0; i < arr.length; i++) {
            int count = 0;
            for (int j = 0; j < arr.length; j++) {
                if (i != j && arr[i] == arr[j]) count++;
            }
            if (count < 2) {
                DeleteElements(arr, i);
            }
        }
        System.out.println(Arrays.toString(arr) + " : after first for");

        for (int i = 0; i < arr.length; i++) {
            int count = 0;
            for (int j = 0; j < arr.length; j++) {
                if (i != j && arr[i] == arr[j]) count++;
            }
            if (count < 2) {
                DeleteElements(arr, i);
            }
        }
        System.out.println(Arrays.toString(arr) + " : after second for");

        // endi 0 larni o'chiramiz

        int count = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] != 0) count++;
        }

        int[] NewArr = new int[count];

        for (int i = 0, j = 0; i < count; i++) {
            if (arr[i] != 0) {
                NewArr[j] = arr[i];
                j++;
            }
        }

        System.out.println(Arrays.toString(NewArr) + " : Changed Array");
        System.out.println("Size of the changed Array = " + NewArr.length);
    }


    public static void DeleteElements(int[] arr, int index) {

        for (int i = index; i < arr.length - 1; i++) {
            arr[i] = arr[i + 1];
        }
        arr[arr.length - 1] = 0;
    }
}