package com.company;

import java.util.Random;
import java.lang.String;
import java.util.Scanner;
import java.util.Arrays;

public class Array83 {
    public static void main(String[] args) {
        int[] arr = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
        System.out.println(Arrays.toString(arr));

        int temp = arr[arr.length - 1];

        for (int j = arr.length - 2; j >= 0; j--) {
            arr[j + 1] = arr[j];
        }
        arr[0] = temp;
        System.out.println(Arrays.toString(arr));
    }
}
//
//class Arr83 {
//    public static void main(String[] args) {
//        Scanner in = new Scanner(System.in);
//        Random ran = new Random();
//
//        System.out.print("Enter a number of digits in the array, n: ");
//        int n = in.nextInt();
//        int[] a = new int[n];
//
//        for (int i = 0; i < n; i++) {
//            a[i] = ran.nextInt(100);
//            System.out.print("a[" + i + "] = " + a[i] + "    ");
//        }
//        System.out.println("\n");
//
//        int[] b = new int[n];
//        b[0] = a[n - 1];
//        int j = 1;
//        for (int i = 0; i < n - 1; i++, j++) {
//            b[j] = a[i];
//        }
//
//        for (int i = 0; i < n; i++) {
//            System.out.print("b[" + i + "] = " + b[i] + "    ");
//        }
//    }
//}
