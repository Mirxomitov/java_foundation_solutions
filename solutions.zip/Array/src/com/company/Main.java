package com.company;

public class Main {
    public static void main(String[] args) {

    }
    public static int[] ChangeSize(int[] array, int len){
        int[] newArray = new int[len];


        for(int i = 0; i < newArray.length; i++){
            newArray[i] = array[i];
        }

        return newArray;
    }
}

