package com.company;

import java.util.Arrays;

public class Array2 {
    public static void main(String[] args) {
        int[] power2 = new int[10];

        for (int i = 0; i < 10; i++) {
            power2[i] = (int)Math.pow(2, i + 1);

        }
        System.out.println(Arrays.toString(power2));
    }
}
