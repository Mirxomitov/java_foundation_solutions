package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array29 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int max = Integer.MIN_VALUE;
        int n = in.nextInt();

        int[] arr = new int[n];

        for (int i = 0; i < n; i++) {
            arr[i] = (int) (Math.random() * 100);
        }
        System.out.println(Arrays.toString(arr));
        for (int i = 0; i < n / 2; i++) {
            if(max < arr[2 * i + 1]){
                max = arr[2 * i + 1];
            }
        }
        System.out.println(max);
    }
}
