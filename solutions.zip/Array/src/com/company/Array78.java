package com.company;

import java.util.Arrays;

public class Array78 {
    public static void main(String[] args) {

        double[] arr = {6.43, -8.74, -9.90, 2.27, 8.85, 7.67};
        double[] array = new double[arr.length];

        for (int i = 1; i < arr.length - 1; i++) {
            array[i] = (arr[i - 1] + arr[i] + arr[i + 1]) / 3;
        }

        array[0] = (arr[0] + arr[1]) / 2;
        array[arr.length - 1] = (arr[arr.length - 1] + arr[arr.length - 2]) / 2;

        System.out.println(Arrays.toString(array));
    }
}