package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array40 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int min1 = Integer.MAX_VALUE;
        int min2 = Integer.MAX_VALUE;

        System.out.print("R = ");
        int R = in.nextInt();

        System.out.println("Array elementlari soni");
        int n = in.nextInt();

        int[] arr = new int[n];

        for (int i = 0; i < n; i++) {
            arr[i] = (int) (Math.random() * 10);
        }
        System.out.println(Arrays.toString(arr));

        for (int i = 0; i < n; i++) {
            if (R >= arr[i] && min1 > R - arr[i]) {
                min1 = R - arr[i];
            }
        }
        for (int i = 0; i < n; i++) {
            if (R < arr[i] && min2 > arr[i] - R) {
                min2 = arr[i] - R;
            }
        }

        if (min2 > min1) System.out.println(R - min1);
        else System.out.println(R - min2);

    }
}

class Arr40{
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("massiv sonini kiriting : ");
        int n = in.nextInt();
        System.out.println("R sonini kiritng : ");
        int r = in.nextInt();
        int[] arr = new int[n];
        int min = Integer.MAX_VALUE;
        int i;

        for (i = 0; i < n; i++) {
            arr[i] = (int) (Math.random() * 100);

        }
        System.out.println(Arrays.toString(arr));
//        for (int i = 0; i < arr.length-1; i++) {
//
//        }
        if ((r - arr[i]) < min) {
            min = arr[i];
        }
        System.out.println(min);
    }
}