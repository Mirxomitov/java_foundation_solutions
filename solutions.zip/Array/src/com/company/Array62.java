package com.company;

import com.sun.org.apache.xpath.internal.operations.Plus;
import javafx.scene.PointLight;

import javax.swing.text.BadLocationException;
import java.util.Arrays;

public class Array62 {
    public static void main(String[] args) {

        double[] A = {4, 0, -9, -8, 3, 0, 0, 0, 1, -3, -5};

        int plus = 0, minus = 0, zero = 0;

        for (double item : A) {

            if (item > 0) plus++;
            else if (item < 0) minus++;
            else zero++;
        }

        double[] B = new double[plus];
        double[] C = new double[minus];
        double[] D = new double[zero];


        int j = 0;
        for (double value : A) {
            if (value > 0) {
                B[j] = value;
                j++;
            }
        }
        System.out.println("Musbat elementlar soni = " + j);
        j = 0;
        for (double value : A) {
            if (value < 0) {
                C[j] = value;
                j++;
            }
        }
        System.out.println("Manfiy elementlar soni = " + j);

        j = 0;
        for (double v : A) {
            if (v == 0) {
                D[j] = v;
                j++;
            }
        }
        System.out.println("J = 0  elementlar soni = " + j);

        System.out.println("\n1. musbat elementli massiv : " + Arrays.toString(B));
        System.out.println("2. manfiy elementli massiv : " + Arrays.toString(C));
        System.out.println("3. 0 ga = elementli massiv : " + Arrays.toString(D));

//        System.out.println(Arrays.toString(B) + Arrays.toString(C));

        int PM = B.length + C.length;

        int[] PlusMinus = new int[PM];
        System.out.println(Arrays.toString(PlusMinus));
    }
}
