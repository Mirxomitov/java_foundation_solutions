package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array94 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.print("N = ");
        int n = in.nextInt();
        int[] arr = new int[n];
        int[] arr0 = new int[(int) Math.ceil(n / 2.0)];

        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int) (Math.random() * 10);
        }
        System.out.println(Arrays.toString(arr));

        int j = 0;
        for (int i = 0; i < arr.length; i += 2, j++) {
            arr0[j] = arr[i];
        }
        System.out.println("soni : " + j);
        System.out.println(Arrays.toString(arr0));
    }
}
