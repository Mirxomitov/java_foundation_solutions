package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array35 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int min = Integer.MAX_VALUE;

        int n = in.nextInt();

        int[] arr = new int[n];

        for (int i = 0; i < n; i++) {
            arr[i] = (int) (Math.random() * 100);
        }
        System.out.println(Arrays.toString(arr));

        for (int i = 1; i < n - 1; i++) {
            if(arr[i - 1] < arr[i] && arr[i] > arr[i + 1] && min > arr[i]) {
                min = arr[i];
            }
        }
        System.out.println(min);
    }
}