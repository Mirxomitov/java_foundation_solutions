package com.company;

public class Array24 {
    public static void main(String[] args) {

        int[] arr = {2, 4, 6, 8, 10, 13};

        int d = arr[1] - arr[0];

        boolean isTrue = false;

        for (int i = 0; i < arr.length - 1; i++) {
            /*if (arr.length - 1 > i)*/ {
                isTrue = arr[i + 1] - arr[i] == d;
            }
        }
        if (isTrue) System.out.println(d);
        else System.out.println(0);
    }
}
