package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array91 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.print("N = ");
        int n = in.nextInt();
        int[] arr = new int[n];

        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int) (Math.random() * 10);
        }
        System.out.println(Arrays.toString(arr));

        System.out.print("k = ");
        int k = in.nextInt();

        System.out.print("m = ");
        int m = in.nextInt();

        int[] arr0 = new int[n - (m - k + 1)];
        System.out.println(Arrays.toString(arr0));
        for (int i = 0; i < k; i++) {
            arr0[i] = arr[i];
        }
        for (int i = m + 1, j = k; i < arr.length; i++, j++) {
            arr0[j] = arr[i];
        }
        System.out.println(Arrays.toString(arr0));
    }
}
