package com.company;

import java.util.Arrays;

public class Array84 {
    public static void main(String[] args) {
        int[] arr = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
        System.out.println(Arrays.toString(arr));

        int temp = arr[arr.length - 1];

        for (int i = arr[arr.length - 2]; i >= 0; i--) {
            arr[i + 1] = arr[i];
        }
        arr[0] = temp;
        System.out.println(Arrays.toString(arr));
    }
}
