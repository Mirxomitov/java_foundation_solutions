package com.company;

import java.util.Arrays;

public class Array97 {
    public static void main(String[] args) {
        int[] massiv = {1, 2, 3, 1, 5, 4, 6, 8, 8, 9, 99, 1, 2, 5, 3};
        System.out.println(Arrays.toString(massiv));

        for (int i = 0; i < massiv.length; i++) {
            for (int j = massiv.length - 1; j > i; j--) {
                if (massiv[i] == massiv[j]) {
                    massivdanDeleteQil(massiv, i);
                }
            }
        }

        System.out.println(Arrays.toString(massiv));
    }

    private static void massivdanDeleteQil(int[] massiv, int index) {
        for (int i = index; i < massiv.length - 1; i++) {
            massiv[i] = massiv[i + 1];
        }
        massiv[massiv.length - 1] = 0;
    }
}
