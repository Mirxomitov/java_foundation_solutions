package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array19 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        int[] lastindex = new int[n];

        for (int i = 0; i < n; i++) {
            lastindex[i] = (int)(Math.random() * 100);
        }
        System.out.println(Arrays.toString(lastindex));

        int out = 0;
        for (int i = 0; i < n; i++) {
            if (lastindex[i] > lastindex[0] && lastindex[i] < lastindex[n - 1]){
                out = i;
            }
        }
        System.out.println(out);
    }
}
