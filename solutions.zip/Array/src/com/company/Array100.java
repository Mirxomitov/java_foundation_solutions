package com.company;

import java.util.Arrays;

public class Array100 {
    public static void main(String[] args) {
        int[] array = {5, 6, 6, 4, 6, 6, 5}, newArray = new int[array.length];
        int len = array.length;

        for (int i = 0, k = 0; i < array.length; i++) {
            int counter = 1;

            for (int j = 0; j < array.length; j++) {
                if (i != j && array[i] == array[j]) {
                    counter++;

                }
            }
            if (counter == 2) len -= 1;
            if (counter != 2) {
                newArray[k++] = array[i];

            }

        }
        System.out.println(Arrays.toString(Main.ChangeSize(newArray, len)));
    }
}
