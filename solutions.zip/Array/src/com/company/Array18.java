package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array18 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();
        int[] firsmin = new int[n];

        // bu for arrayni ichini to'ldiradi randam sonlar bilan
        for (int i = 0; i < n; i++) {
            firsmin[i] = (int) (Math.random() * 100);
        }
        System.out.println(Arrays.toString(firsmin));

        int breaker = 0; // agar oxirgisidan kichigi topilsa break qilish uchun
        for (int i = 0; i < n; i++) {
            if (firsmin[i] < firsmin[n - 1]) {
                System.out.println(firsmin[i]);
                breaker++; // breaker = 1
            }
            // agar breaker 1 ga tebg bo'lsa for sikli tugatilsin
            // yo'qsa yana davom ettiriladi
            if (breaker == 1) break;
        }
        // agar kichik son topilmasdan breaker 1 ga ortmasa
        if (breaker == 0) System.out.println("Kichigi yo'q");
    }
}