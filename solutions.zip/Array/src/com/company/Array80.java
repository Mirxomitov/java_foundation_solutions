package com.company;

import java.util.Arrays;

public class Array80 {
    public static void main(String[] args) {
        int n = 15;

        int[] arr = {1, 3, 4, 5, 8, 5, 2, 1, 4, 62, 1, 51, 6, 32, 5};
        System.out.println(Arrays.toString(arr));
        for (int i = 0; i < n - 1; i++) {
            // 1 2 3 4 5 6 7 8 9
            // 2 3 4 5 6 7 8 9 0

            arr[i] = arr[i + 1];
        }
        arr[arr.length - 1] = 0;
        System.out.println(Arrays.toString(arr));
    }
}
