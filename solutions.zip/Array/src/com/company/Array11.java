package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array11 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.print("Array elementlari soni (n)ni  kiriting : ");
        int n = in.nextInt();

        int[] numbers = new int[n];

        for (int i = 0; i < n; i++) {
            numbers[i] = (int) (Math.random() * 100);
        }

        System.out.println(Arrays.toString(numbers));
        System.out.print("K = ");
        int k = in.nextInt();

        for (int i = k; i < n; i+=k) {

            System.out.println(". " + numbers[i]);
        }
    }
}
