package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array52 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();

        double[] A = new double[n];

        double[] B = new double[n];
        for (int i = 0; i < n; i++) {
            A[i] = 10 * Math.random();

            if(A[i] > 5) B[i] = 2 * A[i];
            else B[i] = A[i] / 2;
        }

        System.out.println(Arrays.toString(A));
        System.out.println(Arrays.toString(B));
    }
}
