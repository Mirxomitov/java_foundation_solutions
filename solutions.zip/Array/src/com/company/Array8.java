package com.company;

public class Array8 {
    public static void main(String[] args) {

        int[] toq_sonlar = {1, 5, 6, 3, 8, 0, 9};

        int Counter = 0;

        System.out.print("TOQ SONLAR: ");
        for (int j : toq_sonlar) {
            if (j % 2 != 0) {
                System.out.print(" " + j);
                Counter++;
            }
        }
        System.out.println("\nsoni = " + Counter);

    }
}
