package com.company;

import java.util.Arrays;

public class Array69 {
    public static void main(String[] args) {

        int[] arr = {1, 9, 3, 7, 6, 4, 8, 2, 9, 1};

        for (int i = 0; i < arr.length; i += 2) {

                int temp = arr[i];
                arr[i] = arr[i + 1];
                arr[i + 1] = temp;

        }
        System.out.println(Arrays.toString(arr));
    }
}
