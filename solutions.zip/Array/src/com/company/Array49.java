package com.company;

import java.util.Scanner;

public class Array49 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Nechta qiymatli array yaratay: ");
        int n = in.nextInt();

        int[] arr = new int[n];
        // ar   rayga qiymat kiritish uchun
        for (int i = 0; i < n; i++) {
            arr[i]= in.nextInt(); // son qabujl qiladi
        }
        boolean inRule = true;
        for(int i = 0; i < arr.length; i++) {
            if(arr[i] < 1 || arr[i] > n || used(arr, i)) {
                inRule = false;
                System.out.println("["+i + "] dagi index elementi -> " + arr[i] + "qoidani buzdi." );
            }
        }
        if(inRule) System.out.println(0);
    }

    // bu method arrydan arr[i] dagi sonni 0-i gacha oraliqda qidiradi
    private static boolean used(int[] arr, int i) {
        for (int j = 0; j < i; j++) {
            if(arr[j] == arr[i]) return true;
        }
        return false;
    }

}