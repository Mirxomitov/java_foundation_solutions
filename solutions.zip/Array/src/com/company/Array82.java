package com.company;

import java.util.Arrays;

public class Array82 {
    public static void main(String[] args) {

        int[] arr = {5,6,9,8,5,2,3,1,4,6,5,7,8,9,5,1};
        System.out.println(Arrays.toString(arr));

        int k = 6;

        for (int i = 0; i < k; i++) {
            for (int j = 0; j < arr.length - 1; j++) {
                arr[j] = arr[j + 1];
                arr[j + 1] = 0;
            }
        }
        System.out.println(Arrays.toString(arr));
    }
}
