package com.company;

import java.util.Arrays;

public class Array89 {
    public static void main(String[] args) {
        int[] arr = {0, 1, 2, 4, 5, 3, 8};
//        int[] arr = {-3, -2, 1, 2, 3, 8, 5, 6, 7, 9, 10};

        boolean Done = false;
        int index = -1;

        out:
        while (true) {
            for (int i = 1; i < arr.length - 1; i++) {
                if (!(arr[i] < arr[i + 1] && arr[i] > arr[i - 1])) {
                    index = i;
                    break;
                }
                if(i == arr.length-2) {
                    break out;
                }
            }

            for (int i = index; i < arr.length - 1; i++) {
                if (arr[i] > arr[i + 1]) {
                    int temp = arr[i];
                    arr[i] = arr[i + 1];
                    arr[i + 1] = temp;
                }
            }
        }
        System.out.println(Arrays.toString(arr));
    }
}