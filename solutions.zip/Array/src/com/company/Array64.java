package com.company;

public class Array64 {
    public static void main(String[] args) {
        int[] a = {1, 4, 5, 11, 12};
        int[] b = {2, 5, 6, 7, 15};
        int[] c = {0, 1, 3, 5, 6, 7, 8};

        int SizeOfd = a.length + b.length + c.length;
        int[] d = new int[SizeOfd];

        int ai = 0, bi = 0, ci = 0, di = 0;

        while (ai < a.length || bi < b.length || ci < c.length) {

            if (ai == a.length && bi == b.length) {
                d[di] = c[ci];
                ci++;
            } else if (ai == a.length && ci == c.length) {
                d[di] = b[bi];
                bi++;
            } else if (bi == b.length && ci == c.length) {
                d[di] = a[ai];
                ai++;
            } else if (ai == a.length){
                if (b[bi] < c[ci]){
                    d[di] = c[ci];
                    ci++;
                }
                else if (b[bi] > c[ci]){
                    d[di] = b[bi];
                    bi++;
                }
            }
            else if (bi == b.length) {

            } else if (ci == c.length) {

            } else {
                if (a[ai] < b[bi] && a[ai] < c[ci]) {
                    d[di] = a[ai];
                    ai++;
                } else if (b[bi] < a[ai] && b[bi] < c[ci]) {
                    d[di] = b[bi];
                    bi++;
                } else if (c[ci] < a[ai] && c[ci] < a[ai]) {
                    d[di] = c[ci];
                    ci++;
                }
            }
            di++;
        }
    }
}