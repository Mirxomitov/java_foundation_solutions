package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Array12 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n = in.nextInt();
        int[] juft = new int[n];

        for (int i = 0; i < n; i++) {
            juft[i] = (int) (Math.random() * 100);
        }
        System.out.println(Arrays.toString(juft));

        for (int i = 0; i < n; i += 2) {
//            if (i % 2 == 0) System.out.println(juft[i]);
            System.out.println(juft[i]);
        }
    }
}
