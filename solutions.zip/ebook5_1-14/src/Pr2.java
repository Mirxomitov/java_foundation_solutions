import java.util.Scanner;

public class Pr2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b;

        System.out.print("a=");
        a = in.nextDouble();
        System.out.print("b=");
        b = in.nextDouble();

        double min;

        min = a < b ? a : b;
        System.out.println("ikkisidan kichigi = " + min);

        if (a > b) {
            System.out.println("kattasi a= " + a);
        }
        else {
            System.out.println("kattasi b= " + b);
        }
    }
}
