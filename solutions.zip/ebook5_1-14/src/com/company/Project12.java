package com.company;

import java.util.Scanner;

public class Project12 {
    public static void main(String[] args) {
        Scanner in= new Scanner(System.in);

        double a, b, c, d;
        System.out.print("a=");
        a = in.nextDouble();
        System.out.print("b=");
        b = in.nextDouble();
        System.out.print("c=");
        c = in.nextDouble();
        System.out.print("d=");
        d = in.nextDouble();

        boolean e = d >= c && c >= b && b >= a;

        if(e) {
            System.out.println("d >= c >= b >= a \n=========================== ");
            System.out.println("\na o'zlashtirsin b ni // b o'zlashtirsin c ni  // c o'zlashtirsin d ni // d dan kattasi yo'qligi uchun d chiqarilmasi");
            a = b;
            b = c;
            c = d;

            System.out.println("a -> " + a);
            System.out.println("b -> " + b);
            System.out.println("c -> " + c);

        }
        else if(a > b && b > c && c > d){
            System.out.println("a > b > c > d \n=========================== ");

            System.out.println("\na -> " + a);
            System.out.println("b -> " + b);
            System.out.println("c -> " + c);
            System.out.println("d -> " + d);
        }
        else {
            System.out.println("kvadratlari chiqarilsin \n ==========================");
            a = a * a;
            b = b * b;
            c = c * c;
            d = d * d;

            System.out.println("a -> " + a);
            System.out.println("b -> " + b);
            System.out.println("c -> " + c);
            System.out.println("d -> " + d);
        }
    }
}
