package com.company;

import java.util.Scanner;

public class Project9 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b, c;

        System.out.print("a=");
        a = in.nextDouble();
        System.out.print("b=");
        b = in.nextDouble();
        System.out.print("c=");
        c = in.nextDouble();

        if (a > 1 && a < 3) {
            System.out.println(a);
        }
        else if (b > 1 && b < 3) {
            System.out.println(b);
        }
        else if(c > 1 && c < 3){
            System.out.println(b);}

        else {
            System.out.println("\nhech qaysi bir son (1,3) oraliqda emas") ;
        }
    }
}


