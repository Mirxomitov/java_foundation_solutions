package com.company;

import java.util.Scanner;

public class Project11 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b, c;

        a = in.nextDouble();
        b = in.nextDouble();
        c = in.nextDouble();


        if (a >= 0) {
            System.out.println(a * a);
        }
        else if (b >= 0){
            System.out.println(b * b);
        }
        else if (c >= 0){
            System.out.println(c * c);
        }
        else {
            System.out.println("hammasi manfiy");
        }
    }
}
