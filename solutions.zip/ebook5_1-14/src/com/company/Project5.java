package com.company;

import java.util.Scanner;

public class Project5 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double a, b, c;

        System.out.print("a=");
        a = in.nextDouble();
        System.out.print("b=");
        b = in.nextDouble();
        System.out.print("c=");
        c = in.nextDouble();

        if (a >= b && a >= c) {
            System.out.println("a >= b >= c is true");
            System.out.println("2 * a =" + 2 * a);
            System.out.println("2 * b =" + 2 * b);
            System.out.println("2 * c =" + 2 * c);

        }
        else {
            System.out.println("a >= b >= c is false");

            System.out.print("a=");
            a = in.nextDouble();
            System.out.print("b=");
            b = in.nextDouble();
            System.out.print("c=");
            c = in.nextDouble();
        }
    }
}
