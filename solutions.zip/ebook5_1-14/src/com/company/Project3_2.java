package com.company;

import java.util.Scanner;

public class Project3_2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b, c;
        double max;

        System.out.print("a=");
        a = in.nextDouble();
        System.out.print("b=");
        b = in.nextDouble();
        System.out.print("c=");
        c = in.nextDouble();

        if (a * b * c / 2 < a + b + c) {
                System.out.println("minimum is a * b * c / 2  = " + a * b * c / 2 );

                double x = Math.pow(a * b * c / 2, 2);
                System.out.println("min^2 + 1 = " + x + 1);

        } else {
                System.out.println("minimum is a + b + c = " + (a + b + c));

                double x = Math.pow(a + b + c, 2);
                System.out.println("min^2 + 1 = " + x + 1);
        }
    }
}