package com.company;

import java.util.Scanner;

public class Project14 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double x, y, a, b, c;

        System.out.print("x = ");
        x = in.nextDouble();
        System.out.print("y = ");
        y = in.nextDouble();
        System.out.print("a = ");
        a = in.nextDouble();
        System.out.print("b = ");
        b = in.nextDouble();
        System.out.print("c = ");
        c = in.nextDouble();

        if (a > b && a > c) {
            System.out.println("a > b && a > c \n============================");

            boolean b1 = (x >= y && c >= y && y >= b) || (x <= y && c >= x && x >= b) ;

                if(b1){
                System.out.println("a, b, c o'chamli g'isht tirqishga sig'adi");
                }
                else {
                System.out.println("a, b, c o'chamli g'isht tirqishga sig'mayadi");
                }
        }
        else if (b > a && b > c ) {
            System.out.println("b > a && b > c ");

            boolean b2 = (x >= y && c >= y && y >= a) || (x <= y && c >= x && x >= a);

                if(b2){
                System.out.println("a, b, c o'chamli g'isht tirqishga sig'adi");
                }
                else {
                System.out.println("a, b, c o'chamli g'isht tirqishga sig'maydi");
                }
        }
        else {
            System.out.println("c > a && c > b ");

            boolean b3 = (x >= y && a >= y && y >= b) || (x <= y && a >= x && x >= b);

                if(b3){
                System.out.println("a, b, c o'chamli g'isht tirqishga sig'adi");
                }
                else {
                System.out.println("a, b, c o'chamli g'isht tirqishga sig'mayadi");
                }
        }
    }
}
