package com.company;

import java.util.Scanner;

public class Project7 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b;

        System.out.print("a=");
        a = in.nextDouble();
        System.out.print("b=");
        b = in.nextDouble();

        if (a > b) {
            System.out.println("a katta b dan, a = " + a);
        } else {
            System.out.println("a va b --> " + a + ", " + b) ;
        }
    }
}


