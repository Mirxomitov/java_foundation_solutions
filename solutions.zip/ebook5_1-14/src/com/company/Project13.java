package com.company;

import java.util.Scanner;

public class Project13 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b, c;
        System.out.println("ax^2 + bx + c = 0 tenglamani yechish:\n");
        System.out.print("a=");
        a = in.nextDouble();
        System.out.print("b=");
        b = in.nextDouble();
        System.out.print("c=");
        c = in.nextDouble();

        double D;
        D = b * b - 4 * a * c;

        if(D > 0){
            double x1 = (- b + Math.sqrt(D)) / (2 * a) ;
            double x2 = (- b - Math.sqrt(D)) / (2 * a) ;

            System.out.println("x1=" + x1);
            System.out.println("x2=" + x2);
        }
        else if(D == 0) {
            double x = - b / (2 * a);
            System.out.println("x = " + x);
        }
        else {
            System.out.println("Kvadrat tenglama yechimga ega emas");
        }
    }
}
