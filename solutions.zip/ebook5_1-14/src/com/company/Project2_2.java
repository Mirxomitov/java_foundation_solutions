package com.company;

import java.util.Scanner;

public class Project2_2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b, c;
        double max;

        System.out.print("a=");
        a = in.nextDouble();
        System.out.print("b=");
        b = in.nextDouble();
        System.out.print("c=");
        c = in.nextDouble();

        boolean isTrue1 = a < b && a < c;
        boolean isTrue2 = b < a && b < c;
        if (isTrue1) {
            System.out.println("minimum = " + a);
        } else if (isTrue2) {
            System.out.println("minimum = " + b);
        } else {
            System.out.println("minimum = " + c);
        }
    }
}
