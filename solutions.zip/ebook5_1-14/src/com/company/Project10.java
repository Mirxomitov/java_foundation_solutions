package com.company;

import java.util.Scanner;

public class Project10 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b, max, min;

        System.out.println("a=");
        a = in.nextDouble();
        System.out.println("b=");
        b = in.nextDouble();

        min = a < b ? a : b;
        System.out.println("ikkita sonning kattasi " + min);

        if (a > b){
            min = (a + b) / 2;
            System.out.println(min);
            a = 2 * a * b;
            System.out.println(a);
        }
        else {
            min = (a + b) / 2;
            System.out.println(min);
            b = 2 * a * b;
            System.out.println(b);
        }
    }

}
