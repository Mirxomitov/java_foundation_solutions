package com.company;

import java.util.Scanner;

public class Project8 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double a, b;

        System.out.print("a=");
        a = in.nextDouble();
        System.out.print("b=");
        b = in.nextDouble();

        if (a <= b) {
            a = 0;
            System.out.println("a kichik yoki teng b" + a);
        } else {
            System.out.println("a=" + a) ;
        }
    }
}


