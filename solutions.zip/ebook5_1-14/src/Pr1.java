import java.util.Scanner;

public class Pr1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        double x, y, max;

        x = in.nextDouble();
        y = in.nextDouble();

        max = x > y ? x : y;
        System.out.println("Ikkita sonning kattasi = "  + max);

        if (x < y) {
            System.out.println("Ikkita sonning kichigi = " + x);
        }
        else {
            System.out.println("Ikkita sonning kichigi = " + y);
        }
    }
}
