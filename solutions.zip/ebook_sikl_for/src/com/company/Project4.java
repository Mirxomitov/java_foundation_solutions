package com.company;

import java.util.Scanner;

public class Project4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n, i, j, sum = 0;
        n = in.nextInt();


        for (i = 1; i <= n; i++) {
            sum = sum + i;

            for (j = 1; j <= n; j++)
                if (j == sum) System.out.println(sum);
        }
    }
}