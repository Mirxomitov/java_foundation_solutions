package com.company;

import java.util.Scanner;

public class Project5 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n, i, j, sum = 0;
            n = in.nextInt();

        for (i = 0; i >= n; i++){
        sum += i++;

        if(sum % 3 == 0 && sum % 5 != 0) {
            System.out.println(sum);
        }
        }
    }
}
