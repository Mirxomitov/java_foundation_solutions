package com.company;

import java.util.Scanner;

public class Project3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int n, sum = 0;
        n = in.nextInt();

        for(int i = 1; i <= n; i++){
            sum +=i;
            if(n == sum) break;
            }

        if(n == sum) System.out.println("Mukammal");
        else System.out.println("Mukammal emas");
    }
}

