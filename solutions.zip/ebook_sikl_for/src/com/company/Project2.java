package com.company;

import java.util.Scanner;

public class Project2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int i, n;
        n = in.nextInt();
        int sum = 0;
        for (i = 1; i <= n; i++){
            if(n % i == 0) {
                sum += n / i;
            }
        }
        System.out.println(sum);
    }
}
