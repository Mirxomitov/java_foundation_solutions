package com.company;

import java.util.Scanner;

public class Project1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int i, n;
        n = in.nextInt();

        for (i = 1; i <= n; i++){
            if(n % i == 0) {
                System.out.println(n / i);
            }
        }
    }
}
